"""Run every example program and check its exact output."""

from __future__ import annotations

import unittest
from pathlib import Path

import helpers
from helpers import compile_text, run_text

EXAMPLES = helpers.ROOT / "examples"

EXPECTED = {
    "hello.rpl": "Hello from RPL!\n",
    "variables.rpl": "15\nRPL\n",
    "loops.rpl": "Working!\nWorking!\nWorking!\n",
    "full_demo.rpl": (
        "Hello from RPL!\n"
        "15\n"
        "Working!\n"
        "Working!\n"
        "Working!\n"
    ),
    "nested_loops.rpl": (
        "Outer loop\n"
        "  Inner loop\n"
        "  Inner loop\n"
        "  Inner loop\n"
        "Outer loop\n"
        "  Inner loop\n"
        "  Inner loop\n"
        "  Inner loop\n"
    ),
}


class ExampleTests(unittest.TestCase):
    def test_expected_examples_exist(self):
        for name in EXPECTED:
            self.assertTrue((EXAMPLES / name).is_file(), name)

    def test_example_outputs(self):
        for name, expected in EXPECTED.items():
            with self.subTest(example=name):
                source = (EXAMPLES / name).read_text(encoding="utf-8")
                self.assertEqual(run_text(source, origin=name), expected)

    def test_all_examples_compile(self):
        sources = sorted(EXAMPLES.glob("*.rpl"))
        self.assertGreaterEqual(len(sources), 5)
        for source in sources:
            with self.subTest(example=source.name):
                text = source.read_text(encoding="utf-8")
                program = compile_text(text, origin=str(source))
                self.assertTrue(program.instructions)
                # The file must survive a serialise/load cycle.
                from src.bytecode import BytecodeProgram

                BytecodeProgram.from_bytes(program.to_bytes())


if __name__ == "__main__":
    unittest.main()
