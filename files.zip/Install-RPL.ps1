<#
.SYNOPSIS
  Installs RPL Portable (Offline Edition): RPL Launcher, RPL Player, RPL Developer.
.DESCRIPTION
  Verifies the bundled files against SHA256SUMS.txt, checks for the .NET 8 Desktop
  Runtime, copies the program files, creates the Apps and Projects folders, keeps an
  existing libary.txt, writes README.txt and optionally creates a desktop shortcut.
#>
[CmdletBinding()]
param(
    [string]$InstallDir
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$ReleaseRoot = $PSScriptRoot
$PayloadDir  = Join-Path $ReleaseRoot 'payload'
$HashFile    = Join-Path $ReleaseRoot 'SHA256SUMS.txt'
$DotNetUrl   = 'https://dotnet.microsoft.com/download/dotnet/8.0'

$LibraryText = @(
    '# RPL (Ridwaan Programming Language) Command Library',
    '# Format: command name:binary (only 0 and 1 allowed)',
    '# Update this file anytime, no app rebuild needed!',
    'open window:101001',
    'close window:101010',
    'show title:101100',
    'print hello:110001',
    'play sound:110010',
    'wait:110100',
    'clear screen:111000',
    'exit app:111111'
) -join "`r`n"

$ReadmeText = @'
RPL (Ridwaan Programming Language) Portable Offline Edition
=============================================================

Requires: Windows 10 or 11 (64-bit) and the .NET 8 Desktop Runtime (x64).

Files in this folder:
- RPL Launcher.exe   : Epic-style offline launcher for your .rplc apps
- RPL Player.exe     : Locked-down runtime (players cannot see source code; requires Encryption Code)
- RPL Developer.exe  : Developer IDE driven by libary.txt to write and encrypt .rplc apps
- libary.txt         : Command definitions in "command name:binary" format (e.g. open window:101001)
- Apps\              : Put .rplc encrypted apps here so they appear in RPL Launcher
- Projects\          : Optional developer .rpl source files

Updating RPL Commands:
- Edit libary.txt and add new lines like:
  my command:101110
- Command names cannot contain ':'. Binary codes may only contain 0 and 1.
- No need to rebuild the .exe files!
'@

function Write-Step([string]$Text) { Write-Host ''; Write-Host "==> $Text" -ForegroundColor Cyan }
function Write-Good([string]$Text) { Write-Host "    $Text" -ForegroundColor Green }
function Write-Note([string]$Text) { Write-Host "    $Text" -ForegroundColor Yellow }

function Ask-YesNo([string]$Question, [bool]$Default = $true) {
    $hint = if ($Default) { '[Y/n]' } else { '[y/N]' }
    $answer = Read-Host "$Question $hint"
    if ([string]::IsNullOrWhiteSpace($answer)) { return $Default }
    return $answer.Trim().ToLower().StartsWith('y')
}

function Test-DotNetDesktop8 {
    $roots = @()
    if ($env:ProgramFiles)        { $roots += (Join-Path $env:ProgramFiles 'dotnet') }
    if (${env:ProgramFiles(x86)}) { $roots += (Join-Path ${env:ProgramFiles(x86)} 'dotnet') }
    foreach ($root in $roots) {
        $dir = Join-Path $root 'shared\Microsoft.WindowsDesktop.App'
        if (Test-Path -LiteralPath $dir) {
            $found = Get-ChildItem -LiteralPath $dir -Directory -ErrorAction SilentlyContinue |
                     Where-Object { $_.Name -like '8.*' }
            if ($found) { return $true }
        }
    }
    if (Get-Command dotnet -ErrorAction SilentlyContinue) {
        $runtimes = & dotnet --list-runtimes 2>$null
        if ($runtimes -match 'Microsoft\.WindowsDesktop\.App 8\.') { return $true }
    }
    return $false
}

function Test-ReleaseFiles {
    if (-not (Test-Path -LiteralPath $HashFile)) {
        throw 'SHA256SUMS.txt is missing. Please download RPL again.'
    }
    $problems = New-Object System.Collections.Generic.List[string]
    foreach ($line in (Get-Content -LiteralPath $HashFile)) {
        if ($line -match '^\s*([0-9A-Fa-f]{64})\s+\*?(.+?)\s*$') {
            $expected = $Matches[1].ToLower()
            $relative = $Matches[2]
            $path = Join-Path $ReleaseRoot $relative
            if (-not (Test-Path -LiteralPath $path)) {
                $problems.Add("missing: $relative")
                continue
            }
            $actual = (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLower()
            if ($actual -ne $expected) { $problems.Add("changed: $relative") }
        }
    }
    return ,$problems.ToArray()
}

function New-LauncherShortcut([string]$TargetPath, [string]$WorkingDir) {
    # Values are passed as objects, not pasted into a command string,
    # so apostrophes or spaces in the install path cannot break it.
    $lnk   = Join-Path ([Environment]::GetFolderPath('Desktop')) 'RPL Launcher.lnk'
    $shell = New-Object -ComObject WScript.Shell
    try {
        $shortcut = $shell.CreateShortcut($lnk)
        $shortcut.TargetPath       = $TargetPath
        $shortcut.WorkingDirectory = $WorkingDir
        $shortcut.Description      = 'RPL Launcher (Ridwaan Programming Language)'
        $shortcut.Save()
    } finally {
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($shell)
    }
    return $lnk
}

Write-Host ''
Write-Host 'RPL Portable Installer' -ForegroundColor White
Write-Host 'Offline edition: RPL Launcher, RPL Player, RPL Developer' -ForegroundColor Gray

try {
    Write-Step 'Checking the installer files'
    if (-not (Test-Path -LiteralPath $PayloadDir)) {
        throw "The payload folder is missing: $PayloadDir"
    }
    $problems = @(Test-ReleaseFiles)
    if ($problems.Count -gt 0) {
        $problems | ForEach-Object { Write-Note $_ }
        throw 'Some files failed verification. Please download RPL again.'
    }
    Write-Good 'All files verified.'

    Write-Step 'Checking the .NET 8 Desktop Runtime'
    if (Test-DotNetDesktop8) {
        Write-Good '.NET 8 Desktop Runtime found.'
    } else {
        Write-Note 'The .NET 8 Desktop Runtime (x64) was not found. RPL needs it to run.'
        if (Ask-YesNo '    Open the download page now?' $true) { Start-Process $DotNetUrl }
        Write-Note 'Installation will continue. RPL will not start until the runtime is installed.'
    }

    Write-Step 'Choosing the install folder'
    if (-not $InstallDir) {
        $default = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'RPL Portable'
        $answer  = Read-Host "    Install folder [$default]"
        $InstallDir = if ([string]::IsNullOrWhiteSpace($answer)) { $default } else { $answer.Trim().Trim('"') }
    }
    $InstallDir = [IO.Path]::GetFullPath($InstallDir)
    Write-Good "Installing to: $InstallDir"

    Write-Step 'Copying program files'
    New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
    foreach ($sub in 'Apps', 'Projects') {
        New-Item -ItemType Directory -Force -Path (Join-Path $InstallDir $sub) | Out-Null
    }
    Get-ChildItem -LiteralPath $PayloadDir -File | ForEach-Object {
        Copy-Item -LiteralPath $_.FullName -Destination $InstallDir -Force
    }
    Write-Good 'Program files copied.'

    Write-Step 'Setting up the command library'
    $utf8    = New-Object System.Text.UTF8Encoding($false)
    $libPath = Join-Path $InstallDir 'libary.txt'
    if (Test-Path -LiteralPath $libPath) {
        Write-Good 'Existing libary.txt kept, so your commands are safe.'
    } else {
        [IO.File]::WriteAllText($libPath, $LibraryText, $utf8)
        Write-Good 'Created libary.txt with the default commands.'
    }
    [IO.File]::WriteAllText((Join-Path $InstallDir 'README.txt'), $ReadmeText, $utf8)
    Write-Good 'README.txt written.'

    Write-Step 'Desktop shortcut'
    $launcher = Join-Path $InstallDir 'RPL Launcher.exe'
    if (Ask-YesNo '    Create a desktop shortcut for RPL Launcher?' $true) {
        $lnk = New-LauncherShortcut -TargetPath $launcher -WorkingDir $InstallDir
        Write-Good "Shortcut created: $lnk"
    } else {
        Write-Good 'Skipped.'
    }

    Write-Host ''
    Write-Host 'Installation complete!' -ForegroundColor Green
    Write-Host "Program folder: $InstallDir" -ForegroundColor Gray
    $exitCode = 0
} catch {
    Write-Host ''
    Write-Host "Install failed: $($_.Exception.Message)" -ForegroundColor Red
    $exitCode = 1
}

Write-Host ''
[void](Read-Host 'Press Enter to close')
exit $exitCode
