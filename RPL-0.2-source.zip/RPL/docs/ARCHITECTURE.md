# RPL Architecture

This document explains how the Python implementation is organised and why.

## 1. Pipeline

```text
 .rpl text
    |
    v
 Lexer ................ tokens with line/column
    |
    v
 Parser ............... AST or syntax error
    |
    v
 Compiler ............. constants, instructions, source map
    |
    v
 Bytecode writer ...... .rbc bytes + CRC32
    |
    v
 Bytecode loader ...... full validation, decoded instructions
    |
    v
 VirtualMachine ....... output, variables, stack, loop frames
```

The compiler and the VM never share mutable state. The only contract between
them is `BytecodeProgram`.

## 2. Modules

### `src/lexer.py`

Converts text to `Token` objects. It knows nothing about grammar. It handles:

- comments, whitespace and newlines,
- keywords and identifiers,
- whole and decimal numbers,
- quoted text and escapes,
- exact 1-based positions.

Errors are raised as `RPLLexError`. The lexer normalises `\r\n` to `\n` so
line numbers are stable across operating systems.

### `src/parser.py`

A hand-written recursive-descent parser. It:

- enforces one statement per line,
- builds AST dataclasses with source positions,
- parses nested `repeat` blocks with a depth limit,
- produces beginner-friendly messages, including "did you mean" suggestions
  for mistyped commands and keywords.

AST nodes: `Program`, `Say`, `Make`, `Add`, `Repeat`, `StringLiteral`,
`NumberLiteral`, `VariableRef`.

The parser does not look up variables. Whether a variable exists is a runtime
property, especially inside a loop that may run zero times.

### `src/compiler.py`

Walks the AST and emits instructions. Design choices:

- **Stack machine.** Expressions push values; commands consume them.
- **Constants pool.** Strings, integers and floats are stored once and
  referenced by index.
- **Source map.** Every emitted instruction records the source line/column of
  the syntax that produced it. Value pushes use the literal's position; the
  command instruction uses its keyword position; variable instructions use
  the name's position.
- **Repeat patch.** `LOOP_START` needs the address just after `LOOP_END`,
  which is unknown while emitting the body. The compiler writes a zero
  placeholder, emits the body, then patches the operand with
  `struct.pack_into`.

After serialising, the compiler sends its own bytes through
`BytecodeProgram.from_bytes`. If the compiler has a bug, the build fails
immediately instead of creating a file the VM cannot run.

### `src/bytecode.py`

One module owns the format. It contains:

- opcode enum and instruction metadata,
- constant encoders,
- `encode_file` (writer),
- `BytecodeProgram.from_bytes` (reader and validator),
- `Instruction` and `SourceMapEntry` value objects.

The reader is deliberately strict and bounds-checked. Counts are checked
against remaining file size *before* loops, so a forged 32-bit count cannot
force billions of iterations. Reserved opcodes are rejected at load time.

### `src/virtual_machine.py`

Executes a validated `BytecodeProgram`. State:

| State | Purpose |
| --- | --- |
| `pc` | index into the decoded instruction list |
| `stack` | temporary values |
| `variables` | global name → value |
| `loops` | remaining count of each active repeat |
| `steps` | instruction budget counter |

Jumps are byte offsets in the format; the VM converts them to instruction
indices once with `offset_to_index()`. This keeps decode validation and
execution consistent.

Dynamic errors (undefined variable, type mismatch, empty stack, runaway loop)
are raised only here, because they cannot always be proven statically.

### `src/errors.py`

One exception base with optional origin, line, column, source text and byte
offset. `render()` builds the final message and caret. Keeping formatting in
one place makes every command report errors the same way.

### `src/main.py`

Argument parsing, file I/O and output formatting. It does not contain language
semantics. `compile`, `run`, `go`, `bits`, `disassemble`, `studio` and
`version` are thin layers over the modules above.

### `src/runner.py`

The headless compile-and-run helper used by the graphical editor. It calls the
same `compile_source` and `VirtualMachine` pipeline as `go`, but captures
output in a string so the result can be shown in a window. Keeping it separate
from Tkinter makes it testable without opening a window.

### `src/studio.py`

RPL Studio: a small Tkinter editor with line numbers, Open/Save, an Examples
menu, an output pane, and **F5** to run. Execution happens on a background
thread; the UI thread polls a queue, so a running program does not freeze the
window. Tkinter is imported only for the `studio` command, so the other
commands still work on a Python build without it.

### `rpl.py` and `rpl_studio.py`

`rpl.py` is the command-line bootstrap. `rpl_studio.py` opens the editor
directly and is the entry point for the windowed standalone build.

## 3. Invariants

These are the rules that keep the system coherent:

1. A `BytecodeProgram` has already passed validation. The VM may assume
   opcodes, constant indexes, jump targets and the entry point are valid.
2. The VM must still assume stack effects are *not* valid, because they are
   dynamic and a hand-written file can underflow or overflow.
3. The compiler's output must be accepted by the loader. This is enforced on
   every compile.
4. Every instruction has a source-map entry when produced by the compiler.
5. The compiler never uses `eval()` or `exec()` and never imports the VM.
6. The VM never reads source text to decide behaviour. Source text is only
   used to improve error display.

## 4. Why these choices

**Why a custom bytecode instead of Python `ast` or `compile()`?**
The project goal is to own the language technology. Using Python's compiler
would hide the interesting parts and make the format meaningless.

**Why a stack machine?**
It is simple to validate and extend, and the operand encoding stays small.
Register machines are faster but more complex for a first release.

**Why include a source map in the bytecode?**
Runtime errors that say "line 3" are much more useful than "bad value". The
map is only 12 bytes per instruction and can be omitted by tools.

**Why a CRC32?**
Bytecode is a binary format. A checksum catches truncation, line-ending
corruption, partial downloads and accidental edits. It is not security.

**Why execution limits?**
A language with loops will eventually meet an accidental infinite loop. A
budget produces a clear error instead of a frozen terminal.

**Why one global variable store?**
RPL 0.2 has no functions or block scopes. Functions in 0.4 will require a
proper call-frame design; pretending to have scopes now would complicate the
semantics without adding a usable feature.

## 5. Extending the language

For a new **source command** that maps to existing opcodes (for example
`subtract 5 from score`):

1. Lexer: add reserved words if needed.
2. Parser: add an AST node and grammar branch.
3. Compiler: emit the existing opcodes.
4. VM: likely no change.
5. Tests: parser, compile shape, runtime output, errors.
6. Docs: language spec and changelog.

For a new **VM instruction**:

1. Allocate the next opcode in `Op` and `SPECS`.
2. Add operand encoding and validation.
3. Implement execution and stack effects.
4. Add disassembler display if operands need context.
5. Add bytecode tests (valid and malformed).
6. Implement compiler emission if source can reach it.
7. Update `docs/BYTECODE_SPEC.md`.
8. Run the full suite and disassemble an example.

The tutorial contains a complete worked `subtract` exercise.

## 6. Future design (not implemented)

- **0.3 conditions:** `COMPARE`, `JUMP_IF_FALSE` and booleans already exist at
  the VM level. The missing parts are source syntax, AST nodes and compiler
  emission, plus short-circuit rules.
- **0.4 functions:** reserved `CALL`/`RETURN` opcodes need a function table,
  call frames, argument passing and local scopes. This is a substantial
  format change.
- **0.5 modules:** likely a pre-link step that combines bytecode units or a
  loader that resolves imports.
- **Native code:** not planned for the near term. RPL 0.2 is a bytecode VM.

## 7. Testing strategy

- **Unit tests** for each stage, including exact error locations.
- **Round-trip tests** for every constant type and for compiled files.
- **Adversarial bytecode tests** for magic, version, checksum, truncation,
  unknown opcodes, reserved opcodes, bad indexes, mid-instruction jumps,
  invalid loop direction, entry point and source map.
- **Execution tests** for normal output and every runtime error path.
- **CLI tests** using the real `rpl.py` process and temporary directories.
- **Example tests** that assert exact output for every shipped program.

Run everything with:

```powershell
python -m unittest discover -s tests -v
```

## 8. Packaging

`packaging/build_windows.ps1` uses PyInstaller to bundle the Python runtime
and `src/` into two programs: `dist/RPL.exe` (console) and
`dist/RPL Studio.exe` (windowed editor). `packaging/build_linux.sh` builds the
console program on Linux/macOS. PyInstaller is a build-time dependency only;
RPL itself has no third-party runtime dependencies.

The iOS situation is different: an iOS app needs a GUI wrapper, macOS/Xcode
and Apple signing. No `.ipa` is produced or claimed by this project. See
`packaging/README.md`.
