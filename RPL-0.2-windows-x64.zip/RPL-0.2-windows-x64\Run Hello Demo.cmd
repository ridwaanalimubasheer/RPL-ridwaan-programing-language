@echo off
setlocal
cd /d "%~dp0"
echo Running examples\hello.rpl ...
echo.
RPL.exe go examples\hello.rpl
echo.
pause
