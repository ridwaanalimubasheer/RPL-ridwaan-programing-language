# Contributing to RPL

Thank you for helping with RPL. This project is an early prototype, so clear
bug reports and small, well-tested changes are especially valuable.

## Before you start

- RPL 0.2 targets Python 3.9+ and uses only the standard library.
- Run the tests before and after your change:
  ```powershell
  python -m unittest discover -s tests -v
  ```
- Read [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and the relevant
  specification before changing behaviour.

## Project rules

1. **Do not use `eval()` or `exec()`** to run RPL code.
2. **Do not claim unimplemented features.** Documentation must distinguish
   what works today from what is planned.
3. **Keep the compiler honest.** If a source feature is added, it needs a
   documented bytecode representation and VM semantics.
4. **Validate bytecode input.** Never trust a `.rbc` file.
5. **Add tests** for every new instruction, syntax form or error path.
6. Keep the code readable. Prefer small functions and comments that explain
   *why*, not restate *what*.

## Making a change

1. Open an issue or describe the change before large work.
2. Create a branch.
3. Update code, tests and documentation together.
4. Run the full suite.
5. Open a pull request with:
   - what changed,
   - why it is needed,
   - what tests were added,
   - any effect on the bytecode format.

If the change affects the binary format, update
[docs/BYTECODE_SPEC.md](docs/BYTECODE_SPEC.md) and bump the format version
when compatibility breaks.

## Style

- Python: 4 spaces, type hints where useful, `snake_case` names.
- Error messages: complete sentences, beginner-friendly, say where and why.
- Keep line length around 88 characters or less where practical.
- Comments in specifications use absolute byte offsets and big-endian order.
- New opcodes need: an enum entry, a spec row, VM execution, disassembler
  support if operands need names, validator checks, and tests.

## Adding an instruction (short version)

1. Add the opcode to `Op` and `SPECS` in `src/bytecode.py`.
2. Validate its operands in `_validate_operands`.
3. Implement it in `VirtualMachine.run`.
4. Emit it from `src/compiler.py` if RPL source can produce it.
5. Update `docs/BYTECODE_SPEC.md`.
6. Add VM tests (and compiler tests if source syntax changed).
7. Run `python rpl.py disassemble` on a sample to check the output.

The tutorial has a full worked example: [docs/TUTORIAL.md](docs/TUTORIAL.md).

## Reporting bugs

Include:

- the smallest `.rpl` program that shows the problem,
- the exact command you ran,
- the output and the error message,
- your Python version (`python --version`) and operating system.

Please do not include personal credentials, tokens or private files.

## Code of conduct

Be respectful and constructive. Disagreements about design are fine; personal
attacks are not. This project follows the spirit of the
[Contributor Covenant](https://www.contributor-covenant.org/).
