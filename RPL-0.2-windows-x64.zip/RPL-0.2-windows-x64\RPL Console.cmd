@echo off
setlocal
cd /d "%~dp0"
title RPL 0.2 Console

echo ================================================
echo   RPL 0.2 - Ridwaan Programming Language
echo   Standalone console (Python not required)
echo ================================================
echo.
echo Type:  RPL.exe --help
echo Try:   RPL.exe go examples\full_demo.rpl
echo.
cmd /k
