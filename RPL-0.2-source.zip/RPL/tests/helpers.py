"""Shared helpers for the RPL test suite."""

from __future__ import annotations

import io
import sys
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from src.bytecode import BytecodeProgram  # noqa: E402
from src.compiler import compile_source  # noqa: E402
from src.lexer import Lexer  # noqa: E402
from src.parser import Parser, Program  # noqa: E402
from src.virtual_machine import VirtualMachine  # noqa: E402


def parse_text(source: str, origin: str = "<test>") -> Program:
    tokens = Lexer(source, origin=origin).tokenize()
    return Parser(tokens, origin=origin, source_text=source).parse()


def compile_text(source: str, origin: str = "<test>") -> BytecodeProgram:
    return compile_source(source, origin=origin)


def run_text(
    source: str,
    *,
    max_steps: int = 100_000,
    origin: str = "<test>",
) -> str:
    program = compile_text(source, origin=origin)
    output = io.StringIO()
    machine = VirtualMachine(
        program, output=output, max_steps=max_steps, origin=origin
    )
    machine.run()
    return output.getvalue()


def run_program(
    program: BytecodeProgram,
    *,
    max_steps: int = 100_000,
    max_stack_values: int = 1024,
) -> str:
    output = io.StringIO()
    machine = VirtualMachine(
        program,
        output=output,
        max_steps=max_steps,
        max_stack_values=max_stack_values,
    )
    machine.run()
    return output.getvalue()
