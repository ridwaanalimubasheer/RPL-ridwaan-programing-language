@echo off
rem Opens RPL Studio without typing any commands.
start "" "%~dp0RPL Studio.exe"
