"""The RPL compiler: AST -> RPL bytecode.

The compiler walks the syntax tree produced by the parser and emits
instructions for the RPL virtual machine.  It never executes the original
source code and it never calls Python's ``eval`` or ``exec``.

Two small details matter for understanding the output:

* A stack machine is used.  ``say score`` becomes two instructions:
  ``LOAD_VARIABLE <name>`` followed by ``SAY``.
* ``repeat`` uses two instructions and one patched operand::

      PUSH_CONST 3          ; the repeat count
      LOOP_START exit       ; jump here when the count is zero
      ...body...
      LOOP_END body_start   ; go back while the counter is above zero
      exit:

  The exit address is not known until the body has been compiled, so the
  compiler writes a placeholder and fills it in afterwards.
"""

from __future__ import annotations

import math
import struct
from typing import Any, Dict, List, Optional, Sequence, Tuple

from src import bytecode
from src.bytecode import (
    MAX_CODE_BYTES,
    MAX_CONSTANTS,
    MAX_STRING_BYTES,
    BytecodeProgram,
    Op,
)
from src.errors import RPLCompileError
from src.lexer import Lexer
from src.parser import (
    Add,
    Make,
    NumberLiteral,
    Parser,
    Program,
    Repeat,
    Say,
    Statement,
    StringLiteral,
    Value,
    VariableRef,
)

I64_MIN = -(2**63)
I64_MAX = 2**63 - 1


class Compiler:
    def __init__(self) -> None:
        self.code = bytearray()
        self.constants: List[Any] = []
        self.constant_index: Dict[Tuple[str, Any], int] = {}
        self.source_map: List[Tuple[int, int, int]] = []
        self.origin: Optional[str] = None

    # -- public API -------------------------------------------------

    def compile(self, program: Program, origin: Optional[str] = None) -> BytecodeProgram:
        """Compile a parsed program and return validated bytecode."""
        self.origin = origin
        # Allow a Compiler instance to be reused safely.
        self.code = bytearray()
        self.constants = []
        self.constant_index = {}
        self.source_map = []

        for statement in program.statements:
            self._compile_statement(statement)

        if program.statements:
            last = program.statements[-1]
            halt_line, halt_column = last.line, last.column
        else:
            halt_line, halt_column = 1, 1

        self._emit(Op.HALT, (), halt_line, halt_column)

        raw = bytecode.encode_file(
            self.constants,
            bytes(self.code),
            self.source_map,
            entry_point=0,
        )

        # Run the same validator the VM uses.  This guarantees that the
        # compiler never produces a file that the loader would reject.
        return BytecodeProgram.from_bytes(raw, origin=origin)

    # -- statements -------------------------------------------------

    def _compile_statement(self, statement: Statement) -> None:
        if isinstance(statement, Say):
            self._compile_value(statement.value)
            self._emit(Op.SAY, (), statement.line, statement.column)
            return

        if isinstance(statement, Make):
            self._compile_value(statement.value)
            name_index = self._name_constant(
                statement.name, statement.name_line, statement.name_column
            )
            self._emit(
                Op.MAKE_VARIABLE,
                (name_index,),
                statement.line,
                statement.column,
            )
            return

        if isinstance(statement, Add):
            self._compile_value(statement.value)
            name_index = self._name_constant(
                statement.name, statement.name_line, statement.name_column
            )
            self._emit(
                Op.LOAD_VARIABLE,
                (name_index,),
                statement.name_line,
                statement.name_column,
            )
            self._emit(Op.ADD, (), statement.line, statement.column)
            self._emit(
                Op.STORE_VARIABLE,
                (name_index,),
                statement.name_line,
                statement.name_column,
            )
            return

        if isinstance(statement, Repeat):
            self._compile_repeat(statement)
            return

        raise TypeError(
            f"compiler bug: unknown statement type "
            f"{type(statement).__name__}"
        )  # pragma: no cover

    def _compile_repeat(self, statement: Repeat) -> None:
        self._compile_value(statement.count)

        # Emit LOOP_START with a placeholder exit address.  The operand is
        # the final u32 in the instruction, so its position is len(code)-4.
        self._emit(
            Op.LOOP_START, (0,), statement.line, statement.column
        )
        exit_operand_position = len(self.code) - 4

        body_start = len(self.code)
        for child in statement.body:
            self._compile_statement(child)

        self._emit(
            Op.LOOP_END,
            (body_start,),
            statement.end_line,
            statement.end_column,
        )

        exit_target = len(self.code)
        struct.pack_into(">I", self.code, exit_operand_position, exit_target)

    # -- values and constants ---------------------------------------

    def _compile_value(self, value: Value) -> None:
        if isinstance(value, StringLiteral):
            index = self._add_constant(value.value, value.line, value.column)
            self._emit(Op.PUSH_CONST, (index,), value.line, value.column)
            return

        if isinstance(value, NumberLiteral):
            self._check_number(value.value, value.line, value.column)
            index = self._add_constant(value.value, value.line, value.column)
            self._emit(Op.PUSH_CONST, (index,), value.line, value.column)
            return

        if isinstance(value, VariableRef):
            index = self._name_constant(
                value.name, value.line, value.column
            )
            self._emit(
                Op.LOAD_VARIABLE, (index,), value.line, value.column
            )
            return

        raise TypeError(
            f"compiler bug: unknown value type {type(value).__name__}"
        )  # pragma: no cover

    def _check_number(self, value: Any, line: int, column: int) -> None:
        if isinstance(value, int):
            if value < I64_MIN or value > I64_MAX:
                raise RPLCompileError(
                    "This whole number is too large for RPL bytecode. "
                    f"The range is {I64_MIN:,} to {I64_MAX:,}.",
                    origin=self.origin,
                    line=line,
                    column=column,
                )
            return

        if isinstance(value, float):
            if not math.isfinite(value):
                raise RPLCompileError(
                    "This decimal number is too large to store.",
                    origin=self.origin,
                    line=line,
                    column=column,
                )
            return

        raise TypeError(f"compiler bug: number is {type(value).__name__}")

    def _add_constant(self, value: Any, line: int, column: int) -> int:
        if isinstance(value, str):
            size = len(value.encode("utf-8"))
            if size > MAX_STRING_BYTES:
                raise RPLCompileError(
                    f"This text is too long ({size:,} bytes). The limit is "
                    f"{MAX_STRING_BYTES:,} bytes.",
                    origin=self.origin,
                    line=line,
                    column=column,
                )

        key = (type(value).__name__, value)
        existing = self.constant_index.get(key)
        if existing is not None:
            return existing

        if len(self.constants) >= MAX_CONSTANTS:
            raise RPLCompileError(
                f"This program needs more than {MAX_CONSTANTS:,} constants.",
                origin=self.origin,
                line=line,
                column=column,
            )

        index = len(self.constants)
        self.constants.append(value)
        self.constant_index[key] = index
        return index

    def _name_constant(self, name: str, line: int, column: int) -> int:
        return self._add_constant(name, line, column)

    # -- instruction emitter ----------------------------------------

    def _emit(
        self,
        op: Op,
        operands: Sequence[int],
        line: int,
        column: int,
    ) -> None:
        spec = bytecode.SPEC_BY_OP[op]
        offset = len(self.code)

        self.code.append(op.value)
        for kind, value in zip(spec.operands, operands):
            if kind == "u8":
                self.code += struct.pack(">B", value)
            elif kind == "u32":
                self.code += struct.pack(">I", value)
            else:  # pragma: no cover - developer mistake
                raise ValueError(f"compiler bug: unknown operand kind {kind}")

        if len(self.code) > MAX_CODE_BYTES:
            raise RPLCompileError(
                "The compiled program is too large. The code limit is "
                f"{MAX_CODE_BYTES:,} bytes. Split it into smaller programs.",
                origin=self.origin,
                line=line,
                column=column,
            )

        self.source_map.append((offset, line, column))


def compile_source(
    source: str,
    origin: Optional[str] = None,
    *,
    show_ast: bool = False,
) -> BytecodeProgram:
    """Compile RPL source text in one call (used by the CLI and tests)."""
    tokens = Lexer(source, origin=origin).tokenize()
    program = Parser(tokens, origin=origin, source_text=source).parse()
    if show_ast:  # pragma: no cover - convenience for interactive use
        from src.parser import format_ast

        print(format_ast(program))
    compiler = Compiler()
    return compiler.compile(program, origin=origin)
