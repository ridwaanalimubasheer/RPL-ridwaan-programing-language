"""Command-line interface for RPL 0.2.

Commands
--------
compile      Turn a .rpl source file into a .rbc bytecode file.
run          Execute a .rbc bytecode file.
go           Compile and run a .rpl file in one step (nothing is written).
bits         Show a .rbc file as 0s and 1s.
disassemble  Show the header, constants and instructions of a .rbc file.
version      Print version information.
studio       Open RPL Studio, the graphical editor (Tkinter).
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import List, Optional

from src.bytecode import COMPARE_MODES, BytecodeProgram
from src.compiler import compile_source
from src.errors import RPLError, RPLBytecodeError
from src.virtual_machine import DEFAULT_MAX_STEPS, VirtualMachine
from src.version import BYTECODE_VERSION, LANGUAGE_VERSION, __version__


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _configure_stdio() -> None:
    """Make command-line output UTF-8 on every platform.

    Windows redirects stdout through the ANSI code page by default. RPL
    supports UTF-8 text, so printing a Unicode program's output should not
    crash with UnicodeEncodeError.
    """
    for stream in (sys.stdout, sys.stderr):
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            reconfigure(encoding="utf-8", errors="replace")
        except (AttributeError, OSError, ValueError):
            # Some embedded/interactive streams cannot be reconfigured.
            pass


def _positive_int(text: str) -> int:
    try:
        value = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError("must be a whole number") from None
    if value < 1:
        raise argparse.ArgumentTypeError("must be 1 or greater")
    return value


def _nonnegative_int(text: str) -> int:
    try:
        value = int(text)
    except ValueError:
        raise argparse.ArgumentTypeError("must be a whole number") from None
    if value < 0:
        raise argparse.ArgumentTypeError("must be 0 or greater")
    return value


def _read_source(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8-sig")
    except UnicodeDecodeError as exc:
        raise RPLError(
            f"{path} is not valid UTF-8 text: {exc}"
        ) from None


def _default_output(source: Path) -> Path:
    if source.suffix.lower() == ".rpl":
        return source.with_suffix(".rbc")
    return source.with_name(source.name + ".rbc")


def _plural(count: int, word: str) -> str:
    return f"{count} {word}" + ("" if count == 1 else "s")


def _constant_kind(value: object) -> str:
    if isinstance(value, str):
        return "text   "
    if isinstance(value, int):
        return "integer"
    return "decimal"


def _constant_preview(value: object, limit: int = 44) -> str:
    if isinstance(value, str):
        text = json.dumps(value, ensure_ascii=False)
    else:
        text = repr(value)
    if len(text) > limit:
        text = text[: limit - 3] + "..."
    return text


def _print_bits(data: bytes, label: str, max_bytes: int) -> None:
    print(f"Binary view of {label} ({len(data):,} bytes)")
    print("Each byte is shown as 8 bits, most significant bit first.")
    print()

    shown = len(data) if max_bytes == 0 else min(len(data), max_bytes)
    for start in range(0, shown, 8):
        chunk = data[start : start + 8]
        bits = " ".join(f"{byte:08b}" for byte in chunk)
        print(f"{start:08X}  {bits}")

    if shown < len(data):
        print()
        print(
            f"... {len(data) - shown:,} more bytes not shown. "
            "Use --max-bytes 0 to show every byte."
        )


def _instruction_text(program: BytecodeProgram, index: int) -> str:
    instruction = program.instructions[index]
    name = instruction.spec.name
    operands = instruction.operands
    comment_parts: List[str] = []

    if name == "PUSH_CONST":
        operand_text = str(operands[0])
        comment_parts.append(
            _constant_preview(program.constants[operands[0]])
        )
    elif name in ("LOAD_VARIABLE", "STORE_VARIABLE", "MAKE_VARIABLE"):
        operand_text = str(operands[0])
        comment_parts.append(str(program.constants[operands[0]]))
    elif name == "COMPARE":
        mode = operands[0]
        operand_text = f"{mode} ({COMPARE_MODES.get(mode, '?')})"
    elif name in ("JUMP", "JUMP_IF_FALSE", "LOOP_START", "LOOP_END"):
        operand_text = str(operands[0])
        comment_parts.append(f"target {operands[0]}")
    else:
        operand_text = ""

    location = program.line_for(instruction.offset)
    if location is not None:
        comment_parts.append(f"line {location[0]}, column {location[1]}")

    text = f"{name:<16}"
    if operand_text:
        text += f" {operand_text}"

    if comment_parts:
        text += "  ; " + ", ".join(comment_parts)
    return text.rstrip()


def _disassemble(program: BytecodeProgram, path: Path) -> None:
    major, minor = program.format_version
    print(f"RPL bytecode format {major}.{minor}")
    print(f"File: {path}")
    print(f"File size: {len(program.to_bytes()):,} bytes")
    print(f"Constants: {len(program.constants):,}")
    print(f"Code: {len(program.code):,} bytes")
    print(f"Entry point: {program.entry_point}")
    print(f"Source map entries: {len(program.source_map):,}")
    print(f"Instructions: {len(program.instructions):,}")
    print()

    if program.constants:
        print("Constants:")
        for index, value in enumerate(program.constants):
            print(
                f"  #{index:<4} {_constant_kind(value)}  "
                f"{_constant_preview(value)}"
            )
        print()

    print("Instructions:")
    print("Offset  Bytes             Instruction")
    print("------  ----------------  ------------------------------------------")

    for index, instruction in enumerate(program.instructions):
        raw = program.code[
            instruction.offset : instruction.offset + instruction.size
        ]
        raw_text = " ".join(f"{byte:02X}" for byte in raw)
        print(
            f"{instruction.offset:04X}    {raw_text:<16}  "
            f"{_instruction_text(program, index)}"
        )


# ---------------------------------------------------------------------------
# Command handlers
# ---------------------------------------------------------------------------


def _cmd_compile(args: argparse.Namespace) -> int:
    source = Path(args.source)
    text = _read_source(source)
    program = compile_source(
        text, origin=str(source), show_ast=args.show_ast
    )

    output = Path(args.output) if args.output else _default_output(source)
    if output.resolve() == source.resolve():
        raise RPLError(
            "The output file would overwrite the source file. "
            "Choose a different output path with -o."
        )

    data = program.to_bytes()
    output.write_bytes(data)

    print(
        f"Compiled {source} -> {output}\n"
        f"  {len(data):,} bytes, "
        f"{_plural(len(program.instructions), 'instruction')}, "
        f"{_plural(len(program.constants), 'constant')}"
    )

    if args.show_bits:
        print()
        _print_bits(data, str(output), args.max_bits)

    return 0


def _cmd_run(args: argparse.Namespace) -> int:
    path = Path(args.program)
    data = path.read_bytes()

    try:
        program = BytecodeProgram.from_bytes(data, origin=str(path))
    except RPLBytecodeError as error:
        print(error.render(), file=sys.stderr)
        if path.suffix.lower() == ".rpl":
            print(
                "\nHint: this looks like RPL source code. "
                "Run it with:\n"
                f"  python rpl.py go \"{path}\"",
                file=sys.stderr,
            )
        return 1

    machine = VirtualMachine(
        program,
        max_steps=args.limit,
        origin=str(path),
    )
    machine.run()
    return 0


def _cmd_go(args: argparse.Namespace) -> int:
    source = Path(args.source)
    text = _read_source(source)
    program = compile_source(text, origin=str(source))

    machine = VirtualMachine(
        program,
        max_steps=args.limit,
        origin=str(source),
        source_text=text,
    )
    machine.run()
    return 0


def _cmd_bits(args: argparse.Namespace) -> int:
    path = Path(args.file)
    _print_bits(path.read_bytes(), str(path), args.max_bytes)
    return 0


def _cmd_disassemble(args: argparse.Namespace) -> int:
    path = Path(args.file)
    program = BytecodeProgram.from_bytes(
        path.read_bytes(), origin=str(path)
    )
    _disassemble(program, path)
    return 0


def _cmd_version(_args: argparse.Namespace) -> int:
    print(f"RPL (Ridwaan Programming Language) {__version__}")
    print(f"Language version: {LANGUAGE_VERSION}")
    print(f"Bytecode format: {BYTECODE_VERSION}")
    print(f"Python: {sys.version.split()[0]}")
    return 0


def _cmd_studio(args: argparse.Namespace) -> int:
    """Open the graphical editor.

    Tkinter is imported lazily so every other command keeps working on a
    Python installation that was built without it.
    """
    try:
        from src.studio import launch_studio
    except ImportError as error:
        print(
            "RPL error: RPL Studio needs Tkinter, which is missing from this "
            f"Python installation ({error}).\n"
            "On Debian/Ubuntu install it with: sudo apt install python3-tk\n"
            "The command-line commands (go, run, compile, ...) still work.",
            file=sys.stderr,
        )
        return 1
    return launch_studio(args.file)


# ---------------------------------------------------------------------------
# Argument parser and entry point
# ---------------------------------------------------------------------------


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="rpl",
        description=(
            "RPL 0.2 - a small English-based programming language with its "
            "own bytecode and virtual machine."
        ),
        epilog=(
            "Examples:\n"
            "  python rpl.py compile examples/hello.rpl\n"
            "  python rpl.py run examples/hello.rbc\n"
            "  python rpl.py go examples/hello.rpl\n"
            "  python rpl.py bits examples/hello.rbc\n"
            "  python rpl.py disassemble examples/hello.rbc\n"
            "  python rpl.py studio examples/hello.rpl"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--version", action="version", version=f"RPL {__version__}"
    )

    subparsers = parser.add_subparsers(
        dest="command", required=True, metavar="COMMAND"
    )

    compile_parser = subparsers.add_parser(
        "compile", help="compile a .rpl source file into .rbc bytecode"
    )
    compile_parser.add_argument("source", help="path to the .rpl file")
    compile_parser.add_argument(
        "-o", "--output", help="output .rbc path (default: same name as input)"
    )
    compile_parser.add_argument(
        "--show-ast",
        action="store_true",
        help="print the parsed syntax tree before compiling",
    )
    compile_parser.add_argument(
        "--show-bits",
        action="store_true",
        help="print the new bytecode file as 0s and 1s",
    )
    compile_parser.add_argument(
        "--max-bits",
        type=_nonnegative_int,
        default=512,
        metavar="N",
        help="with --show-bits, show at most N bytes (0 = all; default 512)",
    )
    compile_parser.set_defaults(func=_cmd_compile)

    run_parser = subparsers.add_parser(
        "run", help="execute a compiled .rbc file"
    )
    run_parser.add_argument("program", help="path to the .rbc file")
    run_parser.add_argument(
        "--limit",
        type=_positive_int,
        default=DEFAULT_MAX_STEPS,
        metavar="N",
        help=(
            "maximum instructions to execute before stopping "
            f"(default {DEFAULT_MAX_STEPS:,})"
        ),
    )
    run_parser.set_defaults(func=_cmd_run)

    go_parser = subparsers.add_parser(
        "go", help="compile and run a .rpl file in one step"
    )
    go_parser.add_argument("source", help="path to the .rpl file")
    go_parser.add_argument(
        "--limit",
        type=_positive_int,
        default=DEFAULT_MAX_STEPS,
        metavar="N",
        help=(
            "maximum instructions to execute before stopping "
            f"(default {DEFAULT_MAX_STEPS:,})"
        ),
    )
    go_parser.set_defaults(func=_cmd_go)

    bits_parser = subparsers.add_parser(
        "bits", help="show a file as 0s and 1s"
    )
    bits_parser.add_argument("file", help="path to the .rbc file")
    bits_parser.add_argument(
        "--max-bytes",
        type=_nonnegative_int,
        default=512,
        metavar="N",
        help="show at most N bytes (0 = all; default 512)",
    )
    bits_parser.set_defaults(func=_cmd_bits)

    dis_parser = subparsers.add_parser(
        "disassemble", help="show the contents of a .rbc file"
    )
    dis_parser.add_argument("file", help="path to the .rbc file")
    dis_parser.set_defaults(func=_cmd_disassemble)

    version_parser = subparsers.add_parser(
        "version", help="show version information"
    )
    version_parser.set_defaults(func=_cmd_version)

    studio_parser = subparsers.add_parser(
        "studio", help="open RPL Studio, the graphical editor"
    )
    studio_parser.add_argument(
        "file", nargs="?", help="optional .rpl file to open"
    )
    studio_parser.set_defaults(func=_cmd_studio)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    _configure_stdio()
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        return int(args.func(args))
    except RPLError as error:
        print(error.render(), file=sys.stderr)
        return 1
    except FileNotFoundError as error:
        print(f"RPL error: file not found: {error.filename}", file=sys.stderr)
        return 1
    except IsADirectoryError as error:
        print(f"RPL error: expected a file, got a directory: {error.filename}", file=sys.stderr)
        return 1
    except OSError as error:
        print(f"RPL error: {error}", file=sys.stderr)
        return 1
    except KeyboardInterrupt:
        print("\nStopped by the user.", file=sys.stderr)
        return 130


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
