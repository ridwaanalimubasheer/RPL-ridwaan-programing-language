@echo off
setlocal
cd /d "%~dp0"
echo Running examples\full_demo.rpl ...
echo.
RPL.exe go examples\full_demo.rpl
echo.
pause
