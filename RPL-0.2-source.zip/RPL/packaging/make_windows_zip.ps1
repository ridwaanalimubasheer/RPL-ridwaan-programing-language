# Assemble a ready-to-use Windows folder and ZIP.
#
# Prerequisite: build both programs first:
#   powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
#
# Result:
#   dist\RPL-0.2-windows-x64\      (folder)
#   dist\RPL-0.2-windows-x64.zip   (share this)

$ErrorActionPreference = "Stop"

$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
$Dist = Join-Path $Root "dist"
$Exe = Join-Path $Dist "RPL.exe"
$Studio = Join-Path $Dist "RPL Studio.exe"

if (-not (Test-Path $Exe)) {
    throw "dist\RPL.exe not found. Run packaging\build_windows.ps1 first."
}
if (-not (Test-Path $Studio)) {
    throw "dist\RPL Studio.exe not found. Run packaging\build_windows.ps1 first."
}

$Stage = Join-Path $Dist "RPL-0.2-windows-x64"
$Zip = Join-Path $Dist "RPL-0.2-windows-x64.zip"

if (Test-Path $Stage) { Remove-Item $Stage -Recurse -Force }
New-Item -ItemType Directory -Path $Stage | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Stage "examples") | Out-Null
New-Item -ItemType Directory -Path (Join-Path $Stage "docs") | Out-Null

Copy-Item $Exe (Join-Path $Stage "RPL.exe")
Copy-Item $Studio (Join-Path $Stage "RPL Studio.exe")
Copy-Item (Join-Path $Root "README.md") $Stage
Copy-Item (Join-Path $Root "LICENSE") $Stage
Copy-Item (Join-Path $Root "CHANGELOG.md") $Stage
Copy-Item (Join-Path $Root "docs\*") (Join-Path $Stage "docs")
Copy-Item (Join-Path $Root "examples\*.rpl") (Join-Path $Stage "examples")
Copy-Item (Join-Path $Root "examples\README.md") (Join-Path $Stage "examples")
Copy-Item (Join-Path $PSScriptRoot "windows\*") $Stage

if (Test-Path $Zip) { Remove-Item $Zip -Force }
Compress-Archive -Path $Stage -DestinationPath $Zip

Write-Host "Portable folder: $Stage"
Write-Host "ZIP:            $Zip"
