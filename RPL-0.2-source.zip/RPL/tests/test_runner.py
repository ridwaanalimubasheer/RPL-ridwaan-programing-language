"""Tests for the shared compile-and-run helper used by RPL Studio."""

from __future__ import annotations

import unittest

import helpers  # noqa: F401  (sets up sys.path)

from src.bytecode import BytecodeProgram
from src.errors import RPLRuntimeError, RPLSyntaxError
from src.runner import compile_to_bytes, execute_source


class ExecuteSourceTests(unittest.TestCase):
    def test_simple_program(self):
        output, steps = execute_source('say "Hello"\n')
        self.assertEqual(output, "Hello\n")
        self.assertGreater(steps, 0)

    def test_variables_and_loop(self):
        source = (
            "make score equal 10\n"
            "add 5 to score\n"
            "say score\n"
            "repeat 2 times\n"
            '    say "loop"\n'
            "end\n"
        )
        output, _ = execute_source(source)
        self.assertEqual(output, "15\nloop\nloop\n")

    def test_source_name_is_used_in_errors(self):
        with self.assertRaises(RPLRuntimeError) as caught:
            execute_source("say missing\n", source_name="demo.rpl")
        self.assertIn("demo.rpl", caught.exception.render())
        self.assertIn("missing", caught.exception.render())

    def test_syntax_error_is_raised(self):
        with self.assertRaises(RPLSyntaxError):
            execute_source("say\n")

    def test_execution_limit_is_respected(self):
        with self.assertRaises(RPLRuntimeError):
            execute_source(
                "repeat 100 times\n    say 1\nend\n", max_steps=10
            )

    def test_unicode_output(self):
        output, _ = execute_source('say "héllo — 日本語 ✓"\n')
        self.assertEqual(output, "héllo — 日本語 ✓\n")


class CompileToBytesTests(unittest.TestCase):
    def test_returns_a_valid_rbc_file(self):
        data = compile_to_bytes('say "hi"\n')
        self.assertTrue(data.startswith(b"RPLB"))
        program = BytecodeProgram.from_bytes(data)
        self.assertEqual(program.constants[0], "hi")

    def test_matches_normal_compiler_output(self):
        source = "make x equal 1\nadd 2 to x\nsay x\n"
        self.assertEqual(compile_to_bytes(source), compile_to_bytes(source))

    def test_syntax_error_is_raised(self):
        with self.assertRaises(RPLSyntaxError):
            compile_to_bytes("add 1\n")


if __name__ == "__main__":
    unittest.main()
