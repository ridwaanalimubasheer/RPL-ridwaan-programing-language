"""Tests for the RPL virtual machine."""

from __future__ import annotations

import io
import unittest

from helpers import compile_text, run_program, run_text

from src.bytecode import BytecodeProgram, Op, encode_file, encode_instructions
from src.errors import RPLRuntimeError
from src.virtual_machine import VirtualMachine, format_value


def build(constants=(), instructions=()):
    code = encode_instructions(instructions)
    return BytecodeProgram.from_bytes(encode_file(constants, code, ()))


def execute(constants, instructions, **kwargs):
    machine = VirtualMachine(build(constants, instructions), **kwargs)
    output = io.StringIO()
    machine.output = output
    machine.run()
    return output.getvalue()


class BasicExecutionTests(unittest.TestCase):
    def test_say_text(self):
        self.assertEqual(run_text('say "hello"\n'), "hello\n")

    def test_say_number(self):
        self.assertEqual(run_text("say 42\n"), "42\n")

    def test_say_decimal(self):
        self.assertEqual(run_text("say 3.5\n"), "3.5\n")

    def test_say_integral_decimal_without_point_zero(self):
        self.assertEqual(run_text("say 3.0\n"), "3\n")

    def test_say_variable(self):
        self.assertEqual(
            run_text('make name equal "RPL"\nsay name\n'), "RPL\n"
        )

    def test_make_can_replace_a_variable(self):
        self.assertEqual(
            run_text('make x equal 1\nmake x equal "two"\nsay x\n'),
            "two\n",
        )

    def test_escapes_are_printed(self):
        self.assertEqual(run_text(r'say "a\nb\t\"c\""' + "\n"), 'a\nb\t"c"\n')

    def test_empty_program_runs(self):
        self.assertEqual(run_text("# nothing\n"), "")

    def test_comment_after_command(self):
        self.assertEqual(run_text('say "x" # comment\n'), "x\n")


class ArithmeticTests(unittest.TestCase):
    def test_add(self):
        self.assertEqual(
            run_text("make score equal 10\nadd 5 to score\nsay score\n"),
            "15\n",
        )

    def test_add_negative(self):
        self.assertEqual(
            run_text("make score equal 10\nadd -4 to score\nsay score\n"),
            "6\n",
        )

    def test_add_decimals(self):
        self.assertEqual(
            run_text("make x equal 1.5\nadd 2.25 to x\nsay x\n"),
            "3.75\n",
        )

    def test_subtract_opcode(self):
        self.assertEqual(
            execute((10, 4), [(Op.PUSH_CONST, (0,)), (Op.PUSH_CONST, (1,)), (Op.SUBTRACT, ()), (Op.SAY, ()), (Op.HALT, ())]),
            "6\n",
        )

    def test_multiply_opcode(self):
        self.assertEqual(
            execute((6, 7), [(Op.PUSH_CONST, (0,)), (Op.PUSH_CONST, (1,)), (Op.MULTIPLY, ()), (Op.SAY, ()), (Op.HALT, ())]),
            "42\n",
        )

    def test_divide_opcode(self):
        self.assertEqual(
            execute((10, 4), [(Op.PUSH_CONST, (0,)), (Op.PUSH_CONST, (1,)), (Op.DIVIDE, ()), (Op.SAY, ()), (Op.HALT, ())]),
            "2.5\n",
        )

    def test_divide_by_zero(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            execute((10, 0), [(Op.PUSH_CONST, (0,)), (Op.PUSH_CONST, (1,)), (Op.DIVIDE, ()), (Op.SAY, ()), (Op.HALT, ())])
        self.assertIn("divide by zero", raised.exception.message.lower())

    def test_add_text_is_rejected(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text('make x equal "a"\nadd 1 to x\n')
        self.assertIn("Arithmetic works with numbers only", raised.exception.message)


class ComparisonAndJumpTests(unittest.TestCase):
    def compare(self, mode, constants, left, right):
        return execute(
            constants,
            [
                (Op.PUSH_CONST, (left,)),
                (Op.PUSH_CONST, (right,)),
                (Op.COMPARE, (mode,)),
                (Op.SAY, ()),
                (Op.HALT, ()),
            ],
        ).strip()

    def test_compare_modes(self):
        self.assertEqual(self.compare(0, (1, 1), 0, 1), "true")
        self.assertEqual(self.compare(0, (1, 2), 0, 1), "false")
        self.assertEqual(self.compare(1, (1, 2), 0, 1), "true")
        self.assertEqual(self.compare(2, (1, 2), 0, 1), "true")
        self.assertEqual(self.compare(3, (2, 2), 0, 1), "true")
        self.assertEqual(self.compare(4, (3, 2), 0, 1), "true")
        self.assertEqual(self.compare(5, (2, 2), 0, 1), "true")

    def test_compare_text(self):
        self.assertEqual(self.compare(0, ("a", "a"), 0, 1), "true")
        self.assertEqual(self.compare(2, ("a", "b"), 0, 1), "true")

    def test_compare_mixed_types_rejected(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            self.compare(2, (1, "x"), 0, 1)
        self.assertIn("Cannot compare", raised.exception.message)

    def test_unconditional_jump(self):
        output = execute(
            ("a",),
            [
                (Op.PUSH_CONST, (0,)),   # 0
                (Op.JUMP, (10,)),        # 5
                (Op.HALT, ()),           # 10
                (Op.SAY, ()),            # 11 (unreachable)
                (Op.HALT, ()),           # 12
            ],
        )
        self.assertEqual(output, "")

    def test_jump_if_false_takes_else_branch(self):
        output = execute(
            (1, 2, "no", "yes"),
            [
                (Op.PUSH_CONST, (0,)),      # 0  -> 1
                (Op.PUSH_CONST, (1,)),      # 5  -> 2
                (Op.COMPARE, (0,)),         # 10 -> equal? false
                (Op.JUMP_IF_FALSE, (28,)),  # 12
                (Op.PUSH_CONST, (3,)),      # 17 "yes"
                (Op.SAY, ()),               # 22
                (Op.JUMP, (34,)),           # 23
                (Op.PUSH_CONST, (2,)),      # 28 "no"
                (Op.SAY, ()),               # 33
                (Op.HALT, ()),              # 34
            ],
        )
        self.assertEqual(output, "no\n")


class LoopTests(unittest.TestCase):
    def test_repeat(self):
        self.assertEqual(
            run_text('repeat 3 times\n    say "x"\nend\n'),
            "x\nx\nx\n",
        )

    def test_repeat_zero_times(self):
        self.assertEqual(
            run_text('repeat 0 times\n    say "x"\nend\n'), ""
        )

    def test_repeat_empty_body(self):
        self.assertEqual(run_text("repeat 4 times\nend\n"), "")

    def test_repeat_count_from_variable(self):
        self.assertEqual(
            run_text('make n equal 2\nrepeat n times\n    say "x"\nend\n'),
            "x\nx\n",
        )

    def test_nested_repeat(self):
        output = run_text(
            'repeat 2 times\n'
            '    say "outer"\n'
            '    repeat 2 times\n'
            '        say "inner"\n'
            "    end\n"
            "end\n"
        )
        self.assertEqual(
            output,
            "outer\ninner\ninner\nouter\ninner\ninner\n",
        )

    def test_negative_repeat_count(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text('repeat -1 times\n    say "x"\nend\n')
        self.assertIn("cannot be negative", raised.exception.message)

    def test_decimal_repeat_count(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text('repeat 2.5 times\n    say "x"\nend\n')
        self.assertIn("whole number of times", raised.exception.message)

    def test_text_repeat_count(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text('repeat "x" times\n    say "y"\nend\n')
        self.assertIn("got text", raised.exception.message)

    def test_runtime_error_has_source_line(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text('say "a"\nrepeat 1.5 times\nsay "b"\nend\n')
        error = raised.exception
        self.assertEqual(error.line, 2)
        self.assertIn("whole number", error.message)


class RuntimeSafetyTests(unittest.TestCase):
    def test_undefined_variable(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text("make score equal 10\nsay scor\n")
        error = raised.exception
        self.assertIn("Variable 'scor' is not defined", error.message)
        self.assertIn("Did you mean 'score'", error.message)
        self.assertEqual((error.line, error.column), (2, 5))

    def test_add_to_undefined_variable(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text("add 1 to missing\n")
        self.assertIn("Variable 'missing' is not defined", raised.exception.message)

    def test_stack_underflow(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            execute((), [(Op.SAY, ()), (Op.HALT, ())])
        self.assertIn("value stack was empty", raised.exception.message)

    def test_stack_limit(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            execute(
                (1,),
                [
                    (Op.PUSH_CONST, (0,)),
                    (Op.PUSH_CONST, (0,)),
                    (Op.PUSH_CONST, (0,)),
                    (Op.HALT, ()),
                ],
                max_stack_values=2,
            )
        self.assertIn("value stack reached its limit", raised.exception.message)

    def test_store_undefined_variable(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            execute(
                ("x", 1),
                [
                    (Op.PUSH_CONST, (1,)),
                    (Op.STORE_VARIABLE, (0,)),
                    (Op.HALT, ()),
                ],
            )
        self.assertIn("has not been made", raised.exception.message)

    def test_execution_limit(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            execute((), [(Op.JUMP, (0,))], max_steps=10)
        self.assertIn("more than 10 instructions", raised.exception.message)

    def test_loop_hits_execution_limit(self):
        with self.assertRaises(RPLRuntimeError) as raised:
            run_text(
                'repeat 100 times\n    say "x"\nend\n', max_steps=20
            )
        self.assertIn("infinite loop", raised.exception.message)

    def test_source_excerpt_is_shown_when_available(self):
        source = 'say "a"\nsay missing\n'
        program = compile_text(source)
        output = io.StringIO()
        machine = VirtualMachine(
            program, output=output, source_text=source, origin="example.rpl"
        )
        with self.assertRaises(RPLRuntimeError) as raised:
            machine.run()
        rendered = raised.exception.render()
        self.assertIn("say missing", rendered)
        self.assertIn("^", rendered)

    def test_format_value(self):
        self.assertEqual(format_value(3.0), "3")
        self.assertEqual(format_value(3.5), "3.5")
        self.assertEqual(format_value(True), "true")
        self.assertEqual(format_value(False), "false")
        self.assertEqual(format_value("x"), "x")


if __name__ == "__main__":
    unittest.main()
