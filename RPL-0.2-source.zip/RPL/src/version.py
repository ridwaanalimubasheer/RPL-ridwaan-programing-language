"""Version information for RPL."""

__version__ = "0.2.0"
LANGUAGE_VERSION = "0.2"
BYTECODE_VERSION = "1.0"
