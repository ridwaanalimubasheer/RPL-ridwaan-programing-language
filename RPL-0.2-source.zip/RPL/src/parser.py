"""The RPL parser.

The parser reads tokens from the lexer and checks that they follow the RPL
grammar.  On success it returns a :class:`Program` containing an abstract
syntax tree (AST).  The compiler consumes that tree in the next stage.

RPL 0.2 grammar (one command per line; indentation is ignored)::

    program   := (NEWLINE | statement)* EOF
    statement := say | make | add | repeat
    say       := "say" value NEWLINE
    make      := "make" IDENT "equal" value NEWLINE
    add       := "add" value "to" IDENT NEWLINE
    repeat    := "repeat" value "times" NEWLINE (NEWLINE | statement)* "end" NEWLINE
    value     := NUMBER | STRING | IDENT | "-" NUMBER
"""

from __future__ import annotations

import difflib
import json
from dataclasses import dataclass, field
from typing import List, Optional, Union

from src.errors import RPLSyntaxError
from src.lexer import (
    EOF,
    IDENT,
    KEYWORD,
    MINUS,
    NEWLINE,
    NUMBER,
    STRING,
    KEYWORDS,
    Token,
)

MAX_BLOCK_DEPTH = 64
MAX_STATEMENTS = 50_000


# ---------------------------------------------------------------------------
# AST node definitions
# ---------------------------------------------------------------------------


@dataclass
class Node:
    line: int
    column: int


@dataclass
class StringLiteral(Node):
    value: str


@dataclass
class NumberLiteral(Node):
    value: Union[int, float]


@dataclass
class VariableRef(Node):
    name: str


Value = Union[StringLiteral, NumberLiteral, VariableRef]


@dataclass
class Say(Node):
    value: Value


@dataclass
class Make(Node):
    name: str
    name_line: int
    name_column: int
    value: Value


@dataclass
class Add(Node):
    value: Value
    name: str
    name_line: int
    name_column: int


@dataclass
class Repeat(Node):
    count: Value
    body: List["Statement"]
    end_line: int
    end_column: int


Statement = Union[Say, Make, Add, Repeat]


@dataclass
class Program:
    statements: List[Statement] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Parser
# ---------------------------------------------------------------------------

COMMANDS = ["say", "make", "add", "repeat"]

# Words that look like commands but are not part of RPL 0.2.  Giving a clear
# "planned later" message is friendlier than a generic unknown-command error.
FUTURE_COMMANDS = {
    "if": "RPL 0.3",
    "else": "RPL 0.3",
    "subtract": "a future version",
    "multiply": "a future version",
    "divide": "a future version",
    "while": "a future version",
    "for": "a future version",
    "set": "a future version",
    "create": "RPL 0.4",
    "function": "RPL 0.4",
    "import": "RPL 0.5",
    "use": "RPL 0.5",
}


class Parser:
    def __init__(
        self,
        tokens: List[Token],
        origin: Optional[str] = None,
        source_text: Optional[str] = None,
    ) -> None:
        self.tokens = tokens
        self.origin = origin
        self.source_text = source_text
        self.index = 0
        self.depth = 0
        self.statement_count = 0

    # -- token helpers ---------------------------------------------

    def _current(self) -> Token:
        return self.tokens[self.index]

    def _advance(self) -> Token:
        token = self.tokens[self.index]
        if token.kind != EOF:
            self.index += 1
        return token

    def _check(self, kind: str, value: Optional[str] = None) -> bool:
        token = self._current()
        if token.kind != kind:
            return False
        if value is not None and token.value != value:
            return False
        return True

    def _skip_newlines(self) -> None:
        while self._check(NEWLINE):
            self._advance()

    def _error(self, token: Token, message: str) -> RPLSyntaxError:
        return RPLSyntaxError(
            message,
            origin=self.origin,
            line=token.line,
            column=token.column,
            source_text=self.source_text,
        )

    @staticmethod
    def _describe(token: Token) -> str:
        if token.kind == EOF:
            return "the end of the file"
        if token.kind == NEWLINE:
            return "the end of the line"
        if token.kind == NUMBER:
            return f"the number {token.value}"
        if token.kind == STRING:
            return "a text value"
        return f"'{token.value}'"

    # -- entry point -----------------------------------------------

    def parse(self) -> Program:
        statements: List[Statement] = []
        self._skip_newlines()

        while not self._check(EOF):
            if self._check(KEYWORD, "end"):
                token = self._current()
                raise self._error(
                    token,
                    "'end' has nothing to close here. "
                    "Every 'end' must close a 'repeat' block.",
                )
            statements.append(self._parse_statement())
            self._expect_line_end()
            self._skip_newlines()

        return Program(statements)

    def _expect_line_end(self) -> None:
        token = self._current()
        if token.kind == NEWLINE:
            self._advance()
            return
        if token.kind == EOF:
            return
        raise self._error(
            token,
            f"Unexpected {self._describe(token)} after this command. "
            "Put each command on its own line.",
        )

    # -- statements ------------------------------------------------

    def _parse_statement(self) -> Statement:
        self.statement_count += 1
        if self.statement_count > MAX_STATEMENTS:
            raise self._error(
                self._current(),
                f"This program has too many statements. "
                f"The limit is {MAX_STATEMENTS:,}.",
            )

        token = self._current()

        if token.kind == KEYWORD:
            if token.value == "say":
                return self._parse_say()
            if token.value == "make":
                return self._parse_make()
            if token.value == "add":
                return self._parse_add()
            if token.value == "repeat":
                return self._parse_repeat()
            if token.value == "end":
                raise self._error(token, "'end' cannot start a command.")
            raise self._error(
                token,
                f"The word '{token.value}' cannot start a command here.",
            )

        if token.kind == IDENT:
            raise self._error(token, self._unknown_command_message(token.value))

        raise self._error(
            token,
            f"Expected a command such as 'say', 'make', 'add' or 'repeat', "
            f"but found {self._describe(token)}.",
        )

    def _parse_say(self) -> Say:
        keyword = self._advance()
        value = self._parse_value("after 'say'")
        return Say(keyword.line, keyword.column, value)

    def _parse_make(self) -> Make:
        keyword = self._advance()
        name_token = self._current()
        if name_token.kind != IDENT:
            raise self._error(
                name_token,
                f"Expected a variable name after 'make', but found "
                f"{self._describe(name_token)}.\n"
                "Example: make score equal 10",
            )
        self._advance()

        self._expect_keyword(
            "equal",
            "after the variable name",
            example=f"make {name_token.value} equal 10",
        )
        value = self._parse_value("after 'equal'")
        return Make(
            keyword.line,
            keyword.column,
            name_token.value,
            name_token.line,
            name_token.column,
            value,
        )

    def _parse_add(self) -> Add:
        keyword = self._advance()
        value = self._parse_value("after 'add'")
        self._expect_keyword(
            "to",
            "after the value",
            example="add 5 to score",
        )
        name_token = self._current()
        if name_token.kind != IDENT:
            raise self._error(
                name_token,
                f"Expected a variable name after 'to', but found "
                f"{self._describe(name_token)}.\n"
                "Example: add 5 to score",
            )
        self._advance()
        return Add(
            keyword.line,
            keyword.column,
            value,
            name_token.value,
            name_token.line,
            name_token.column,
        )

    def _parse_repeat(self) -> Repeat:
        keyword = self._advance()
        count = self._parse_value("after 'repeat'")
        self._expect_keyword(
            "times",
            "after the repeat count",
            example="repeat 5 times",
        )

        self._expect_line_end()

        self.depth += 1
        if self.depth > MAX_BLOCK_DEPTH:
            raise self._error(
                keyword,
                f"Blocks are nested too deeply. "
                f"The limit is {MAX_BLOCK_DEPTH} levels.",
            )

        body, end_line, end_column = self._parse_block(keyword)
        self.depth -= 1

        return Repeat(
            keyword.line,
            keyword.column,
            count,
            body,
            end_line,
            end_column,
        )

    def _parse_block(self, opening: Token) -> tuple:
        body: List[Statement] = []

        while True:
            self._skip_newlines()
            token = self._current()

            if token.kind == EOF:
                raise self._error(
                    opening,
                    "This 'repeat' block is missing its 'end'.\n"
                    "Add a line containing only: end",
                )

            if token.kind == KEYWORD and token.value == "end":
                end_token = self._advance()
                return body, end_token.line, end_token.column

            body.append(self._parse_statement())
            self._expect_line_end()

    # -- values and keywords ---------------------------------------

    def _parse_value(self, context: str) -> Value:
        token = self._current()

        if token.kind == NUMBER:
            self._advance()
            return NumberLiteral(token.line, token.column, token.value)

        if token.kind == STRING:
            self._advance()
            return StringLiteral(token.line, token.column, token.value)

        if token.kind == IDENT:
            self._advance()
            return VariableRef(token.line, token.column, token.value)

        if token.kind == MINUS:
            self._advance()
            number = self._current()
            if number.kind != NUMBER:
                raise self._error(
                    token,
                    "A minus sign must be followed directly by a number, "
                    "for example -5.",
                )
            self._advance()
            return NumberLiteral(token.line, token.column, -number.value)

        raise self._error(
            token,
            f"Expected text, a number, or a variable name {context}, "
            f"but found {self._describe(token)}.",
        )

    def _expect_keyword(
        self, word: str, context: str, example: Optional[str] = None
    ) -> Token:
        token = self._current()
        if token.kind == KEYWORD and token.value == word:
            return self._advance()

        message = (
            f"Expected '{word}' {context}, but found {self._describe(token)}."
        )
        if token.kind in (IDENT, KEYWORD):
            matches = difflib.get_close_matches(
                str(token.value).lower(), [word], n=1, cutoff=0.6
            )
            if matches:
                message += f" Did you mean '{word}'?"
        if example:
            message += f"\nExample: {example}"

        raise self._error(token, message)

    def _unknown_command_message(self, word: str) -> str:
        lower = word.lower()

        if lower in KEYWORDS:
            return (
                f"RPL commands are lowercase. Did you mean '{lower}'?"
            )

        if lower in FUTURE_COMMANDS:
            milestone = FUTURE_COMMANDS[lower]
            return (
                f"'{word}' is planned for {milestone}, but it is not "
                "available in RPL 0.2 yet."
            )

        matches = difflib.get_close_matches(lower, COMMANDS, n=1, cutoff=0.6)
        if matches:
            return (
                f"I don't know the command '{word}'. "
                f"Did you mean '{matches[0]}'?"
            )

        return (
            f"I don't know the command '{word}'. "
            "The commands in RPL 0.2 are: say, make, add and repeat."
        )


# ---------------------------------------------------------------------------
# Human-readable AST dump (used by ``rpl compile --show-ast``)
# ---------------------------------------------------------------------------


def _format_value(value: Value) -> str:
    if isinstance(value, StringLiteral):
        return json.dumps(value.value, ensure_ascii=False)
    if isinstance(value, NumberLiteral):
        return str(value.value)
    return value.name


def _format_statement(statement: Statement, indent: int) -> List[str]:
    pad = "  " * indent
    if isinstance(statement, Say):
        return [f"{pad}say {_format_value(statement.value)}"]
    if isinstance(statement, Make):
        return [
            f"{pad}make {statement.name} = {_format_value(statement.value)}"
        ]
    if isinstance(statement, Add):
        return [
            f"{pad}add {_format_value(statement.value)} to {statement.name}"
        ]
    # Repeat
    lines = [f"{pad}repeat {_format_value(statement.count)} times"]
    for child in statement.body:
        lines.extend(_format_statement(child, indent + 1))
    lines.append(f"{pad}end")
    return lines


def format_ast(program: Program) -> str:
    lines = ["Program"]
    if not program.statements:
        lines.append("  (empty)")
    for statement in program.statements:
        lines.extend(_format_statement(statement, 1))
    return "\n".join(lines)
