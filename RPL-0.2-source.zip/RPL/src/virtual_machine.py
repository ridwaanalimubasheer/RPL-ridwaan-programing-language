"""The RPL virtual machine (VM).

The VM loads already-validated ``BytecodeProgram`` objects and executes
their instructions.  It is a stack machine:

* a *value stack* holds temporary values (numbers and text),
* a *variable store* maps names to values,
* a *loop stack* holds the remaining count of each active ``repeat``.

The VM has a hard instruction budget (``max_steps``).  A program that runs
longer than the budget stops with a runtime error instead of hanging the
computer.  This is the safety net for accidental infinite loops.

No Python ``eval`` or ``exec`` is involved at any point.
"""

from __future__ import annotations

import difflib
import math
import sys
from typing import Any, Dict, List, Optional, TextIO

from src.bytecode import (
    COMPARE_MODES,
    BytecodeProgram,
    Instruction,
    Op,
)
from src.errors import RPLRuntimeError

DEFAULT_MAX_STEPS = 1_000_000
DEFAULT_MAX_STACK_VALUES = 1024
DEFAULT_MAX_LOOP_DEPTH = 256
MAX_VARIABLES = 100_000


def format_value(value: Any) -> str:
    """Format a runtime value the way ``say`` prints it."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if math.isnan(value):
            return "nan"
        if math.isinf(value):
            return "inf" if value > 0 else "-inf"
        # 15.0 should look like 15, not 15.0.
        if value.is_integer() and abs(value) < 1e16:
            return str(int(value))
        return repr(value)
    return str(value)


def _type_name(value: Any) -> str:
    if isinstance(value, bool):
        return "a true/false value"
    if isinstance(value, int):
        return "a whole number"
    if isinstance(value, float):
        return "a decimal number"
    if isinstance(value, str):
        return "text"
    return type(value).__name__  # pragma: no cover - defensive


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _is_truthy(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    if _is_number(value):
        return value != 0
    if isinstance(value, str):
        return len(value) > 0
    return True  # pragma: no cover - no other runtime types exist


class VirtualMachine:
    def __init__(
        self,
        program: BytecodeProgram,
        *,
        output: Optional[TextIO] = None,
        max_steps: int = DEFAULT_MAX_STEPS,
        max_stack_values: int = DEFAULT_MAX_STACK_VALUES,
        max_loop_depth: int = DEFAULT_MAX_LOOP_DEPTH,
        origin: Optional[str] = None,
        source_text: Optional[str] = None,
    ) -> None:
        if max_steps < 1:
            raise ValueError("max_steps must be at least 1")
        if max_stack_values < 1:
            raise ValueError("max_stack_values must be at least 1")
        if max_loop_depth < 1:
            raise ValueError("max_loop_depth must be at least 1")

        self.program = program
        self.output = output if output is not None else sys.stdout
        self.max_steps = max_steps
        self.max_stack_values = max_stack_values
        self.max_loop_depth = max_loop_depth
        self.origin = origin if origin is not None else program.origin
        self.source_text = source_text

        self.offset_to_index = program.offset_to_index()
        self.variables: Dict[str, Any] = {}
        self.stack: List[Any] = []
        self.loops: List[int] = []
        self.pc = 0
        self.steps = 0

    # -- public API -------------------------------------------------

    def run(self) -> int:
        """Execute the program and return the number of instructions run."""
        self.variables = {}
        self.stack = []
        self.loops = []
        self.pc = self.offset_to_index.get(self.program.entry_point, 0)
        self.steps = 0

        instructions = self.program.instructions

        while self.pc < len(instructions):
            instruction = instructions[self.pc]
            self.steps += 1

            if self.steps > self.max_steps:
                raise self._error(
                    f"The program used more than {self.max_steps:,} "
                    "instructions and was stopped. This usually means an "
                    "infinite loop. You can raise the limit with --limit.",
                    instruction,
                )

            op = instruction.op

            if op is Op.HALT:
                return self.steps

            if op is Op.PUSH_CONST:
                self._push(self.program.constants[instruction.operands[0]])
                self.pc += 1
                continue

            if op is Op.LOAD_VARIABLE:
                name = self._name(instruction)
                if name not in self.variables:
                    raise self._error(self._undefined_message(name), instruction)
                self._push(self.variables[name])
                self.pc += 1
                continue

            if op is Op.STORE_VARIABLE:
                name = self._name(instruction)
                value = self._pop(instruction)
                if name not in self.variables:
                    raise self._error(
                        f"Cannot update '{name}' because it has not been "
                        f"made yet. Use: make {name} equal ...",
                        instruction,
                    )
                self.variables[name] = value
                self.pc += 1
                continue

            if op is Op.MAKE_VARIABLE:
                name = self._name(instruction)
                value = self._pop(instruction)
                if name not in self.variables and len(self.variables) >= MAX_VARIABLES:
                    raise self._error(
                        f"The program has declared more than "
                        f"{MAX_VARIABLES:,} variables, which is the limit.",
                        instruction,
                    )
                self.variables[name] = value
                self.pc += 1
                continue

            if op is Op.SAY:
                value = self._pop(instruction)
                print(format_value(value), file=self.output)
                self.pc += 1
                continue

            if op in (Op.ADD, Op.SUBTRACT, Op.MULTIPLY, Op.DIVIDE):
                self._arithmetic(op, instruction)
                self.pc += 1
                continue

            if op is Op.COMPARE:
                self._compare(instruction)
                self.pc += 1
                continue

            if op is Op.JUMP:
                self.pc = self._target(instruction, instruction.operands[0])
                continue

            if op is Op.JUMP_IF_FALSE:
                condition = self._pop(instruction)
                if not _is_truthy(condition):
                    self.pc = self._target(instruction, instruction.operands[0])
                else:
                    self.pc += 1
                continue

            if op is Op.LOOP_START:
                self._loop_start(instruction)
                continue

            if op is Op.LOOP_END:
                self._loop_end(instruction)
                continue

            # The loader rejects unknown and reserved opcodes, so this is a
            # defensive check for a bug in RPL itself.
            raise self._error(  # pragma: no cover
                f"Internal error: the VM does not know opcode "
                f"0x{int(op):02X}.",
                instruction,
            )

        # Falling off the end of the code is a clean stop.  The compiler
        # always emits HALT, but hand-written bytecode may rely on this.
        return self.steps

    # -- stack helpers ----------------------------------------------

    def _push(self, value: Any) -> None:
        if len(self.stack) >= self.max_stack_values:
            instruction = (
                self.program.instructions[self.pc]
                if self.pc < len(self.program.instructions)
                else None
            )
            raise self._error(
                f"The value stack reached its limit of "
                f"{self.max_stack_values:,} values. This usually means the "
                "program keeps adding values without using them.",
                instruction,
            )
        self.stack.append(value)

    def _pop(self, instruction: Instruction) -> Any:
        if not self.stack:
            raise self._error(
                f"The value stack was empty while running "
                f"{instruction.spec.name}. The bytecode is invalid.",
                instruction,
            )
        return self.stack.pop()

    def _name(self, instruction: Instruction) -> str:
        index = instruction.operands[0]
        name = self.program.constants[index]
        # The loader guarantees this is text.
        return str(name)

    def _target(self, instruction: Instruction, offset: int) -> int:
        if offset == len(self.program.code):
            return len(self.program.instructions)
        index = self.offset_to_index.get(offset)
        if index is None:  # pragma: no cover - loader prevents this
            raise self._error(
                f"Invalid jump target {offset}. The bytecode is invalid.",
                instruction,
            )
        return index

    # -- operations -------------------------------------------------

    def _arithmetic(self, op: Op, instruction: Instruction) -> None:
        right = self._pop(instruction)
        left = self._pop(instruction)

        if not _is_number(left) or not _is_number(right):
            verb = {
                Op.ADD: "add",
                Op.SUBTRACT: "subtract",
                Op.MULTIPLY: "multiply",
                Op.DIVIDE: "divide",
            }[op]
            raise self._error(
                f"Cannot {verb} {_type_name(left)} and "
                f"{_type_name(right)}. Arithmetic works with numbers only.",
                instruction,
            )

        if op is Op.ADD:
            result = left + right
        elif op is Op.SUBTRACT:
            result = left - right
        elif op is Op.MULTIPLY:
            result = left * right
        else:
            if right == 0:
                raise self._error("Cannot divide by zero.", instruction)
            result = left / right

        self._push(result)

    def _compare(self, instruction: Instruction) -> None:
        mode = instruction.operands[0]
        mode_name = COMPARE_MODES[mode]
        right = self._pop(instruction)
        left = self._pop(instruction)

        if mode in (0, 1):  # EQ / NE
            left_number = _is_number(left)
            right_number = _is_number(right)
            if left_number and right_number:
                equal = left == right
            elif isinstance(left, str) and isinstance(right, str):
                equal = left == right
            elif isinstance(left, bool) and isinstance(right, bool):
                equal = left == right
            else:
                equal = False
            self._push(equal if mode == 0 else not equal)
            return

        left_ok = _is_number(left) or isinstance(left, str)
        right_ok = _is_number(right) or isinstance(right, str)
        same_kind = (
            (_is_number(left) and _is_number(right))
            or (isinstance(left, str) and isinstance(right, str))
        )
        if not (left_ok and right_ok and same_kind):
            raise self._error(
                f"Cannot compare {_type_name(left)} and "
                f"{_type_name(right)} with {mode_name}.",
                instruction,
            )

        if mode == 2:
            result = left < right
        elif mode == 3:
            result = left <= right
        elif mode == 4:
            result = left > right
        else:  # mode == 5
            result = left >= right
        self._push(result)

    def _loop_start(self, instruction: Instruction) -> None:
        count = self._pop(instruction)

        if not _is_number(count):
            raise self._error(
                f"'repeat' needs a number of times, but got "
                f"{_type_name(count)}.",
                instruction,
            )

        if isinstance(count, float):
            if not math.isfinite(count) or not count.is_integer():
                raise self._error(
                    f"'repeat' needs a whole number of times, but got "
                    f"{format_value(count)}.",
                    instruction,
                )
            count = int(count)

        if count < 0:
            raise self._error(
                f"The repeat count cannot be negative (got {count}).",
                instruction,
            )

        if len(self.loops) >= self.max_loop_depth:
            raise self._error(
                f"Loops are nested {self.max_loop_depth} levels deep, which "
                "is the limit.",
                instruction,
            )

        exit_target = instruction.operands[0]
        if count == 0:
            self.pc = self._target(instruction, exit_target)
            return

        self.loops.append(int(count))
        self.pc += 1

    def _loop_end(self, instruction: Instruction) -> None:
        if not self.loops:
            raise self._error(
                "LOOP_END ran without a matching LOOP_START. "
                "The bytecode is invalid.",
                instruction,
            )

        remaining = self.loops[-1] - 1
        if remaining > 0:
            self.loops[-1] = remaining
            self.pc = self._target(instruction, instruction.operands[0])
        else:
            self.loops.pop()
            self.pc += 1

    # -- errors -----------------------------------------------------

    def _undefined_message(self, name: str) -> str:
        message = f"Variable '{name}' is not defined."
        matches = difflib.get_close_matches(
            name, list(self.variables.keys()), n=1, cutoff=0.6
        )
        if matches:
            message += f" Did you mean '{matches[0]}'?"
        else:
            message += " Use 'make' to create it first."
        return message

    def _error(
        self, message: str, instruction: Optional[Instruction]
    ) -> RPLRuntimeError:
        line: Optional[int] = None
        column: Optional[int] = None
        offset: Optional[int] = None

        if instruction is not None:
            offset = instruction.offset
            location = self.program.line_for(instruction.offset)
            if location is not None:
                line, column = location

        return RPLRuntimeError(
            message,
            origin=self.origin,
            line=line,
            column=column,
            source_text=self.source_text,
            offset=offset,
        )
