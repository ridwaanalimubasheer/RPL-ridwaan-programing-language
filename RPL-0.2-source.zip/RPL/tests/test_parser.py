"""Tests for the RPL parser and AST."""

from __future__ import annotations

import unittest

from helpers import parse_text

from src.errors import RPLSyntaxError
from src.parser import (
    Add,
    Make,
    NumberLiteral,
    Repeat,
    Say,
    StringLiteral,
    VariableRef,
    format_ast,
)


class ParserTests(unittest.TestCase):
    def test_say_string(self):
        program = parse_text('say "hello"\n')
        self.assertEqual(len(program.statements), 1)
        statement = program.statements[0]
        self.assertIsInstance(statement, Say)
        self.assertIsInstance(statement.value, StringLiteral)
        self.assertEqual(statement.value.value, "hello")
        self.assertEqual((statement.line, statement.column), (1, 1))

    def test_say_number_and_variable(self):
        program = parse_text("say 42\nsay score\n")
        self.assertIsInstance(program.statements[0].value, NumberLiteral)
        self.assertIsInstance(program.statements[1].value, VariableRef)
        self.assertEqual(program.statements[1].value.name, "score")

    def test_make(self):
        statement = parse_text("make score equal 10\n").statements[0]
        self.assertIsInstance(statement, Make)
        self.assertEqual(statement.name, "score")
        self.assertEqual(statement.value.value, 10)

    def test_add(self):
        statement = parse_text("add 5 to score\n").statements[0]
        self.assertIsInstance(statement, Add)
        self.assertEqual(statement.name, "score")
        self.assertEqual(statement.value.value, 5)

    def test_negative_number(self):
        statement = parse_text("make score equal -5\n").statements[0]
        self.assertEqual(statement.value.value, -5)

    def test_repeat_with_body(self):
        program = parse_text(
            'repeat 3 times\n    say "x"\n    say "y"\nend\n'
        )
        repeat = program.statements[0]
        self.assertIsInstance(repeat, Repeat)
        self.assertEqual(repeat.count.value, 3)
        self.assertEqual(len(repeat.body), 2)
        self.assertEqual((repeat.end_line, repeat.end_column), (4, 1))

    def test_nested_repeat(self):
        program = parse_text(
            "repeat 2 times\n"
            '    say "outer"\n'
            "    repeat 3 times\n"
            '        say "inner"\n'
            "    end\n"
            "end\n"
        )
        outer = program.statements[0]
        self.assertIsInstance(outer, Repeat)
        inner = outer.body[1]
        self.assertIsInstance(inner, Repeat)
        self.assertEqual(len(inner.body), 1)

    def test_empty_repeat_body(self):
        repeat = parse_text("repeat 2 times\nend\n").statements[0]
        self.assertEqual(repeat.body, [])

    def test_blank_lines_and_comments(self):
        program = parse_text(
            "\n# comment\n\n"
            'say "a"\n\n'
            "# another\n"
            "say 2\n"
        )
        self.assertEqual(len(program.statements), 2)

    def test_empty_program(self):
        program = parse_text("\n\n# only comments\n")
        self.assertEqual(program.statements, [])

    def test_missing_end(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text("repeat 2 times\n    say \"x\"\n")
        error = raised.exception
        self.assertIn("missing its 'end'", error.message)
        self.assertEqual((error.line, error.column), (1, 1))

    def test_unexpected_end(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text("end\n")
        self.assertIn("nothing to close", raised.exception.message)

    def test_missing_equal(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text("make score 10\n")
        error = raised.exception
        self.assertIn("Expected 'equal'", error.message)
        self.assertEqual((error.line, error.column), (1, 12))

    def test_misspelled_equal_suggestion(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text("make score eqal 10\n")
        message = raised.exception.message
        self.assertIn("Expected 'equal'", message)
        self.assertIn("Did you mean 'equal'", message)

    def test_missing_names(self):
        for source in ("make 5 equal 5\n", "add 5 to 5\n"):
            with self.assertRaises(RPLSyntaxError) as raised:
                parse_text(source)
            self.assertIn("Expected a variable name", raised.exception.message)

    def test_say_without_value(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text("say\n")
        error = raised.exception
        self.assertIn("Expected text, a number, or a variable name", error.message)
        self.assertEqual((error.line, error.column), (1, 4))

    def test_unknown_command_suggestion(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text('sya "hello"\n')
        self.assertIn("Did you mean 'say'", raised.exception.message)

    def test_lowercase_keyword_hint(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text('Say "hello"\n')
        self.assertIn("commands are lowercase", raised.exception.message)

    def test_future_command_message(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text("if score is 10\n")
        self.assertIn("planned for RPL 0.3", raised.exception.message)

    def test_extra_input_on_line(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text('say "a" say "b"\n')
        error = raised.exception
        self.assertIn("own line", error.message.lower())
        self.assertEqual((error.line, error.column), (1, 9))

    def test_repeat_requires_times(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text("repeat 3\nend\n")
        self.assertIn("Expected 'times'", raised.exception.message)

    def test_minus_needs_number(self):
        with self.assertRaises(RPLSyntaxError) as raised:
            parse_text('say -"x"\n')
        self.assertIn("minus sign", raised.exception.message)

    def test_format_ast(self):
        text = format_ast(
            parse_text(
                'say "hi"\nmake x equal 1\nadd 2 to x\n'
                'repeat 2 times\n say x\nend\n'
            )
        )
        self.assertEqual(
            text,
            'Program\n'
            '  say "hi"\n'
            "  make x = 1\n"
            "  add 2 to x\n"
            "  repeat 2 times\n"
            "    say x\n"
            "  end",
        )


if __name__ == "__main__":
    unittest.main()
