# RPL examples

Run any example from the project root.

| File | What it shows | Command |
| --- | --- | --- |
| `hello.rpl` | `say` | `python rpl.py go examples/hello.rpl` |
| `variables.rpl` | `make`, `add`, text variables | `python rpl.py go examples/variables.rpl` |
| `loops.rpl` | `repeat ... end` | `python rpl.py go examples/loops.rpl` |
| `nested_loops.rpl` | loops inside loops | `python rpl.py go examples/nested_loops.rpl` |
| `full_demo.rpl` | the complete RPL 0.2 feature set | `python rpl.py go examples/full_demo.rpl` |

Expected output for `full_demo.rpl`:

```text
Hello from RPL!
15
Working!
Working!
Working!
```

To inspect the compiled form:

```powershell
python rpl.py compile examples/full_demo.rpl
python rpl.py disassemble examples/full_demo.rbc
python rpl.py bits examples/full_demo.rbc --max-bytes 128
```
