"""Tests for the .rbc file format and its validator."""

from __future__ import annotations

import struct
import unittest
import zlib

from helpers import compile_text

from src.bytecode import (
    FORMAT_MAJOR,
    FORMAT_MINOR,
    HEADER_SIZE,
    MAGIC,
    BytecodeProgram,
    Op,
    encode_file,
    encode_instructions,
)
from src.errors import RPLBytecodeError


def build(constants=(), instructions=(), source_map=(), entry_point=0):
    code = encode_instructions(instructions)
    return BytecodeProgram.from_bytes(
        encode_file(constants, code, source_map, entry_point)
    )


def refresh_checksum(data: bytearray) -> bytearray:
    checksum = zlib.crc32(bytes(data[HEADER_SIZE:])) & 0xFFFFFFFF
    struct.pack_into(">I", data, 24, checksum)
    return data


class BytecodeFormatTests(unittest.TestCase):
    def test_header_fields(self):
        program = compile_text('say "hello"\n')
        data = program.to_bytes()
        (
            magic,
            major,
            minor,
            flags,
            constants,
            code_length,
            entry,
            map_count,
            checksum,
        ) = struct.unpack_from(">4sBBHIIIII", data, 0)

        self.assertEqual(magic, MAGIC)
        self.assertEqual((major, minor), (FORMAT_MAJOR, FORMAT_MINOR))
        self.assertEqual(flags, 0)
        self.assertEqual(constants, 1)
        self.assertEqual(code_length, 7)
        self.assertEqual(entry, 0)
        self.assertEqual(map_count, 3)
        self.assertEqual(checksum, zlib.crc32(data[HEADER_SIZE:]) & 0xFFFFFFFF)

    def test_round_trip_constants(self):
        program = build(
            constants=(42, -7, 3.5, "héllo", ""),
            instructions=[(Op.HALT, ())],
        )
        self.assertEqual(program.constants, (42, -7, 3.5, "héllo", ""))
        self.assertEqual(program.format_version, (FORMAT_MAJOR, FORMAT_MINOR))

    def test_halt_only_program_is_valid(self):
        program = build(instructions=[(Op.HALT, ())])
        self.assertEqual(len(program.instructions), 1)
        self.assertEqual(program.instructions[0].op, Op.HALT)

    def test_to_bytes_matches_original(self):
        raw = encode_file(
            (1, "x"), bytes([0x00]), [(0, 1, 1)]
        )
        program = BytecodeProgram.from_bytes(raw)
        self.assertEqual(program.to_bytes(), raw)

    def test_line_for_uses_nearest_previous_entry(self):
        code = encode_instructions(
            [(Op.PUSH_CONST, (0,)), (Op.HALT, ())]
        )
        program = BytecodeProgram.from_bytes(
            encode_file(("x",), code, [(0, 1, 1), (5, 2, 3)])
        )
        self.assertEqual(program.line_for(0), (1, 1))
        self.assertEqual(program.line_for(3), (1, 1))
        self.assertEqual(program.line_for(5), (2, 3))
        self.assertEqual(program.line_for(6), (2, 3))

    def test_no_source_map_is_allowed(self):
        program = build(instructions=[(Op.HALT, ())])
        self.assertIsNone(program.line_for(0))


class BytecodeValidationTests(unittest.TestCase):
    def test_bad_magic(self):
        data = bytearray(compile_text('say "hi"\n').to_bytes())
        data[0:4] = b"XXXX"
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(bytes(data))
        self.assertIn("RPLB", raised.exception.message)

    def test_unsupported_version(self):
        data = bytearray(compile_text('say "hi"\n').to_bytes())
        data[4] = 2
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(bytes(data))
        self.assertIn("Unsupported bytecode format version", raised.exception.message)

    def test_unknown_flags(self):
        data = bytearray(compile_text('say "hi"\n').to_bytes())
        struct.pack_into(">H", data, 6, 1)
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(bytes(data))
        self.assertIn("unknown feature flags", raised.exception.message)

    def test_checksum_mismatch(self):
        data = bytearray(compile_text('say "hi"\n').to_bytes())
        data[-1] ^= 0x01
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(bytes(data))
        self.assertIn("checksum does not match", raised.exception.message)
        self.assertEqual(raised.exception.offset, 24)

    def test_truncated_file(self):
        data = compile_text('say "hi"\n').to_bytes()[:-1]
        with self.assertRaises(RPLBytecodeError):
            BytecodeProgram.from_bytes(data)

    def test_header_too_short(self):
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(b"RPLB")
        self.assertIn("too short", raised.exception.message)

    def test_trailing_bytes(self):
        data = bytearray(compile_text('say "hi"\n').to_bytes()) + b"\x00"
        refresh_checksum(data)
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(bytes(data))
        self.assertIn("unexpected extra bytes", raised.exception.message)

    def test_empty_code(self):
        raw = encode_file((), b"", ())
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("code section is empty", raised.exception.message)

    def test_unknown_opcode(self):
        raw = encode_file((), b"\xFF", ())
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("Unknown opcode 0xFF", raised.exception.message)
        self.assertEqual(raised.exception.offset, 0)

    def test_reserved_opcode(self):
        raw = encode_file((), bytes([Op.CALL]), ())
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("reserved for a future RPL version", raised.exception.message)

    def test_constant_index_out_of_range(self):
        raw = encode_file((), encode_instructions([(Op.PUSH_CONST, (9,))]), ())
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("constant #9", raised.exception.message)

    def test_variable_name_must_be_text(self):
        raw = encode_file(
            (123,),
            encode_instructions([(Op.LOAD_VARIABLE, (0,))]),
            (),
        )
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("needs a text constant", raised.exception.message)

    def test_jump_into_middle_of_instruction(self):
        raw = encode_file(
            ("x",),
            encode_instructions(
                [(Op.PUSH_CONST, (0,)), (Op.JUMP, (2,)), (Op.HALT, ())]
            ),
            (),
        )
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("does not point to the start of an instruction", raised.exception.message)

    def test_loop_end_cannot_jump_forward(self):
        raw = encode_file(
            (),
            encode_instructions(
                [(Op.LOOP_START, (10,)), (Op.LOOP_END, (10,)), (Op.HALT, ())]
            ),
            (),
        )
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("points forward", raised.exception.message)

    def test_loop_start_must_move_forward(self):
        raw = encode_file(
            (),
            encode_instructions([(Op.LOOP_START, (0,)), (Op.HALT, ())]),
            (),
        )
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("does not move forward", raised.exception.message)

    def test_invalid_entry_point(self):
        raw = encode_file((), bytes([Op.HALT]), (), entry_point=1)
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("entry point", raised.exception.message.lower())

    def test_source_map_must_point_to_instruction_start(self):
        code = encode_instructions(
            [(Op.PUSH_CONST, (0,)), (Op.HALT, ())]
        )
        raw = encode_file(("x",), code, [(0, 1, 1), (2, 1, 1)])
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("middle of an instruction", raised.exception.message)

    def test_source_map_offsets_must_increase(self):
        raw = encode_file((), bytes([Op.HALT]), [(0, 1, 1), (0, 1, 1)])
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("strictly increasing", raised.exception.message)

    def test_source_map_line_must_be_positive(self):
        raw = encode_file((), bytes([Op.HALT]), [(0, 0, 1)])
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(raw)
        self.assertIn("line and column", raised.exception.message)

    def test_unknown_constant_tag(self):
        data = bytearray(compile_text("say 1\n").to_bytes())
        data[HEADER_SIZE] = 99
        refresh_checksum(data)
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(bytes(data))
        self.assertIn("Unknown constant tag", raised.exception.message)

    def test_too_many_constants(self):
        data = bytearray(compile_text("say 1\n").to_bytes())
        struct.pack_into(">I", data, 8, 70_000)
        with self.assertRaises(RPLBytecodeError) as raised:
            BytecodeProgram.from_bytes(bytes(data))
        self.assertIn("Too many constants", raised.exception.message)


if __name__ == "__main__":
    unittest.main()
