"""RPL binary bytecode format (version 1.0, used by RPL 0.2).

A ``.rbc`` file has a fixed 28-byte header followed by three sections:

    +------------------+ 0
    | Header (28 bytes)|
    +------------------+ 28
    | Constant pool    |  variable length
    +------------------+
    | Code             |  code_length bytes
    +------------------+
    | Source map       |  12 bytes per entry
    +------------------+

All multi-byte integers are big-endian (network byte order).  The complete
layout is documented in ``docs/BYTECODE_SPEC.md``.

This module owns three responsibilities:

1. describing the instruction set (opcodes and operand shapes),
2. writing bytecode (:func:`encode_file`),
3. reading and validating bytecode (:meth:`BytecodeProgram.from_bytes`).

Validation happens before the VM sees any instruction.  A corrupted file,
an unknown opcode, a constant index that points outside the pool, or a jump
into the middle of an instruction is rejected with :class:`RPLBytecodeError`.
"""

from __future__ import annotations

import struct
import zlib
from dataclasses import dataclass
from enum import IntEnum
from typing import Any, Dict, List, Optional, Sequence, Tuple

from src.errors import RPLBytecodeError

# ---------------------------------------------------------------------------
# Format constants
# ---------------------------------------------------------------------------

MAGIC = b"RPLB"
FORMAT_MAJOR = 1
FORMAT_MINOR = 0
FORMAT_VERSION = (FORMAT_MAJOR, FORMAT_MINOR)

HEADER_STRUCT = struct.Struct(">4sBBHIIIII")
HEADER_SIZE = HEADER_STRUCT.size  # 28 bytes

TAG_INTEGER = 1
TAG_FLOAT = 2
TAG_STRING = 3

# Safety limits.  They keep a malformed or hostile file from making the
# loader allocate huge amounts of memory or loop for a very long time.
MAX_FILE_BYTES = 16 * 1024 * 1024
MAX_CONSTANTS = 65_535
MAX_CODE_BYTES = 8 * 1024 * 1024
MAX_STRING_BYTES = 1024 * 1024
MAX_SOURCE_MAP_ENTRIES = 1_000_000

OPERAND_SIZES = {"u8": 1, "u32": 4}


class Op(IntEnum):
    HALT = 0x00
    PUSH_CONST = 0x01
    LOAD_VARIABLE = 0x02
    STORE_VARIABLE = 0x03
    MAKE_VARIABLE = 0x04
    SAY = 0x05
    ADD = 0x06
    SUBTRACT = 0x07
    MULTIPLY = 0x08
    DIVIDE = 0x09
    COMPARE = 0x0A
    JUMP = 0x0B
    JUMP_IF_FALSE = 0x0C
    LOOP_START = 0x0D
    LOOP_END = 0x0E
    CALL = 0x0F
    RETURN = 0x10


@dataclass(frozen=True)
class InstructionSpec:
    opcode: int
    name: str
    operands: Tuple[str, ...] = ()
    reserved: bool = False
    summary: str = ""


SPECS: Tuple[InstructionSpec, ...] = (
    InstructionSpec(0x00, "HALT", (), summary="Stop the program."),
    InstructionSpec(
        0x01, "PUSH_CONST", ("u32",), summary="Push constant[operand]."
    ),
    InstructionSpec(
        0x02, "LOAD_VARIABLE", ("u32",), summary="Push variable[operand]."
    ),
    InstructionSpec(
        0x03,
        "STORE_VARIABLE",
        ("u32",),
        summary="Pop a value and assign it to an existing variable.",
    ),
    InstructionSpec(
        0x04,
        "MAKE_VARIABLE",
        ("u32",),
        summary="Pop a value and declare or replace a variable.",
    ),
    InstructionSpec(0x05, "SAY", (), summary="Pop and print a value."),
    InstructionSpec(0x06, "ADD", (), summary="Pop b, pop a, push a + b."),
    InstructionSpec(
        0x07, "SUBTRACT", (), summary="Pop b, pop a, push a - b."
    ),
    InstructionSpec(
        0x08, "MULTIPLY", (), summary="Pop b, pop a, push a * b."
    ),
    InstructionSpec(
        0x09, "DIVIDE", (), summary="Pop b, pop a, push a / b."
    ),
    InstructionSpec(
        0x0A,
        "COMPARE",
        ("u8",),
        summary="Pop b, pop a, push a comparison result.",
    ),
    InstructionSpec(
        0x0B, "JUMP", ("u32",), summary="Continue at absolute code offset."
    ),
    InstructionSpec(
        0x0C,
        "JUMP_IF_FALSE",
        ("u32",),
        summary="Pop a value; jump if it is false.",
    ),
    InstructionSpec(
        0x0D,
        "LOOP_START",
        ("u32",),
        summary="Pop a repeat count; operand is the exit offset.",
    ),
    InstructionSpec(
        0x0E,
        "LOOP_END",
        ("u32",),
        summary="Repeat or finish the loop; operand is the body offset.",
    ),
    InstructionSpec(
        0x0F,
        "CALL",
        (),
        reserved=True,
        summary="Reserved for RPL 0.4 functions.",
    ),
    InstructionSpec(
        0x10,
        "RETURN",
        (),
        reserved=True,
        summary="Reserved for RPL 0.4 functions.",
    ),
)

SPEC_BY_OPCODE: Dict[int, InstructionSpec] = {s.opcode: s for s in SPECS}
SPEC_BY_OP: Dict[Op, InstructionSpec] = {
    Op(s.opcode): s for s in SPECS
}

# Names of the COMPARE modes.  The operand is a u8.
COMPARE_MODES = {
    0: "EQ",
    1: "NE",
    2: "LT",
    3: "LE",
    4: "GT",
    5: "GE",
}


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class SourceMapEntry:
    offset: int
    line: int
    column: int


@dataclass(frozen=True)
class Instruction:
    offset: int
    op: Op
    operands: Tuple[int, ...]
    size: int

    @property
    def spec(self) -> InstructionSpec:
        return SPEC_BY_OP[self.op]


@dataclass
class BytecodeProgram:
    constants: Tuple[Any, ...]
    code: bytes
    entry_point: int
    source_map: Tuple[SourceMapEntry, ...]
    instructions: Tuple[Instruction, ...]
    format_version: Tuple[int, int]
    origin: Optional[str] = None

    def offset_to_index(self) -> Dict[int, int]:
        """Map a code byte offset to its position in ``instructions``."""
        return {instr.offset: index for index, instr in enumerate(self.instructions)}

    def line_for(self, offset: int) -> Optional[Tuple[int, int]]:
        """Return ``(line, column)`` recorded for an instruction offset."""
        low = 0
        high = len(self.source_map)
        found = None
        while low < high:
            middle = (low + high) // 2
            entry = self.source_map[middle]
            if entry.offset <= offset:
                found = entry
                low = middle + 1
            else:
                high = middle
        if found is None:
            return None
        return (found.line, found.column)

    def to_bytes(self) -> bytes:
        return encode_file(
            self.constants,
            self.code,
            [
                (entry.offset, entry.line, entry.column)
                for entry in self.source_map
            ],
            entry_point=self.entry_point,
        )

    @classmethod
    def from_bytes(
        cls, data: bytes, origin: Optional[str] = None
    ) -> "BytecodeProgram":
        """Parse and fully validate a ``.rbc`` file."""
        data = bytes(data)

        if len(data) < HEADER_SIZE:
            raise RPLBytecodeError(
                f"This file is too short to be RPL bytecode. "
                f"A valid file needs at least {HEADER_SIZE} bytes for its "
                f"header, but this file has {len(data)}.",
                origin=origin,
                offset=0,
            )

        if len(data) > MAX_FILE_BYTES:
            raise RPLBytecodeError(
                f"This bytecode file is too large. The limit is "
                f"{MAX_FILE_BYTES:,} bytes.",
                origin=origin,
            )

        (
            magic,
            major,
            minor,
            flags,
            constant_count,
            code_length,
            entry_point,
            map_count,
            checksum,
        ) = HEADER_STRUCT.unpack_from(data, 0)

        if magic != MAGIC:
            raise RPLBytecodeError(
                "This file does not start with the RPLB signature. "
                "It is not RPL bytecode.",
                origin=origin,
                offset=0,
            )

        if (major, minor) != FORMAT_VERSION:
            raise RPLBytecodeError(
                f"Unsupported bytecode format version {major}.{minor}. "
                f"This VM supports version {FORMAT_MAJOR}.{FORMAT_MINOR}.",
                origin=origin,
                offset=4,
            )

        if flags != 0:
            raise RPLBytecodeError(
                f"The header uses unknown feature flags (0x{flags:04X}). "
                "This file was probably made for a newer RPL version.",
                origin=origin,
                offset=6,
            )

        if constant_count > MAX_CONSTANTS:
            raise RPLBytecodeError(
                f"Too many constants ({constant_count:,}); the limit is "
                f"{MAX_CONSTANTS:,}.",
                origin=origin,
                offset=8,
            )

        if code_length == 0:
            raise RPLBytecodeError(
                "The code section is empty. Bytecode must contain at least "
                "one instruction.",
                origin=origin,
                offset=12,
            )

        if code_length > MAX_CODE_BYTES:
            raise RPLBytecodeError(
                f"The code section is too large ({code_length:,} bytes); "
                f"the limit is {MAX_CODE_BYTES:,}.",
                origin=origin,
                offset=12,
            )

        if map_count > MAX_SOURCE_MAP_ENTRIES:
            raise RPLBytecodeError(
                f"Too many source map entries ({map_count:,}); the limit is "
                f"{MAX_SOURCE_MAP_ENTRIES:,}.",
                origin=origin,
                offset=20,
            )

        payload = data[HEADER_SIZE:]
        actual_checksum = zlib.crc32(payload) & 0xFFFFFFFF
        if actual_checksum != checksum:
            raise RPLBytecodeError(
                "The bytecode checksum does not match. The file is corrupted "
                "or was edited without updating the checksum. Recompile the "
                ".rpl source file.",
                origin=origin,
                offset=24,
            )

        # Each constant needs at least 5 bytes, so this quick check stops a
        # forged count from making the loop below run billions of times.
        if constant_count * 5 > len(payload):
            raise RPLBytecodeError(
                "The constant count is too large for the size of this file.",
                origin=origin,
                offset=8,
            )

        position = HEADER_SIZE
        constants: List[Any] = []

        for index in range(constant_count):
            if position >= len(data):
                raise RPLBytecodeError(
                    f"The constant pool ends early while reading constant "
                    f"#{index}.",
                    origin=origin,
                    offset=position,
                )
            tag_offset = position
            tag = data[position]
            position += 1

            if tag == TAG_INTEGER:
                if position + 8 > len(data):
                    raise RPLBytecodeError(
                        f"Constant #{index} is an incomplete 64-bit integer.",
                        origin=origin,
                        offset=tag_offset,
                    )
                value = struct.unpack_from(">q", data, position)[0]
                position += 8
            elif tag == TAG_FLOAT:
                if position + 8 > len(data):
                    raise RPLBytecodeError(
                        f"Constant #{index} is an incomplete 64-bit float.",
                        origin=origin,
                        offset=tag_offset,
                    )
                value = struct.unpack_from(">d", data, position)[0]
                position += 8
            elif tag == TAG_STRING:
                if position + 4 > len(data):
                    raise RPLBytecodeError(
                        f"Constant #{index} is missing its string length.",
                        origin=origin,
                        offset=tag_offset,
                    )
                string_length = struct.unpack_from(">I", data, position)[0]
                position += 4
                if string_length > MAX_STRING_BYTES:
                    raise RPLBytecodeError(
                        f"Constant #{index} is a string of "
                        f"{string_length:,} bytes; the limit is "
                        f"{MAX_STRING_BYTES:,}.",
                        origin=origin,
                        offset=tag_offset,
                    )
                if position + string_length > len(data):
                    raise RPLBytecodeError(
                        f"Constant #{index} says its text is "
                        f"{string_length:,} bytes long, but the file ends "
                        "before that.",
                        origin=origin,
                        offset=tag_offset,
                    )
                raw = data[position : position + string_length]
                try:
                    value = raw.decode("utf-8")
                except UnicodeDecodeError:
                    raise RPLBytecodeError(
                        f"Constant #{index} contains text that is not valid "
                        "UTF-8.",
                        origin=origin,
                        offset=position,
                    ) from None
                position += string_length
            else:
                raise RPLBytecodeError(
                    f"Unknown constant tag 0x{tag:02X} for constant "
                    f"#{index}. Valid tags are 1 (integer), 2 (float) and "
                    "3 (text).",
                    origin=origin,
                    offset=tag_offset,
                )

            constants.append(value)

        code_offset = position
        if code_length > len(data) - position:
            raise RPLBytecodeError(
                f"The header says the code is {code_length:,} bytes, but "
                f"only {len(data) - position:,} bytes remain in the file.",
                origin=origin,
                offset=12,
            )
        code = data[position : position + code_length]
        position += code_length

        map_bytes = map_count * 12
        if map_bytes > len(data) - position:
            raise RPLBytecodeError(
                f"The source map needs {map_bytes:,} bytes, but only "
                f"{len(data) - position:,} bytes remain in the file.",
                origin=origin,
                offset=position,
            )

        source_map: List[SourceMapEntry] = []
        for _ in range(map_count):
            entry_offset, line, column = struct.unpack_from(
                ">III", data, position
            )
            position += 12
            source_map.append(SourceMapEntry(entry_offset, line, column))

        if position != len(data):
            raise RPLBytecodeError(
                f"There are {len(data) - position:,} unexpected extra bytes "
                "after the source map. The file may contain trailing data.",
                origin=origin,
                offset=position,
            )

        instructions, boundaries = _decode_instructions(
            code, constants, origin
        )
        _validate_operands(instructions, constants, boundaries, code_length, origin)
        _validate_entry_point(entry_point, instructions, code_length, origin)
        _validate_source_map(source_map, boundaries, code_length, origin)

        return cls(
            constants=tuple(constants),
            code=code,
            entry_point=entry_point,
            source_map=tuple(source_map),
            instructions=tuple(instructions),
            format_version=(major, minor),
            origin=origin,
        )

    # ``code_offset`` is used by the disassembler for its header summary.
    @property
    def code_offset(self) -> int:
        constant_bytes = sum(len(encode_constant(v)) for v in self.constants)
        return HEADER_SIZE + constant_bytes


# ---------------------------------------------------------------------------
# Writer
# ---------------------------------------------------------------------------


def encode_constant(value: Any) -> bytes:
    if isinstance(value, bool):
        raise TypeError("booleans are not valid constant-pool values")
    if isinstance(value, int):
        return struct.pack(">Bq", TAG_INTEGER, value)
    if isinstance(value, float):
        return struct.pack(">Bd", TAG_FLOAT, value)
    if isinstance(value, str):
        raw = value.encode("utf-8")
        return struct.pack(">BI", TAG_STRING, len(raw)) + raw
    raise TypeError(f"unsupported constant type: {type(value).__name__}")


def encode_instructions(instructions: Sequence[Tuple[Op, Sequence[int]]]) -> bytes:
    """Small helper used by tests and tools to build a code section."""
    code = bytearray()
    for op, operands in instructions:
        spec = SPEC_BY_OP[op]
        if len(operands) != len(spec.operands):
            raise ValueError(
                f"{spec.name} needs {len(spec.operands)} operand(s), "
                f"got {len(operands)}"
            )
        code.append(op.value)
        for kind, value in zip(spec.operands, operands):
            if kind == "u8":
                code += struct.pack(">B", value)
            elif kind == "u32":
                code += struct.pack(">I", value)
            else:  # pragma: no cover - developer mistake
                raise ValueError(f"unknown operand kind: {kind}")
    return bytes(code)


def encode_file(
    constants: Sequence[Any],
    code: bytes,
    source_map: Sequence[Tuple[int, int, int]],
    entry_point: int = 0,
) -> bytes:
    """Assemble a complete ``.rbc`` file without validating it.

    The compiler calls the validator (:meth:`BytecodeProgram.from_bytes`)
    immediately after writing, so invalid output is caught during builds.
    """
    if len(constants) > MAX_CONSTANTS:
        raise ValueError("too many constants")

    constant_blob = b"".join(encode_constant(value) for value in constants)
    map_blob = b"".join(
        struct.pack(">III", offset, line, column)
        for offset, line, column in source_map
    )
    payload = constant_blob + bytes(code) + map_blob
    checksum = zlib.crc32(payload) & 0xFFFFFFFF
    header = HEADER_STRUCT.pack(
        MAGIC,
        FORMAT_MAJOR,
        FORMAT_MINOR,
        0,
        len(constants),
        len(code),
        entry_point,
        len(source_map),
        checksum,
    )
    return header + payload


# ---------------------------------------------------------------------------
# Reader validation helpers
# ---------------------------------------------------------------------------


def _decode_instructions(
    code: bytes, constants: Sequence[Any], origin: Optional[str]
) -> Tuple[List[Instruction], set]:
    instructions: List[Instruction] = []
    boundaries = {0}
    offset = 0

    while offset < len(code):
        start = offset
        raw_opcode = code[offset]
        offset += 1

        spec = SPEC_BY_OPCODE.get(raw_opcode)
        if spec is None:
            raise RPLBytecodeError(
                f"Unknown opcode 0x{raw_opcode:02X} at byte offset "
                f"{start}. The bytecode is invalid or uses an instruction "
                "from an unsupported RPL version.",
                origin=origin,
                offset=start,
            )

        if spec.reserved:
            raise RPLBytecodeError(
                f"The instruction {spec.name} (opcode 0x{raw_opcode:02X}) "
                "is reserved for a future RPL version and cannot run in "
                "RPL 0.2.",
                origin=origin,
                offset=start,
            )

        operands: List[int] = []
        for kind in spec.operands:
            size = OPERAND_SIZES[kind]
            if offset + size > len(code):
                raise RPLBytecodeError(
                    f"The {spec.name} instruction at byte offset {start} "
                    f"is cut off: it needs a {kind} operand but the code "
                    "section ends too early.",
                    origin=origin,
                    offset=start,
                )
            if kind == "u8":
                operands.append(code[offset])
            else:
                operands.append(struct.unpack_from(">I", code, offset)[0])
            offset += size

        instruction = Instruction(
            offset=start,
            op=Op(raw_opcode),
            operands=tuple(operands),
            size=offset - start,
        )
        instructions.append(instruction)
        boundaries.add(offset)

    return instructions, boundaries


def _check_constant(
    index: int,
    constants: Sequence[Any],
    instruction: Instruction,
    description: str,
    origin: Optional[str],
) -> None:
    if index >= len(constants):
        raise RPLBytecodeError(
            f"{instruction.spec.name} at byte offset {instruction.offset} "
            f"refers to constant #{index}, but the pool only has "
            f"{len(constants)} constant(s).",
            origin=origin,
            offset=instruction.offset,
        )
    if description == "name" and not isinstance(constants[index], str):
        raise RPLBytecodeError(
            f"{instruction.spec.name} at byte offset {instruction.offset} "
            f"needs a text constant for a variable name, but constant "
            f"#{index} is {type(constants[index]).__name__}.",
            origin=origin,
            offset=instruction.offset,
        )


def _check_target(
    target: int,
    instruction: Instruction,
    boundaries: set,
    code_length: int,
    origin: Optional[str],
    description: str,
) -> None:
    if target != code_length and target not in boundaries:
        raise RPLBytecodeError(
            f"{instruction.spec.name} at byte offset {instruction.offset} "
            f"has an invalid {description} {target}: it does not point to "
            "the start of an instruction.",
            origin=origin,
            offset=instruction.offset,
        )


def _validate_operands(
    instructions: Sequence[Instruction],
    constants: Sequence[Any],
    boundaries: set,
    code_length: int,
    origin: Optional[str],
) -> None:
    for instruction in instructions:
        op = instruction.op

        if op is Op.PUSH_CONST:
            _check_constant(
                instruction.operands[0],
                constants,
                instruction,
                "value",
                origin,
            )

        elif op in (Op.LOAD_VARIABLE, Op.STORE_VARIABLE, Op.MAKE_VARIABLE):
            _check_constant(
                instruction.operands[0],
                constants,
                instruction,
                "name",
                origin,
            )

        elif op is Op.COMPARE:
            mode = instruction.operands[0]
            if mode not in COMPARE_MODES:
                raise RPLBytecodeError(
                    f"COMPARE at byte offset {instruction.offset} uses "
                    f"unknown comparison mode {mode}. Valid modes are 0-5.",
                    origin=origin,
                    offset=instruction.offset,
                )

        elif op in (Op.JUMP, Op.JUMP_IF_FALSE):
            _check_target(
                instruction.operands[0],
                instruction,
                boundaries,
                code_length,
                origin,
                "jump target",
            )

        elif op is Op.LOOP_START:
            target = instruction.operands[0]
            _check_target(
                target,
                instruction,
                boundaries,
                code_length,
                origin,
                "loop exit target",
            )
            if target <= instruction.offset:
                raise RPLBytecodeError(
                    f"LOOP_START at byte offset {instruction.offset} has "
                    "an exit target that does not move forward.",
                    origin=origin,
                    offset=instruction.offset,
                )

        elif op is Op.LOOP_END:
            target = instruction.operands[0]
            _check_target(
                target,
                instruction,
                boundaries,
                code_length,
                origin,
                "loop body target",
            )
            if target > instruction.offset:
                raise RPLBytecodeError(
                    f"LOOP_END at byte offset {instruction.offset} points "
                    "forward instead of back to the start of its body.",
                    origin=origin,
                    offset=instruction.offset,
                )


def _validate_entry_point(
    entry_point: int,
    instructions: Sequence[Instruction],
    code_length: int,
    origin: Optional[str],
) -> None:
    valid_offsets = {instruction.offset for instruction in instructions}
    if entry_point not in valid_offsets:
        raise RPLBytecodeError(
            f"The entry point {entry_point} is not the start of an "
            "instruction.",
            origin=origin,
            offset=16,
        )
    if entry_point >= code_length:  # defensive; valid_offsets implies this
        raise RPLBytecodeError(
            "The entry point is outside the code section.",
            origin=origin,
            offset=16,
        )


def _validate_source_map(
    source_map: Sequence[SourceMapEntry],
    boundaries: set,
    code_length: int,
    origin: Optional[str],
) -> None:
    previous = -1
    for entry in source_map:
        if entry.offset <= previous:
            raise RPLBytecodeError(
                "The source map offsets must be strictly increasing.",
                origin=origin,
                offset=entry.offset,
            )
        if entry.offset >= code_length:
            raise RPLBytecodeError(
                f"The source map points to byte offset {entry.offset}, which "
                "is outside the code section.",
                origin=origin,
                offset=entry.offset,
            )
        if entry.offset not in boundaries:
            raise RPLBytecodeError(
                f"The source map points to byte offset {entry.offset}, which "
                "is in the middle of an instruction.",
                origin=origin,
                offset=entry.offset,
            )
        if entry.line < 1 or entry.column < 1:
            raise RPLBytecodeError(
                "Source map line and column numbers must be 1 or greater.",
                origin=origin,
                offset=entry.offset,
            )
        previous = entry.offset
