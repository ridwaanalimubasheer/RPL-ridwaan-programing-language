"""Tests for the RPL lexer."""

from __future__ import annotations

import unittest

import helpers  # noqa: F401  (adds the project root to sys.path)

from src.errors import RPLLexError
from src.lexer import (
    EOF,
    IDENT,
    KEYWORD,
    MINUS,
    NEWLINE,
    NUMBER,
    STRING,
    Lexer,
)


class LexerTests(unittest.TestCase):
    def kinds(self, source: str):
        return [token.kind for token in Lexer(source).tokenize()]

    def test_simple_say(self):
        tokens = Lexer('say "hi"\n').tokenize()
        self.assertEqual(
            [(t.kind, t.value) for t in tokens],
            [
                (KEYWORD, "say"),
                (STRING, "hi"),
                (NEWLINE, "\n"),
                (EOF, ""),
            ],
        )

    def test_keywords_and_identifiers(self):
        tokens = Lexer("make score equal 10\n").tokenize()
        self.assertEqual(tokens[0].kind, KEYWORD)
        self.assertEqual(tokens[0].value, "make")
        self.assertEqual(tokens[1].kind, IDENT)
        self.assertEqual(tokens[1].value, "score")
        self.assertEqual(tokens[2].kind, KEYWORD)
        self.assertEqual(tokens[3].kind, NUMBER)
        self.assertEqual(tokens[3].value, 10)

    def test_numbers(self):
        tokens = Lexer("0 42 3.5 0.25\n").tokenize()
        values = [t.value for t in tokens if t.kind == NUMBER]
        self.assertEqual(values, [0, 42, 3.5, 0.25])
        self.assertIsInstance(values[0], int)
        self.assertIsInstance(values[2], float)

    def test_token_positions(self):
        tokens = Lexer('say "hi"\nmake x equal 1\n').tokenize()
        self.assertEqual((tokens[0].line, tokens[0].column), (1, 1))
        self.assertEqual((tokens[1].line, tokens[1].column), (1, 5))
        self.assertEqual((tokens[2].line, tokens[2].column), (1, 9))
        self.assertEqual((tokens[3].line, tokens[3].column), (2, 1))

    def test_crlf_is_normalised(self):
        tokens = Lexer('say "a"\r\nsay "b"\r\n').tokenize()
        lines = [t.line for t in tokens if t.kind == KEYWORD]
        self.assertEqual(lines, [1, 2])

    def test_comments_are_skipped(self):
        tokens = Lexer("# full line\nsay 1 # trailing\n").tokenize()
        kinds = [t.kind for t in tokens]
        self.assertEqual(
            kinds, [NEWLINE, KEYWORD, NUMBER, NEWLINE, EOF]
        )

    def test_string_escapes(self):
        tokens = Lexer(r'say "a\nb\t\"c\"\\d"').tokenize()
        self.assertEqual(tokens[1].value, 'a\nb\t"c"\\d')

    def test_minus(self):
        tokens = Lexer("-5").tokenize()
        self.assertEqual([t.kind for t in tokens], [MINUS, NUMBER, EOF])
        self.assertEqual(tokens[0].column, 1)

    def test_unterminated_string(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer('say "hello').tokenize()
        error = raised.exception
        self.assertIn("never ends", error.message)
        self.assertEqual((error.line, error.column), (1, 5))

    def test_string_cannot_span_lines(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer('say "hello\nworld"').tokenize()
        self.assertIn("cannot continue onto a new line", raised.exception.message)

    def test_unknown_escape(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer(r'say "bad \q"').tokenize()
        self.assertIn("Unknown escape sequence", raised.exception.message)
        self.assertEqual(raised.exception.column, 10)

    def test_number_followed_by_letters(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer("say 12abc").tokenize()
        self.assertIn("cannot be followed directly by letters", raised.exception.message)

    def test_decimal_needs_digit(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer("say 12.").tokenize()
        self.assertIn("decimal point", raised.exception.message)

    def test_plus_has_helpful_message(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer("add 1 + 2").tokenize()
        self.assertIn("not an RPL command", raised.exception.message)

    def test_equals_has_helpful_message(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer("make x = 1").tokenize()
        self.assertIn("word 'equal'", raised.exception.message)

    def test_error_render_contains_caret(self):
        with self.assertRaises(RPLLexError) as raised:
            Lexer('say "oops').tokenize()
        rendered = raised.exception.render()
        self.assertIn('say "oops', rendered)
        self.assertIn("^", rendered)


if __name__ == "__main__":
    unittest.main()
