#!/usr/bin/env bash
# Build a standalone Linux (or macOS) executable.
#
# Run this ON the operating system you want to target. PyInstaller cannot
# cross-compile: a Linux binary must be built on Linux, and a macOS binary
# must be built on macOS.
#
# Usage:
#   chmod +x packaging/build_linux.sh
#   ./packaging/build_linux.sh
#
# Result: dist/rpl  (no Python installation is needed to run it)

set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [ ! -x ".venv-build/bin/python" ]; then
    echo "Creating build environment..."
    python3 -m venv .venv-build
fi

echo "Installing build tools (PyInstaller)..."
.venv-build/bin/python -m pip install --disable-pip-version-check \
    -r packaging/requirements-build.txt

echo "Building dist/rpl..."
.venv-build/bin/pyinstaller \
    --noconfirm --onefile --console --clean \
    --name rpl --paths "$ROOT" rpl.py

echo
echo "Done: $ROOT/dist/rpl"
echo "Try it: ./dist/rpl version"
echo "Run an example: ./dist/rpl go examples/full_demo.rpl"
