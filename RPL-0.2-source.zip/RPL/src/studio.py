"""RPL Studio — a small graphical editor for RPL.

The studio is intentionally simple: an editor with line numbers, an output
pane, Open/Save, and one-click Run. Pressing F5 compiles the current text in
memory and runs it on the RPL VM; no terminal commands are required.

Only the standard library is used (Tkinter, which ships with the Windows and
macOS Python installers, and with python3-tk on most Linux systems).
"""

from __future__ import annotations

import os
import queue
import subprocess
import sys
import threading
import traceback
from pathlib import Path
from typing import Optional

import tkinter as tk
import tkinter.font as tkfont
from tkinter import filedialog, messagebox, ttk

from src.errors import RPLError
from src.runner import compile_to_bytes, execute_source
from src.version import __version__

WELCOME = '''# Welcome to RPL Studio
# Press F5 (or click Run) to run this program.

say "Hello from RPL!"

make score equal 10
add 5 to score
say score

repeat 3 times
    say "Working!"
end
'''

NEW_TEMPLATE = '''# New RPL program
# Press F5 to run.

say "Hello!"
'''


def examples_directory() -> Path:
    """Find the examples folder for a source checkout or a frozen build."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent / "examples"
    return Path(__file__).resolve().parents[1] / "examples"


def _enable_windows_dpi_awareness() -> None:
    if sys.platform != "win32":
        return
    try:
        import ctypes

        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        # Older Windows or a restricted environment: keep the default.
        pass


class StudioApp(tk.Tk):
    def __init__(self, initial_path: Optional[str] = None) -> None:
        super().__init__()

        self.current_path: Optional[Path] = None
        self._modified = False
        self._loading = False
        self._line_count = 0
        self._running = False
        self._results: "queue.Queue" = queue.Queue()

        self.title(f"RPL Studio {__version__}")
        self.geometry("1050x760")
        self.minsize(720, 520)

        self._mono = tkfont.Font(
            family="Consolas" if sys.platform == "win32" else "DejaVu Sans Mono",
            size=11,
        )

        self._build_menus()
        self._build_toolbar()
        self._build_status_bar()
        self._build_panes()
        self._bind_shortcuts()
        self._center_window()

        self.protocol("WM_DELETE_WINDOW", self._on_close)

        if initial_path:
            path = Path(initial_path)
            if path.is_file():
                self._load_file(path)
            else:
                self._set_editor_text(NEW_TEMPLATE)
                self.after(
                    200,
                    lambda: messagebox.showwarning(
                        "File not found",
                        f"Could not open:\n{path}\n\n"
                        "Starting with a new program instead.",
                    ),
                )
        else:
            self._set_editor_text(WELCOME)

        self.editor.focus_set()
        self.after(80, self._poll_results)
        self.after(120, self._place_sash)

    # -- construction ----------------------------------------------

    def _center_window(self) -> None:
        self.update_idletasks()
        width = 1050
        height = 760
        x = max(0, (self.winfo_screenwidth() - width) // 2)
        y = max(0, (self.winfo_screenheight() - height) // 2)
        self.geometry(f"{width}x{height}+{x}+{y}")

    def _build_menus(self) -> None:
        menubar = tk.Menu(self)

        file_menu = tk.Menu(menubar, tearoff=False)
        file_menu.add_command(
            label="New", accelerator="Ctrl+N", command=self.new_file
        )
        file_menu.add_command(
            label="Open...", accelerator="Ctrl+O", command=self.open_file
        )
        file_menu.add_command(
            label="Save", accelerator="Ctrl+S", command=self.save_file
        )
        file_menu.add_command(
            label="Save As...",
            accelerator="Ctrl+Shift+S",
            command=self.save_file_as,
        )
        file_menu.add_separator()
        file_menu.add_command(
            label="Open Examples Folder", command=self.open_examples_folder
        )
        file_menu.add_separator()
        file_menu.add_command(label="Exit", command=self._on_close)
        menubar.add_cascade(label="File", menu=file_menu)

        self.examples_menu = tk.Menu(menubar, tearoff=False)
        self._populate_examples_menu()
        menubar.add_cascade(label="Examples", menu=self.examples_menu)

        run_menu = tk.Menu(menubar, tearoff=False)
        run_menu.add_command(
            label="Run", accelerator="F5", command=self.run_program
        )
        run_menu.add_command(
            label="Compile to .rbc",
            accelerator="Ctrl+B",
            command=self.compile_program,
        )
        run_menu.add_separator()
        run_menu.add_command(
            label="Clear Output", accelerator="Ctrl+L", command=self.clear_output
        )
        menubar.add_cascade(label="Run", menu=run_menu)

        help_menu = tk.Menu(menubar, tearoff=False)
        help_menu.add_command(label="About RPL Studio", command=self.show_about)
        menubar.add_cascade(label="Help", menu=help_menu)

        self.config(menu=menubar)

    def _build_toolbar(self) -> None:
        toolbar = ttk.Frame(self, padding=(8, 8, 8, 4))
        toolbar.pack(side="top", fill="x")

        ttk.Button(toolbar, text="New", command=self.new_file).pack(
            side="left", padx=(0, 4)
        )
        ttk.Button(toolbar, text="Open", command=self.open_file).pack(
            side="left", padx=4
        )
        ttk.Button(toolbar, text="Save", command=self.save_file).pack(
            side="left", padx=4
        )

        ttk.Separator(toolbar, orient="vertical").pack(
            side="left", fill="y", padx=10
        )

        self.run_button = ttk.Button(
            toolbar, text="▶ Run (F5)", command=self.run_program
        )
        self.run_button.pack(side="left", padx=4)
        self.compile_button = ttk.Button(
            toolbar, text="Compile .rbc", command=self.compile_program
        )
        self.compile_button.pack(side="left", padx=4)

        ttk.Button(toolbar, text="Clear Output", command=self.clear_output).pack(
            side="right", padx=(4, 0)
        )

    def _build_status_bar(self) -> None:
        status = ttk.Frame(self, relief="sunken", padding=(8, 3))
        status.pack(side="bottom", fill="x")

        self.status_var = tk.StringVar(value="Ready")
        self.cursor_var = tk.StringVar(value="Ln 1, Col 1")

        ttk.Label(status, textvariable=self.status_var, anchor="w").pack(
            side="left", fill="x", expand=True
        )
        ttk.Label(status, textvariable=self.cursor_var, anchor="e").pack(
            side="right"
        )

    def _build_panes(self) -> None:
        self.paned = tk.PanedWindow(
            self, orient="vertical", sashwidth=6, sashrelief="raised"
        )
        self.paned.pack(fill="both", expand=True, padx=8, pady=(0, 4))

        editor_frame = ttk.Frame(self.paned)
        editor_frame.rowconfigure(0, weight=1)
        editor_frame.columnconfigure(1, weight=1)

        self.line_numbers = tk.Text(
            editor_frame,
            width=4,
            padx=6,
            pady=4,
            takefocus=0,
            borderwidth=0,
            highlightthickness=0,
            background="#f0f0f0",
            foreground="#777777",
            font=self._mono,
            state="disabled",
        )
        self.line_numbers.grid(row=0, column=0, sticky="ns")

        self.vbar = ttk.Scrollbar(editor_frame, orient="vertical")
        self.vbar.grid(row=0, column=2, sticky="ns")

        self.editor = tk.Text(
            editor_frame,
            undo=True,
            wrap="none",
            font=self._mono,
            padx=8,
            pady=4,
            borderwidth=0,
            highlightthickness=0,
            insertwidth=2,
            yscrollcommand=self._on_editor_yscroll,
        )
        self.editor.grid(row=0, column=1, sticky="nsew")

        hbar = ttk.Scrollbar(
            editor_frame, orient="horizontal", command=self.editor.xview
        )
        hbar.grid(row=1, column=1, sticky="ew")
        self.editor.configure(xscrollcommand=hbar.set)
        self.vbar.configure(command=self.editor.yview)

        self.editor.bind("<<Modified>>", self._on_modified)
        self.editor.bind("<Tab>", self._on_tab)
        self.editor.bind("<KeyRelease>", self._on_cursor_move)
        self.editor.bind("<ButtonRelease-1>", self._on_cursor_move)

        self.paned.add(editor_frame, minsize=300)

        output_frame = ttk.LabelFrame(self.paned, text=" Output ", padding=4)
        output_frame.rowconfigure(0, weight=1)
        output_frame.columnconfigure(0, weight=1)

        self.output = tk.Text(
            output_frame,
            wrap="word",
            height=10,
            font=self._mono,
            background="#1e1e1e",
            foreground="#e8e8e8",
            insertbackground="#e8e8e8",
            borderwidth=0,
            highlightthickness=0,
            padx=8,
            pady=6,
            state="disabled",
        )
        self.output.grid(row=0, column=0, sticky="nsew")

        output_scroll = ttk.Scrollbar(
            output_frame, orient="vertical", command=self.output.yview
        )
        output_scroll.grid(row=0, column=1, sticky="ns")
        self.output.configure(yscrollcommand=output_scroll.set)

        self.paned.add(output_frame, minsize=120)

    def _place_sash(self) -> None:
        try:
            self.paned.sash_place(0, 0, 470)
        except tk.TclError:
            pass

    def _bind_shortcuts(self) -> None:
        def shortcut(callback):
            def handler(_event):
                callback()
                return "break"

            return handler

        self.bind_all("<Control-n>", shortcut(self.new_file))
        self.bind_all("<Control-o>", shortcut(self.open_file))
        self.bind_all("<Control-s>", shortcut(self.save_file))
        self.bind_all("<Control-Shift-S>", shortcut(self.save_file_as))
        self.bind_all("<Control-b>", shortcut(self.compile_program))
        self.bind_all("<Control-l>", shortcut(self.clear_output))
        self.bind_all("<F5>", shortcut(self.run_program))

    # -- examples menu ---------------------------------------------

    def _populate_examples_menu(self) -> None:
        self.examples_menu.delete(0, "end")
        folder = examples_directory()
        files = sorted(folder.glob("*.rpl")) if folder.is_dir() else []

        if not files:
            self.examples_menu.add_command(
                label="(examples folder not found)", state="disabled"
            )
            return

        for path in files:
            self.examples_menu.add_command(
                label=path.name,
                command=lambda p=path: self.open_example(p),
            )

    def open_example(self, path: Path) -> None:
        if not self._confirm_discard():
            return
        self._load_file(path)

    def open_examples_folder(self) -> None:
        folder = examples_directory()
        if not folder.is_dir():
            messagebox.showwarning(
                "Examples not found",
                "The examples folder is not next to RPL Studio.\n\n"
                f"Expected:\n{folder}",
            )
            return
        try:
            if sys.platform.startswith("win"):
                os.startfile(str(folder))  # type: ignore[attr-defined]
            elif sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except OSError as error:
            messagebox.showerror("Could not open folder", str(error))

    # -- editor plumbing -------------------------------------------

    def _on_editor_yscroll(self, first: str, last: str) -> None:
        self.vbar.set(first, last)
        self.line_numbers.yview_moveto(first)

    def _on_tab(self, _event) -> str:
        self.editor.insert("insert", "    ")
        return "break"

    def _on_modified(self, _event=None) -> None:
        if not self.editor.edit_modified():
            return
        self.editor.edit_modified(False)
        if self._loading:
            return
        self._update_line_numbers()
        self._set_modified(True)

    def _on_cursor_move(self, _event=None) -> None:
        line, column = self.editor.index("insert").split(".")
        self.cursor_var.set(f"Ln {line}, Col {int(column) + 1}")

    def _update_line_numbers(self) -> None:
        text = self.editor.get("1.0", "end-1c")
        count = text.count("\n") + 1
        if count == self._line_count:
            return

        self._line_count = count
        numbers = "\n".join(str(number) for number in range(1, count + 1))
        self.line_numbers.configure(state="normal")
        self.line_numbers.delete("1.0", "end")
        self.line_numbers.insert("1.0", numbers)
        self.line_numbers.configure(state="disabled", width=max(4, len(str(count)) + 1))
        self.line_numbers.yview_moveto(self.editor.yview()[0])

    def _set_editor_text(self, text: str) -> None:
        self._loading = True
        self.editor.delete("1.0", "end")
        self.editor.insert("1.0", text)
        self.editor.edit_reset()
        self.editor.edit_modified(False)
        self._line_count = 0
        self._update_line_numbers()
        self.editor.mark_set("insert", "1.0")
        self.editor.see("1.0")
        self._set_modified(False)
        self._on_cursor_move()
        self.after_idle(self._finish_loading)

    def _finish_loading(self) -> None:
        self._loading = False
        self.editor.edit_modified(False)

    def _set_modified(self, modified: bool) -> None:
        self._modified = modified
        self._update_title()

    def _update_title(self) -> None:
        name = self.current_path.name if self.current_path else "Untitled.rpl"
        star = " *" if self._modified else ""
        self.title(f"{name}{star} — RPL Studio {__version__}")

    def _set_output(self, text: str) -> None:
        self.output.configure(state="normal")
        self.output.delete("1.0", "end")
        self.output.insert("1.0", text)
        self.output.see("end")
        self.output.configure(state="disabled")

    def clear_output(self) -> None:
        self._set_output("")
        self.status_var.set("Output cleared")

    # -- file commands ---------------------------------------------

    def _confirm_discard(self) -> bool:
        if not self._modified:
            return True
        answer = messagebox.askyesnocancel(
            "Unsaved changes",
            f"Save changes to {self.current_path.name if self.current_path else 'this program'}?",
        )
        if answer is None:
            return False
        if answer:
            return self.save_file()
        return True

    def new_file(self) -> None:
        if not self._confirm_discard():
            return
        self.current_path = None
        self._set_editor_text(NEW_TEMPLATE)
        self._set_output("")
        self.status_var.set("New program")

    def open_file(self) -> None:
        if not self._confirm_discard():
            return

        initial_dir = (
            str(self.current_path.parent)
            if self.current_path is not None
            else str(examples_directory() if examples_directory().is_dir() else Path.home())
        )
        filename = filedialog.askopenfilename(
            title="Open RPL program",
            initialdir=initial_dir,
            filetypes=[("RPL programs", "*.rpl"), ("All files", "*.*")],
        )
        if filename:
            self._load_file(Path(filename))

    def _load_file(self, path: Path) -> None:
        try:
            text = path.read_text(encoding="utf-8-sig")
        except (OSError, UnicodeDecodeError) as error:
            messagebox.showerror("Could not open file", f"{path}\n\n{error}")
            return

        self.current_path = path
        self._set_editor_text(text)
        self._set_output("")
        self.status_var.set(f"Opened {path.name}")

    def save_file(self) -> bool:
        if self.current_path is None:
            return self.save_file_as()
        return self._write_file(self.current_path)

    def save_file_as(self) -> bool:
        initial_dir = (
            str(self.current_path.parent)
            if self.current_path is not None
            else str(Path.home())
        )
        initial_name = (
            self.current_path.name if self.current_path is not None else "program.rpl"
        )
        filename = filedialog.asksaveasfilename(
            title="Save RPL program",
            initialdir=initial_dir,
            initialfile=initial_name,
            defaultextension=".rpl",
            filetypes=[("RPL programs", "*.rpl"), ("All files", "*.*")],
        )
        if not filename:
            return False
        return self._write_file(Path(filename))

    def _write_file(self, path: Path) -> bool:
        text = self.editor.get("1.0", "end-1c")
        if text and not text.endswith("\n"):
            text += "\n"
        try:
            path.write_text(text, encoding="utf-8")
        except OSError as error:
            messagebox.showerror("Could not save file", f"{path}\n\n{error}")
            return False

        self.current_path = path
        self._set_modified(False)
        self.status_var.set(f"Saved {path.name}")
        return True

    # -- run and compile -------------------------------------------

    def run_program(self) -> None:
        if self._running:
            return

        source = self.editor.get("1.0", "end-1c")
        name = str(self.current_path) if self.current_path else "<editor>"

        self._running = True
        self.run_button.configure(state="disabled")
        self.compile_button.configure(state="disabled")
        self.status_var.set("Running...")
        self._set_output("")

        thread = threading.Thread(
            target=self._run_worker, args=(source, name), daemon=True
        )
        thread.start()

    def _run_worker(self, source: str, name: str) -> None:
        try:
            output, steps = execute_source(source, source_name=name)
            self._results.put(("ok", output, steps))
        except RPLError as error:
            self._results.put(("rpl_error", error.render(), None))
        except Exception:
            self._results.put(("internal", traceback.format_exc(), None))

    def _poll_results(self) -> None:
        try:
            while True:
                kind, text, steps = self._results.get_nowait()
                self._finish_run(kind, text, steps)
        except queue.Empty:
            pass
        self.after(80, self._poll_results)

    def _finish_run(self, kind: str, text: str, steps: Optional[int]) -> None:
        self._running = False
        self.run_button.configure(state="normal")
        self.compile_button.configure(state="normal")

        if kind == "ok":
            self._set_output(text)
            self.status_var.set(
                f"Finished — {steps:,} instruction{'s' if steps != 1 else ''}"
            )
            return

        self._set_output(text + ("\n" if not text.endswith("\n") else ""))
        if kind == "internal":
            self.status_var.set("Internal error — please report this")
            messagebox.showerror(
                "RPL Studio internal error",
                "An unexpected error happened.\n\n"
                "The details are in the Output pane.",
            )
        else:
            self.status_var.set("Error — see Output")

    def compile_program(self) -> None:
        if self._running:
            return

        if self.current_path is None:
            if not self.save_file():
                return

        source = self.editor.get("1.0", "end-1c")
        name = str(self.current_path)
        target = self.current_path.with_suffix(".rbc")

        try:
            data = compile_to_bytes(source, name)
            target.write_bytes(data)
        except RPLError as error:
            self._set_output(error.render() + "\n")
            self.status_var.set("Compile error — see Output")
            return
        except OSError as error:
            messagebox.showerror("Could not write bytecode", str(error))
            return

        self._set_output(
            f"Compiled {self.current_path.name} -> {target.name}\n"
            f"{len(data):,} bytes\n\n"
            f"The bytecode file is next to your source:\n{target}\n"
        )
        self.status_var.set(f"Compiled {target.name}")

    # -- dialogs and close -----------------------------------------

    def show_about(self) -> None:
        messagebox.showinfo(
            "About RPL Studio",
            f"RPL Studio {__version__}\n\n"
            "A graphical editor for RPL 0.2.\n\n"
            "Press F5 to compile and run the current program.\n\n"
            "RPL is a bytecode-interpreted language with its own compiler, "
            "binary .rbc format and virtual machine. It does not produce "
            "native machine code.",
        )

    def _on_close(self) -> None:
        if self._running:
            if not messagebox.askyesno(
                "Program is running",
                "A program is still running. Quit anyway?",
            ):
                return
        if not self._confirm_discard():
            return
        self.destroy()


def launch_studio(initial_path: Optional[str] = None) -> int:
    """Open the editor. Returns a process exit code."""
    _enable_windows_dpi_awareness()
    try:
        app = StudioApp(initial_path)
    except Exception:
        details = traceback.format_exc()
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror(
                "RPL Studio could not start",
                "The editor could not open.\n\n" + details,
            )
            root.destroy()
        except Exception:
            print("RPL Studio could not start:\n" + details, file=sys.stderr)
        return 1

    app.mainloop()
    return 0
