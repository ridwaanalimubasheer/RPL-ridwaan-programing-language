#!/usr/bin/env python3
"""Launcher for RPL Studio, the graphical editor.

Double-click this file (or the built ``RPL Studio.exe``) to open the editor.
No command line is needed.  Press F5 in the editor to compile and run the
current program.
"""

from __future__ import annotations

import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)


def _show_fatal(message: str) -> None:
    """Report a startup failure even in a windowed (console-less) build."""
    try:
        import tkinter as tk
        from tkinter import messagebox

        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("RPL Studio could not start", message)
        root.destroy()
        return
    except Exception:
        pass

    try:
        import ctypes

        ctypes.windll.user32.MessageBoxW(
            0, message, "RPL Studio could not start", 0x10
        )
    except Exception:
        print("RPL Studio could not start:\n" + message, file=sys.stderr)


def main() -> int:
    try:
        from src.studio import launch_studio
    except Exception as error:  # missing Tkinter, broken install, ...
        _show_fatal(
            "The editor could not load.\n\n"
            f"{error}\n\n"
            "If Tkinter is missing on Linux, install it with:\n"
            "    sudo apt install python3-tk"
        )
        return 1

    path = sys.argv[1] if len(sys.argv) > 1 else None
    return launch_studio(path)


if __name__ == "__main__":
    raise SystemExit(main())
