"""Run RPL source text and capture its output.

This small module is shared by the graphical editor.  Keeping it separate
from Tkinter means the execution path can be tested without opening a window.

The normal CLI has its own thin glue in ``src/main.py``; this is the same
compile -> VM pipeline, with output collected in a ``StringIO``.
"""

from __future__ import annotations

import io
from typing import Optional, Tuple

from src.compiler import compile_source
from src.virtual_machine import DEFAULT_MAX_STEPS, VirtualMachine


def execute_source(
    source: str,
    *,
    source_name: str = "<source>",
    max_steps: int = DEFAULT_MAX_STEPS,
) -> Tuple[str, int]:
    """Compile and run source; return ``(output, instruction_count)``.

    Expected RPL failures (syntax, bytecode, runtime) are not caught here.
    The caller decides how to display them.
    """
    program = compile_source(source, origin=source_name)
    output = io.StringIO()
    machine = VirtualMachine(
        program,
        output=output,
        max_steps=max_steps,
        origin=source_name,
        source_text=source,
    )
    steps = machine.run()
    return output.getvalue(), steps


def compile_to_bytes(source: str, source_name: str = "<source>") -> bytes:
    """Compile source and return the complete ``.rbc`` file bytes."""
    program = compile_source(source, origin=source_name)
    return program.to_bytes()
