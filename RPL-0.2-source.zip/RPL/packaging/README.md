# Standalone builds

RPL itself is pure Python with no runtime dependencies. A *standalone build*
bundles the Python interpreter with RPL so the person running it does not
install Python.

| Platform | Status | How to get a standalone program |
| --- | --- | --- |
| Windows 10/11, 64-bit | Built and tested for 0.2 | `RPL.exe` and `RPL Studio.exe` in the release ZIP, or run `packaging\build_windows.ps1` |
| Linux, 64-bit | Build script and CI workflow provided | Run `./packaging/build_linux.sh` on Linux, or download the CI artifact |
| macOS | Same Unix script should work, untested | Run `packaging/build_linux.sh` on macOS; output is `dist/rpl` |
| iOS | **Not available** | See below |
| Android | Not available | Could be a future app wrapper; not part of 0.2 |

## Windows

From the project root:

```powershell
powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
.\dist\RPL.exe version
.\dist\RPL.exe go examples\full_demo.rpl
```

The build produces two single-file programs:

| File | Kind | Use |
| --- | --- | --- |
| `dist\RPL.exe` | console | `RPL.exe go program.rpl`, `version`, `bits`, ... |
| `dist\RPL Studio.exe` | windowed | double-click, type a program, press **F5** |

Copy either file anywhere. The target computer does not need Python. The
build computer does need Python 3.9+ and internet access once, to install
PyInstaller into the local `.venv-build` folder.

`RPL Studio.exe` opens with no console window. It contains Tkinter, the RPL
compiler, the bytecode loader and the VM, so the editor can run programs
without a separate Python installation. Examples are read from the `examples`
folder next to the executable; keep the ZIP contents together.

The executables are unsigned, so Windows SmartScreen may show a warning for a
downloaded copy. Signing requires a code-signing certificate and is not part
of this prototype.

## Linux

Build on Linux (PyInstaller does not cross-compile):

```bash
chmod +x packaging/build_linux.sh
./packaging/build_linux.sh
./dist/rpl version
```

The result is a single executable for the architecture and glibc version of
the build machine. For broad compatibility, build on an older distribution
(the included GitHub Actions workflow uses Ubuntu 22.04).

The Linux script builds the command-line program only. RPL Studio is a
Tkinter app and can be run from source on Linux after installing `python3-tk`:

```bash
sudo apt install python3-tk
python3 rpl.py studio
```

A packaged Linux Studio is not produced by the current build script.

## Automatic builds (GitHub Actions)

`.github/workflows/release.yml` builds both binaries:

- trigger it manually from the Actions tab, or
- push a tag such as `v0.2.0`.

Artifacts:

- `RPL-windows-x64.zip` containing `RPL.exe` and `RPL Studio.exe`
- `rpl-linux-x64.zip` containing `rpl`

Tag builds also create a GitHub Release with the files attached.

## Why there is no iOS build

An iOS app is not a command-line executable. To put RPL on an iPhone or iPad
you need all of the following, none of which can be produced by this Windows
project:

1. a graphical app (editor, Run button, output pane),
2. an app wrapper such as BeeWare Briefcase or Kivy,
3. macOS with Xcode to compile it,
4. an Apple Developer account and code signing for a real device or the
   App Store.

Shipping an `.ipa` from this machine would be fake. A future RPL iOS app is a
separate GUI project, not a packaging flag. The language engine can be reused,
but the app wrapper does not exist yet.

If you want an iPhone-friendly way to try RPL before that, the realistic
options are a future browser playground (not implemented) or running the
desktop build on a computer. RPL 0.2 does not claim iOS support.

## What is inside the executable

PyInstaller packages:

- the Python interpreter,
- the Python standard library modules RPL uses (including Tkinter for Studio),
- `rpl.py`, `rpl_studio.py` and the `src/` package,
- no tests, examples or source files.

Examples and documentation are shipped next to the executable in the release
ZIP, not embedded inside it.
