#!/usr/bin/env python3
"""Small launcher so the project works without installing a package.

Run from anywhere:

    python rpl.py --help

The launcher adds the project root to ``sys.path`` so that ``import src...``
works even when the current directory is different.
"""

from __future__ import annotations

import os
import sys

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

from src.main import main  # noqa: E402  (import after sys.path setup)


if __name__ == "__main__":
    raise SystemExit(main())
