# RPL — Ridwaan Programming Language

RPL is an English-based programming language with its own compiler, its own
binary bytecode format (`.rbc`), and its own virtual machine. This repository
is the reference implementation of **RPL 0.2**.

> **Status: early prototype.** RPL 0.2 is a *bytecode-interpreted* language.
> It compiles source to RPL bytecode and runs that bytecode on the RPL VM. It
> does not produce native machine code, and it is not a game engine.

## What works in 0.2

| Feature | Status |
| --- | --- |
| `say` text, numbers and variables | Implemented |
| `make name equal value` | Implemented |
| `add value to name` (whole and decimal numbers) | Implemented |
| `repeat N times ... end` (including nesting) | Implemented |
| `#` line comments | Implemented |
| Compile `.rpl` → `.rbc` | Implemented |
| Run `.rbc` on the RPL VM | Implemented |
| Custom binary format with validation and checksum | Implemented |
| Show compiled bytecode as 0s and 1s | Implemented |
| Disassembler | Implemented |
| RPL Studio graphical editor (F5 to run) | Implemented |
| `if` / `else` / conditions | **Not in 0.2** (planned 0.3) |
| Functions, parameters, lists | **Not in 0.2** (planned 0.4) |
| Modules, imports, standard library | **Not in 0.2** (planned 0.5) |
| Native executables | **Not in 0.2** |

The VM already understands subtraction, multiplication, division, comparison
and jumps at the instruction level, but RPL 0.2 source syntax only exposes the
features in the table above. See [docs/BYTECODE_SPEC.md](docs/BYTECODE_SPEC.md).

## Requirements

- Python 3.9 or newer (tested with Python 3.12)
- No third-party packages
- Windows, macOS or Linux

### No Python? Use the standalone Windows build

The release ZIP `RPL-0.2-windows-x64.zip` contains two programs that include
their own Python runtime, so the target computer does not need Python:

- **`RPL Studio.exe`** — double-click it, type a program, press **F5** to run.
- **`RPL.exe`** — the command-line program.

```text
Double-click:  RPL Studio.exe
Press:         F5
```

No terminal commands are needed for normal use. The examples and docs are in
the same folder. The command line is still available:

```powershell
.\RPL.exe version
.\RPL.exe go examples\full_demo.rpl
```

Platform status:

| Platform | Standalone support |
| --- | --- |
| Windows 10/11 x64 | Built and tested for 0.2 (`RPL.exe` and `RPL Studio.exe`) |
| Linux x64 | Build script + CI workflow provided; must be built on Linux |
| macOS | Unix build script should work but is untested |
| iOS | **Not available**; needs a GUI app, macOS/Xcode and signing |

Details and limitations: [packaging/README.md](packaging/README.md).

## Quick start — no commands (Windows)

1. Unzip `RPL-0.2-windows-x64.zip`.
2. Double-click **`RPL Studio.exe`**.
3. Type a program in the editor.
4. Press **F5**.

The output appears in the pane below the editor. Use **File → Open/Save** for
your own `.rpl` files and the **Examples** menu for the samples.

## Quick start (Windows PowerShell)

Open PowerShell in the folder that contains `rpl.py`:

```powershell
# 1. Check that RPL runs
python rpl.py version

# 2. Compile and run in one step
python rpl.py go examples/full_demo.rpl

# 3. Compile to a .rbc file, then run the bytecode
python rpl.py compile examples/full_demo.rpl
python rpl.py run examples/full_demo.rbc

# 4. Look inside the bytecode
python rpl.py disassemble examples/full_demo.rbc
python rpl.py bits examples/full_demo.rbc --max-bytes 128
```

Expected output of `full_demo.rpl`:

```text
Hello from RPL!
15
Working!
Working!
Working!
```

If PowerShell blocks a script, use `python rpl.py ...` exactly as shown.
If your path contains spaces, put the path in double quotes.

### Optional `rpl` shortcut on Windows

`rpl.cmd` is a tiny launcher:

```powershell
.\rpl.cmd go examples/hello.rpl
```

To open the graphical editor from a source checkout:

```powershell
python rpl.py studio
```

Then press **F5** to run the program in the editor.

## The language in 30 seconds

```text
# This is a comment.
say "Hello from RPL!"

make score equal 10
add 5 to score
say score

repeat 3 times
    say "Working!"
end
```

Rules for RPL 0.2:

- One command per line.
- Keywords are lowercase: `say`, `make`, `equal`, `add`, `to`, `repeat`,
  `times`, `end`.
- Variable names are case-sensitive and may contain letters, digits and
  underscores (they cannot start with a digit).
- Text uses double quotes. Escapes: `\\`, `\"`, `\n`, `\t`, `\r`.
- Indentation is for humans; `end` is what closes a `repeat`.
- Numbers are whole (`10`) or decimal (`3.5`).

Full details: [docs/LANGUAGE_SPEC.md](docs/LANGUAGE_SPEC.md).

## How it works

```text
hello.rpl
   |
   v
 Lexer      splits source into tokens, tracks line/column
   |
   v
 Parser     checks grammar and builds an AST
   |
   v
 Compiler   emits stack-machine instructions
   |
   v
 Bytecode   .rbc file: header + constants + code + source map
   |
   v
 RPL VM     validates, decodes and executes instructions
```

RPL never uses Python `eval()` or `exec()`. The VM only executes the
instruction set defined in [docs/BYTECODE_SPEC.md](docs/BYTECODE_SPEC.md).

## Commands

| Command | Purpose |
| --- | --- |
| `python rpl.py compile FILE.rpl` | Compile to `FILE.rbc` (use `-o` to choose a path) |
| `python rpl.py run FILE.rbc` | Execute a bytecode file |
| `python rpl.py go FILE.rpl` | Compile in memory and run (no file written) |
| `python rpl.py bits FILE.rbc` | Print bytes as 0s and 1s |
| `python rpl.py disassemble FILE.rbc` | Show header, constants and instructions |
| `python rpl.py studio [FILE.rpl]` | Open the graphical editor (F5 runs) |
| `python rpl.py version` | Show version information |

Useful options:

```powershell
python rpl.py compile FILE.rpl --show-ast       # show the syntax tree
python rpl.py compile FILE.rpl --show-bits      # show the new bytecode as bits
python rpl.py run FILE.rbc --limit 500000       # instruction budget
```

Exit codes: `0` success, `1` RPL error (source, bytecode or runtime), `2`
command-line usage error.

## Testing

From the project root:

```powershell
python -m unittest discover -s tests -v
```

The suite checks the lexer, parser, compiler, binary format, validator, VM,
CLI and every example. GitHub Actions runs the same suite on Python 3.9–3.12.

## Project layout

```text
RPL/
    README.md
    LICENSE
    CHANGELOG.md
    CONTRIBUTING.md
    .gitignore
    rpl.py                  launcher: python rpl.py ...
    rpl_studio.py           launcher: opens the graphical editor
    rpl.cmd                 optional Windows launcher
    packaging/
        README.md           standalone builds and platform limits
        build_windows.ps1   build RPL.exe and RPL Studio.exe (no Python to run)
        build_linux.sh      build dist/rpl on Linux/macOS
        make_windows_zip.ps1  assemble the portable Windows ZIP
        requirements-build.txt  build-only dependency (PyInstaller)
        windows/            launchers and START_HERE for the portable ZIP
    docs/
        LANGUAGE_SPEC.md    syntax and semantics
        BYTECODE_SPEC.md    byte-for-byte .rbc format
        ARCHITECTURE.md     how the pieces fit together
        TUTORIAL.md         beginner walkthrough and exercises
    src/
        lexer.py            source text -> tokens
        parser.py           tokens -> AST
        compiler.py         AST -> bytecode
        bytecode.py         format writer, reader and validator
        virtual_machine.py  instruction interpreter
        runner.py           compile-and-run helper for the editor
        studio.py           RPL Studio graphical editor (Tkinter)
        errors.py           user-facing error types
        main.py             command-line interface
        version.py          version constants
        __init__.py
    examples/
        hello.rpl
        variables.rpl
        loops.rpl
        full_demo.rpl
        nested_loops.rpl
    tests/
```

## Error messages

RPL tries to explain what went wrong and where:

```text
RPL syntax error in examples/broken.rpl, line 3, column 7:
  3 | add 5 scoer
    |       ^
Expected 'to' after the value, but found 'scoer'.
Example: add 5 to score
```

At runtime, bytecode remembers the original source line and column:

```text
RPL runtime error in examples/broken.rpl, line 2, column 5:
  2 | say scor
    |     ^
Variable 'scor' is not defined. Did you mean 'score'?
```

## Safety and limits

- Bytecode is fully validated before execution: signature, version, checksum,
  section sizes, opcodes, operand ranges, jump targets, constant types and
  source-map offsets.
- The VM counts instructions and stops after a configurable budget (default
  1,000,000) to catch accidental infinite loops.
- Value-stack, loop-nesting and variable counts have explicit limits.
- Malformed or edited `.rbc` files fail validation instead of crashing the VM.

These are prototype limits, documented in the specifications.

## Roadmap

These are proposed milestones, not guaranteed dates:

- **0.3** — conditions, comparisons, boolean values, more mathematics
- **0.4** — functions, parameters, return values, lists
- **0.5** — modules, imports, standard library, file operations
- **1.0** — stable specification, complete documentation, automated tests,
  public release

## Documentation

- [Language specification](docs/LANGUAGE_SPEC.md)
- [Bytecode specification](docs/BYTECODE_SPEC.md)
- [Architecture](docs/ARCHITECTURE.md)
- [Beginner tutorial](docs/TUTORIAL.md)
- [Standalone builds](packaging/README.md)
- [Changelog](CHANGELOG.md)
- [Contributing](CONTRIBUTING.md)

## License

MIT. See [LICENSE](LICENSE).
