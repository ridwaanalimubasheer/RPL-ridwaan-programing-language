# Build the standalone Windows programs.
#
# Usage (from anywhere):
#   powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
#
# Results:
#   dist\RPL.exe          command-line program (console)
#   dist\RPL Studio.exe   graphical editor (no console window)
#
# Both contain the Python runtime and the RPL implementation, so the computer
# that runs them does NOT need Python installed.

$ErrorActionPreference = "Stop"

$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
Set-Location $Root

$Venv = Join-Path $Root ".venv-build"

if (-not (Test-Path (Join-Path $Venv "Scripts\python.exe"))) {
    Write-Host "Creating build environment..."
    python -m venv $Venv
}

Write-Host "Installing build tools (PyInstaller)..."
& (Join-Path $Venv "Scripts\python.exe") -m pip install `
    --disable-pip-version-check `
    -r (Join-Path $Root "packaging\requirements-build.txt")

Write-Host "Building dist\RPL.exe..."
& (Join-Path $Venv "Scripts\pyinstaller.exe") `
    --noconfirm --onefile --console --clean `
    --name RPL --paths $Root rpl.py

Write-Host "Building dist\RPL Studio.exe..."
& (Join-Path $Venv "Scripts\pyinstaller.exe") `
    --noconfirm --onefile --windowed --clean `
    --name "RPL Studio" --paths $Root `
    --hidden-import src.studio --hidden-import src.runner `
    rpl_studio.py

Write-Host ""
Write-Host "Done:"
Write-Host "  $Root\dist\RPL.exe"
Write-Host "  $Root\dist\RPL Studio.exe"
Write-Host ""
Write-Host "Double-click RPL Studio.exe, then press F5 to run a program."
Write-Host "Command line: .\dist\RPL.exe version"
