"""End-to-end tests that run the real command-line interface."""

from __future__ import annotations

import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

import helpers

ROOT = helpers.ROOT


def cli(*arguments: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, str(ROOT / "rpl.py"), *arguments],
        cwd=str(ROOT),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )


class CliTests(unittest.TestCase):
    def test_help(self):
        result = cli("--help")
        self.assertEqual(result.returncode, 0)
        self.assertIn("compile", result.stdout)
        self.assertIn("disassemble", result.stdout)

    def test_no_command_is_a_usage_error(self):
        result = cli()
        self.assertEqual(result.returncode, 2)

    def test_version(self):
        result = cli("version")
        self.assertEqual(result.returncode, 0)
        self.assertIn("RPL (Ridwaan Programming Language) 0.2.0", result.stdout)
        self.assertIn("Bytecode format: 1.0", result.stdout)

    def test_version_flag(self):
        result = cli("--version")
        self.assertEqual(result.returncode, 0)
        self.assertIn("RPL 0.2.0", result.stdout)

    def test_compile_run_cycle(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "Hello from RPL!"\n', encoding="utf-8")

            compiled = cli("compile", str(source))
            self.assertEqual(compiled.returncode, 0, compiled.stderr)
            self.assertIn("Compiled", compiled.stdout)

            bytecode = source.with_suffix(".rbc")
            self.assertTrue(bytecode.exists())

            ran = cli("run", str(bytecode))
            self.assertEqual(ran.returncode, 0, ran.stderr)
            self.assertEqual(ran.stdout, "Hello from RPL!\n")

    def test_custom_output_path(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "hi"\n', encoding="utf-8")
            output = Path(directory) / "custom.rbc"

            result = cli("compile", str(source), "-o", str(output))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(output.exists())
            self.assertFalse(source.with_suffix(".rbc").exists())

    def test_go_runs_without_writing_files(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "go works"\n', encoding="utf-8")

            result = cli("go", str(source))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, "go works\n")
            self.assertEqual(list(Path(directory).glob("*.rbc")), [])

    def test_show_ast(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "hi"\n', encoding="utf-8")
            result = cli("compile", str(source), "--show-ast")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("Program", result.stdout)
            self.assertIn('say "hi"', result.stdout)

    def test_show_bits(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "hi"\n', encoding="utf-8")
            result = cli("compile", str(source), "--show-bits", "--max-bits", "16")
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("Binary view", result.stdout)
            # 0x52 is the first byte of the "RPLB" magic number.
            self.assertIn("01010010", result.stdout)

    def test_bits_command(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "hi"\n', encoding="utf-8")
            self.assertEqual(cli("compile", str(source)).returncode, 0)
            result = cli("bits", str(source.with_suffix(".rbc")))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("Binary view", result.stdout)
            self.assertIn("01010010", result.stdout)

    def test_disassemble(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "hi"\n', encoding="utf-8")
            self.assertEqual(cli("compile", str(source)).returncode, 0)
            result = cli("disassemble", str(source.with_suffix(".rbc")))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("RPL bytecode format 1.0", result.stdout)
            self.assertIn("PUSH_CONST", result.stdout)
            self.assertIn("SAY", result.stdout)
            self.assertIn("HALT", result.stdout)

    def test_syntax_error(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "broken.rpl"
            source.write_text("make x 5\n", encoding="utf-8")
            result = cli("compile", str(source))
            self.assertEqual(result.returncode, 1)
            self.assertIn("syntax error", result.stderr)
            self.assertIn("line 1", result.stderr)
            self.assertFalse(source.with_suffix(".rbc").exists())

    def test_runtime_error_from_go(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "broken.rpl"
            source.write_text('make x equal 1\nsay missing\n', encoding="utf-8")
            result = cli("go", str(source))
            self.assertEqual(result.returncode, 1)
            self.assertIn("runtime error", result.stderr)
            self.assertIn("say missing", result.stderr)
            self.assertIn("^", result.stderr)

    def test_run_source_file_gives_hint(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "hi"\n', encoding="utf-8")
            result = cli("run", str(source))
            self.assertEqual(result.returncode, 1)
            self.assertIn("RPL bytecode error", result.stderr)
            self.assertIn("Hint", result.stderr)
            self.assertIn("go", result.stderr)

    def test_missing_file(self):
        result = cli("run", "does_not_exist.rbc")
        self.assertEqual(result.returncode, 1)
        self.assertIn("file not found", result.stderr.lower())

    def test_execution_limit_option(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "loop.rpl"
            source.write_text(
                'repeat 100 times\n    say "x"\nend\n', encoding="utf-8"
            )
            self.assertEqual(cli("compile", str(source)).returncode, 0)
            result = cli(
                "run", str(source.with_suffix(".rbc")), "--limit", "10"
            )
            self.assertEqual(result.returncode, 1)
            self.assertIn("more than 10 instructions", result.stderr)

    def test_compile_onto_source_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "hello.rpl"
            source.write_text('say "hi"\n', encoding="utf-8")
            result = cli("compile", str(source), "-o", str(source))
            self.assertEqual(result.returncode, 1)
            self.assertIn("overwrite the source", result.stderr)

    def test_unicode_output(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / "unicode.rpl"
            source.write_text(
                'say "héllo — RPL ✓"\nsay "日本語"\n', encoding="utf-8"
            )
            result = cli("go", str(source))
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertIn("héllo — RPL ✓", result.stdout)
            self.assertIn("日本語", result.stdout)

    def test_bad_bytecode_is_reported(self):
        with tempfile.TemporaryDirectory() as directory:
            bad = Path(directory) / "bad.rbc"
            bad.write_bytes(b"not rpl bytecode")
            result = cli("run", str(bad))
            self.assertEqual(result.returncode, 1)
            self.assertIn("too short", result.stderr)


if __name__ == "__main__":
    unittest.main()
