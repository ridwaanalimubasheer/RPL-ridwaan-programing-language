# RPL 0.2 — Beginner Tutorial

This tutorial assumes you have never built a programming language. It walks
from "run the example" to "add a new command", explaining each stage.

## 1. Choose how to run RPL

### Option A — Windows editor, no commands (recommended)

Use the portable `RPL-0.2-windows-x64.zip`:

1. Unzip it anywhere.
2. Double-click **`RPL Studio.exe`**.
3. Type a program in the editor.
4. Press **F5**.

The result appears in the Output pane. Use **File → Open/Save** for your own
`.rpl` files and the **Examples** menu for the sample programs. No Python and
no terminal commands are needed for this option.

### Option B — Windows console, no Python

In the same ZIP, double-click `RPL Console.cmd`, then type:

```text
RPL.exe version
RPL.exe go examples\full_demo.rpl
```

Double-click `Run Hello Demo.cmd` or `Run Full Demo.cmd` to run a sample
without typing anything.

### Option C — Run from source (any OS)

You need Python 3.9+.

```powershell
cd path\to\RPL
python rpl.py version
python rpl.py go examples/full_demo.rpl
python rpl.py studio
```

The rest of this tutorial uses `python rpl.py`. If you use the standalone
build, replace `python rpl.py` with `RPL.exe`.

## 2. The files you will touch

| File | Job |
| --- | --- |
| `src/lexer.py` | text → tokens |
| `src/parser.py` | tokens → syntax tree |
| `src/compiler.py` | tree → instructions |
| `src/bytecode.py` | instructions → `.rbc` bytes, and validation |
| `src/virtual_machine.py` | executes instructions |
| `src/runner.py` | compile-and-run helper used by the editor |
| `src/studio.py` | RPL Studio graphical editor |
| `src/main.py` | the command-line commands |
| `tests/` | automated checks |
| `docs/` | specifications and this guide |

## 3. Your first program

Create `first.rpl`:

```text
say "Hello from RPL!"
```

Run it without writing bytecode:

```powershell
python rpl.py go first.rpl
```

Output:

```text
Hello from RPL!
```

`go` lexes, parses and compiles in memory, then runs the result. To keep the
bytecode:

```powershell
python rpl.py compile first.rpl
python rpl.py run first.rbc
```

You should get `first.rbc` next to the source.

## 4. Variables and loops

```text
make score equal 10
add 5 to score
say score

repeat 3 times
    say "Working!"
end
```

Run it. Output:

```text
15
Working!
Working!
Working!
```

Things to notice:

- `make` creates a variable; running `make` again replaces it.
- `add` only changes numbers and requires the variable to exist.
- `repeat` evaluates its count once, then runs the body.
- Indentation is for humans. `end` is what closes the block.
- `#` starts a comment.

## 5. Watch the compiler work

### 5.1 Show the syntax tree

```powershell
python rpl.py compile first.rpl --show-ast
```

Output (before the compile message):

```text
Program
  say "Hello from RPL!"
```

For a bigger program you will see nested `repeat`/`end` lines. The tree is the
parser's proof that the grammar is correct.

### 5.2 Disassemble the bytecode

```powershell
python rpl.py disassemble first.rbc
```

For `say "hi"` you get:

```text
RPL bytecode format 1.0
...
0000  01 00 00 00 00   PUSH_CONST  0  ; "hi", line 1, column 5
0005  05               SAY            ; line 1, column 1
0006  00               HALT           ; line 1, column 1
```

That is the whole program: push the text, print it, stop.

### 5.3 See the bits

```powershell
python rpl.py bits first.rbc --max-bytes 32
```

The first four bytes are the signature:

```text
01010010 01010000 01001100 01000010   ->  "RPLB"
```

Every byte is eight bits, most significant bit first. The complete format is in
[docs/BYTECODE_SPEC.md](BYTECODE_SPEC.md).

## 6. How the compiler thinks

Take this program:

```text
say "hi"
make score equal 10
add 5 to score
say score
```

The compiler produces:

```text
0   PUSH_CONST 0      ; "hi"        push text
5   SAY               ;             print and pop
6   PUSH_CONST 1      ; 10          push number
11  MAKE_VARIABLE 2   ; "score"     pop into variable
16  PUSH_CONST 3      ; 5
21  LOAD_VARIABLE 2   ; "score"     push current value
26  ADD               ;             pop 5 and score, push 15
27  STORE_VARIABLE 2  ; "score"     pop 15 into score
32  LOAD_VARIABLE 2   ; "score"     push 15
37  SAY               ;             print 15
38  HALT
```

A useful way to read it: the compiler is a recipe writer. It writes small
steps that say "push this", "pop that", "add the top two", "store the result".

### The hidden part: `repeat`

`repeat` is compiled into a loop with a known exit address:

```text
PUSH_CONST 2          ; count = 2
LOOP_START exit       ; if count is zero, go to exit
body_start:
...body...
LOOP_END body_start   ; count -= 1; repeat while count > 0
exit:
```

`exit` is not known until the body has been emitted, so the compiler writes a
placeholder and patches the number afterwards. This is a normal technique
called a **backpatch**.

## 7. How the VM runs instructions

The VM keeps:

- a **program counter** (`pc`) pointing at the next instruction,
- a **value stack** for temporary values,
- a **variable store** (a dictionary),
- a **loop stack** for remaining repeat counts.

For the program above, execution looks like:

| Step | Instruction | Stack after | Variables | Output |
| --- | --- | --- | --- | --- |
| 1 | `PUSH_CONST "hi"` | `["hi"]` | `{}` | |
| 2 | `SAY` | `[]` | `{}` | `hi` |
| 3 | `PUSH_CONST 10` | `[10]` | `{}` | |
| 4 | `MAKE_VARIABLE score` | `[]` | `score=10` | |
| 5 | `PUSH_CONST 5` | `[5]` | `score=10` | |
| 6 | `LOAD_VARIABLE score` | `[5, 10]` | `score=10` | |
| 7 | `ADD` | `[15]` | `score=10` | |
| 8 | `STORE_VARIABLE score` | `[]` | `score=15` | |
| 9 | `LOAD_VARIABLE score` | `[15]` | `score=15` | |
| 10 | `SAY` | `[]` | `score=15` | `15` |
| 11 | `HALT` | | | |

When `SAY` runs, it pops the top value. When `ADD` runs, it pops the right
operand first, then the left: `a op b`.

The VM also refuses to run forever. After 1,000,000 instructions it stops with
a runtime error. Raise the budget with `--limit`.

## 8. Reading errors

Bad syntax:

```text
add 5 scoer
```

```text
RPL syntax error in example.rpl, line 1, column 7:
  1 | add 5 scoer
    |       ^
Expected 'to' after the value, but found 'scoer'.
Example: add 5 to score
```

The caret points at the first token that did not fit. The message suggests the
expected word.

Bad runtime behaviour:

```text
make score equal 10
say scor
```

```text
RPL runtime error in example.rpl, line 2, column 5:
  2 | say scor
    |     ^
Variable 'scor' is not defined. Did you mean 'score'?
```

Runtime errors use the source map stored in the bytecode. That is why the VM,
which never reads the `.rpl` file, still knows the line and column.

Bad bytecode (for example after editing the binary) gives a byte offset and a
message such as "checksum does not match".

## 9. Run the tests

From the project root:

```powershell
python -m unittest discover -s tests -v
```

The suite covers:

- token positions and lexical errors,
- AST shape and syntax errors,
- compiler output,
- bytecode round-trips and corruption cases,
- VM output, arithmetic, comparisons, jumps, loops, limits and errors,
- the real CLI with temporary files,
- every example's exact output.

When you change code, run this before saying it works.

## 10. Add a new instruction (worked example)

The VM already has `SUBTRACT`, but RPL 0.2 has no `subtract` command. Let's
expose it as:

```text
subtract 5 from score
```

This is an exercise, not a feature of the downloaded 0.2 release.

### Step 1 — lexer

In `src/lexer.py`, add two reserved words:

```python
KEYWORDS = frozenset({
    "say", "make", "equal", "add", "subtract", "from",
    "to", "repeat", "times", "end",
})
```

### Step 2 — parser

In `src/parser.py`, add an AST node after `Add`:

```python
@dataclass
class Subtract(Node):
    value: Value
    name: str
    name_line: int
    name_column: int
```

Include it in the statement union:

```python
Statement = Union[Say, Make, Add, Subtract, Repeat]
```

In `_parse_statement`, add a branch:

```python
if token.value == "subtract":
    return self._parse_subtract()
```

Add the parse method:

```python
def _parse_subtract(self) -> Subtract:
    keyword = self._advance()
    value = self._parse_value("after 'subtract'")
    self._expect_keyword(
        "from", "after the value", example="subtract 5 from score"
    )
    name_token = self._current()
    if name_token.kind != IDENT:
        raise self._error(
            name_token,
            f"Expected a variable name after 'from', but found "
            f"{self._describe(name_token)}.\n"
            "Example: subtract 5 from score",
        )
    self._advance()
    return Subtract(
        keyword.line, keyword.column,
        value,
        name_token.value, name_token.line, name_token.column,
    )
```

Also add a branch to `_format_statement` if you want `--show-ast` to display
it:

```python
if isinstance(statement, Subtract):
    return [
        f"{pad}subtract {_format_value(statement.value)} "
        f"from {statement.name}"
    ]
```

### Step 3 — compiler

In `src/compiler.py`, import `Subtract` and add a branch before `Repeat`:

```python
if isinstance(statement, Subtract):
    self._compile_value(statement.value)
    name_index = self._name_constant(
        statement.name, statement.name_line, statement.name_column
    )
    self._emit(
        Op.LOAD_VARIABLE, (name_index,),
        statement.name_line, statement.name_column,
    )
    self._emit(Op.SUBTRACT, (), statement.line, statement.column)
    self._emit(
        Op.STORE_VARIABLE, (name_index,),
        statement.name_line, statement.name_column,
    )
    return
```

### Step 4 — VM

No change. `Op.SUBTRACT` is already implemented and tested. This is the value
of a documented instruction set: once an operation exists at the VM level,
adding surface syntax is mostly lexer, parser and compiler work.

### Step 5 — tests and docs

Add a parser test, a compile-shape test and a runtime test:

```python
self.assertEqual(
    run_text("make x equal 10\nsubtract 3 from x\nsay x\n"), "7\n"
)
```

Update `docs/LANGUAGE_SPEC.md`, `CHANGELOG.md` and the bytecode spec if the
instruction set changed (it did not here).

### Step 6 — try it

```powershell
python rpl.py go test.rpl
```

## 11. Add a completely new VM instruction (optional)

Suppose you want a `DOUBLE` instruction. It is not reachable from source yet,
but it is a real VM operation.

1. In `src/bytecode.py`, add `DOUBLE = 0x11` to `Op` and a spec row:
   ```python
   InstructionSpec(0x11, "DOUBLE", (), summary="Push twice the top number."),
   ```
2. In `src/virtual_machine.py`, handle it:
   ```python
   if op is Op.DOUBLE:
       value = self._pop(instruction)
       if not _is_number(value):
           raise self._error("DOUBLE needs a number.", instruction)
       self._push(value * 2)
       self.pc += 1
       continue
   ```
3. The loader needs no operand validation because `DOUBLE` has no operands.
4. Add a test using `encode_instructions([(Op.DOUBLE, ())])` and assert output.
5. Document it in `docs/BYTECODE_SPEC.md` and bump the format version if
   compatibility requires it.

If source should be able to emit it later, add a parser/compiler path as in
the `subtract` exercise.

## 12. Build the standalone version

Windows:

```powershell
powershell -ExecutionPolicy Bypass -File packaging\build_windows.ps1
.\dist\RPL.exe version
.\"dist\RPL Studio.exe"
```

That builds two programs: the console `RPL.exe` and the windowed
`RPL Studio.exe`. Double-click the Studio, then press F5. Both include Python,
so the person running them does not install it.

Linux/macOS:

```bash
chmod +x packaging/build_linux.sh
./packaging/build_linux.sh
./dist/rpl version
```

Packaging uses PyInstaller only at build time. The output includes Python, so
users do not install it. iOS is different: it needs a GUI app, macOS/Xcode and
Apple signing; see [packaging/README.md](../packaging/README.md).

## 13. Where to go next

- Read [ARCHITECTURE.md](ARCHITECTURE.md) for the module contracts.
- Read [BYTECODE_SPEC.md](BYTECODE_SPEC.md) for every byte.
- Read [LANGUAGE_SPEC.md](LANGUAGE_SPEC.md) for exact semantics and limits.
- Try the `subtract` exercise.
- Add tests before adding features.
- Keep the documentation honest: if it is not implemented, say so.

Welcome to RPL.
