@echo off
rem Optional Windows launcher: run "rpl compile file.rpl" from this folder.
python "%~dp0rpl.py" %*
