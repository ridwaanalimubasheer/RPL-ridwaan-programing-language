# RPL Language Specification — version 0.2

This document describes what RPL 0.2 actually does. Anything labelled
"planned" is a design target and is **not implemented**. The reference
implementation is the source in `src/`.

- Language version: **0.2**
- Bytecode format: **1.0**
- Implementation version: **0.2.0**

RPL is bytecode-interpreted: source is compiled to `.rbc` bytecode and run on
the RPL virtual machine. It is not compiled to native machine code.

## 1. Source files

- RPL source files conventionally use the `.rpl` extension.
- Files are UTF-8 text. A UTF-8 BOM is accepted by the command-line tool.
- `\r\n`, `\n` and `\r` line endings are accepted and treated as one newline.
- One command is written per line.
- Indentation is ignored by the language. It is used only to make programs
  readable for humans.
- A `#` character starts a comment that continues to the end of the line.
  A `#` inside text is ordinary text.

```text
# This whole line is a comment.
say "The # sign is text here."   # This part is a comment.
```

## 2. Lexical rules

### 2.1 Keywords

The following words are reserved and lowercase:

```text
say   make   equal   add   to   repeat   times   end
```

Keywords cannot be used as variable names. Keywords are case-sensitive:
`Say` is not the keyword `say`; it is an identifier and will produce a
syntax error with a lowercase hint.

### 2.2 Names (variables)

A name:

- starts with a letter (`A`–`Z`, `a`–`z`) or `_`,
- continues with letters, digits (`0`–`9`) or `_`,
- is case-sensitive: `score`, `Score` and `SCORE` are different names.

Examples: `score`, `player_1`, `_temp`.

RPL 0.2 does not limit name length separately; the total source limit applies.

### 2.3 Numbers

Number syntax:

```text
number := digit+ [ "." digit+ ]
```

Examples: `0`, `42`, `3.5`, `0.25`.

- A decimal point must be followed by at least one digit. `3.` is an error.
- A number cannot be directly followed by a letter: `12abc` is an error.
- Scientific notation (`1e5`) is not part of RPL 0.2.
- A leading minus is allowed where a value is expected: `-5`, `-2.5`.
- A number literal must fit in a signed 64-bit integer if it is whole:
  `-9,223,372,036,854,775,808` to `9,223,372,036,854,775,807`.
  Values computed at runtime are not limited to 64 bits.
- Decimal literals are stored as IEEE-754 double-precision values. A literal
  that is too large to represent is a compile error.

### 2.4 Text

Text is written in double quotes:

```text
say "Hello"
```

Supported escape sequences:

| Escape | Meaning |
| --- | --- |
| `\\` | backslash |
| `\"` | double quote |
| `\n` | newline |
| `\t` | tab |
| `\r` | carriage return |

Any other escape (for example `\q`) is a lexer error. Text cannot continue
onto a new line; there are no multiline strings in 0.2.

### 2.5 Other characters

There are no operator symbols in RPL 0.2. In particular, `+`, `=`, `<` and
`>` are rejected with a hint to use an English command. A minus sign is only
valid immediately before a number in a value position.

## 3. Program structure

A program is a sequence of statements. Empty lines are ignored. Execution
starts at the first statement and runs statements in order.

Blocks are opened by `repeat ... times` and closed by `end`. Blocks can be
nested. An `end` always closes the nearest open `repeat`.

## 4. Statements

### 4.1 `say`

```text
say <value>
```

Evaluates the value and prints it to standard output, followed by a newline.

```text
say "Hello"        # prints: Hello
say 42             # prints: 42
say score          # prints the current value of score
```

The value may be text, a number literal, or a variable name. There are no
expressions such as `a + b` in 0.2; use `add` to change a number.

### 4.2 `make`

```text
make <name> equal <value>
```

Evaluates the value and stores it in the variable. If the variable already
exists, it is replaced, including with a value of a different type:

```text
make score equal 10
make score equal "game over"
```

The value is copied, not linked. Text and numbers are immutable.

If the value is a variable that has not been created, a runtime error occurs.

### 4.3 `add`

```text
add <value> to <name>
```

Equivalent to:

```text
make <name> equal (<old value of name> + value)
```

Requirements:

- `<name>` must already exist.
- Both the old value and the added value must be numbers.
- Whole plus whole produces a whole number; if either side is decimal, the
  result is decimal.

```text
make score equal 10
add 5 to score       # score is now 15
add -2 to score      # score is now 13
```

The value may be a variable:

```text
make bonus equal 5
add bonus to score
```

Adding text is a runtime error. Subtraction, multiplication and division are
not available as RPL 0.2 source commands, although the VM instruction set
contains them for future versions.

### 4.4 `repeat ... end`

```text
repeat <count> times
    <statements>
end
```

- `<count>` may be a number literal or a variable.
- It is evaluated **once**, before the body starts.
- It must be a whole number (a decimal with no fractional part is accepted,
  such as `3.0`) and must be zero or greater.
- If the count is zero, the body is skipped.
- Otherwise the body runs exactly that many times.
- Loops can be nested.
- Variables are global; a `make` inside a loop changes the same variable each
  time and remains after the loop.

```text
repeat 3 times
    say "Working!"
end
```

There is no `break` or `continue` in 0.2.

## 5. Values and types

RPL 0.2 source can create three kinds of value:

| Kind | Examples | Notes |
| --- | --- | --- |
| Whole number | `0`, `42`, `-7` | Arbitrary precision at runtime |
| Decimal number | `3.5`, `-0.25` | IEEE-754 double |
| Text | `"hello"` | UTF-8 |

The VM also has true/false values and comparison instructions for future
language versions, but RPL 0.2 source cannot write a boolean literal or a
condition.

Printing rules:

- Whole numbers print without a decimal point.
- Decimal numbers with an integral value below `1e16` print without `.0`
  (`3.0` prints as `3`).
- Other decimals use Python's shortest round-trip representation (`3.5`,
  `0.1`, `1e+20`).
- Text prints exactly as stored.
- `say` always adds one newline at the end.

## 6. Variables and scope

RPL 0.2 has a single global variable store per program run.

- There are no local variables or block scopes yet.
- `make` creates or replaces a variable.
- Using a variable before `make` is a runtime error; the VM suggests a similar
  existing name when possible.
- `add` requires an existing variable.
- Variable names are case-sensitive.

## 7. Errors

RPL reports three categories of user-facing error:

1. **Lexer error** — invalid characters, broken text, malformed numbers.
2. **Syntax error** — tokens do not follow the grammar.
3. **Compile error** — the program is grammatical but exceeds a compiler
   limit, such as a whole number too large for the constant pool.

These happen before bytecode is written. They include a file, line, column,
the source line and a caret.

4. **Bytecode error** — a `.rbc` file is malformed, corrupted, edited, or
   uses an unsupported version.
5. **Runtime error** — a valid instruction cannot complete, for example an
   undefined variable, adding text to a number, a negative repeat count, or
   exceeding the instruction budget.

Runtime errors refer to the original `.rpl` line and column stored in the
bytecode source map. When running a `.rbc` file directly, the source text is
not available, so no source excerpt is shown; `rpl go source.rpl` shows the
excerpt.

## 8. Formal grammar (EBNF)

```ebnf
program     = { newline | statement } EOF ;
statement   = say | make | add | repeat ;
say         = "say" value newline ;
make        = "make" name "equal" value newline ;
add         = "add" value "to" name newline ;
repeat      = "repeat" value "times" newline
              { newline | statement }
              "end" newline ;
value       = number | text | name | "-" number ;
name        = identifier ;
```

Notes:

- `EOF` may replace a final newline.
- `repeat` bodies may be empty.
- The parser treats `end` as a keyword, so it cannot be a variable name.
- The grammar is implemented by a hand-written recursive-descent parser.

## 9. Limits in 0.2

| Limit | Value |
| --- | --- |
| Source characters | 2,000,000 |
| Statements per program | 50,000 |
| Nested `repeat` depth (parser) | 64 |
| Constants per bytecode file | 65,535 |
| Text constant size | 1,048,576 bytes |
| Code section | 8,388,608 bytes |
| Bytecode file | 16,777,216 bytes |
| VM instructions per run | 1,000,000 (configurable with `--limit`) |
| VM value stack | 1,024 values |
| VM loop nesting | 256 |
| VM variables | 100,000 |

These limits protect the compiler and VM from runaway input. They are
implementation limits, not language ideals, and may be raised in later
versions.

## 10. Not in RPL 0.2

The following are design targets only. They do **not** work and must not be
claimed as features:

```text
# NOT IMPLEMENTED — planned syntax examples
if score is greater than 50
    say "You win"
else
    say "Try again"
end

create function greet
    say "Welcome to RPL"
end
```

Planned milestones:

- **0.3** — conditions, comparisons, booleans, more arithmetic commands
- **0.4** — functions, parameters, return values, lists
- **0.5** — modules, imports, standard library, file operations
- **1.0** — stable specification and full documentation

Dates are not promised.

## 11. Versioning

- The **language version** describes source syntax and semantics.
- The **bytecode format version** describes the binary file layout.
- The **implementation version** describes this Python codebase.

RPL 0.2 produces bytecode format 1.0. The loader rejects files whose format
version it does not support rather than guessing. When a future version
changes the format incompatibly, the major format version must increase.

## 12. Complete example

```text
say "Hello from RPL!"

make score equal 10
add 5 to score
say score

repeat 3 times
    say "Working!"
end
```

Output:

```text
Hello from RPL!
15
Working!
Working!
Working!
```
