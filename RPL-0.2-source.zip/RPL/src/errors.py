"""Error types for RPL.

Every error that a user can cause (bad source code, bad bytecode, bad
runtime behaviour) is represented by a subclass of :class:`RPLError`.
The classes keep enough location information to print a helpful message
with the offending source line and a caret.

Internal programming mistakes are *not* wrapped: those should surface as
normal Python exceptions while developing RPL itself.
"""

from __future__ import annotations

from typing import Optional


class RPLError(Exception):
    """Base class for all expected, user-facing RPL errors."""

    kind = "error"

    def __init__(
        self,
        message: str,
        *,
        origin: Optional[str] = None,
        line: Optional[int] = None,
        column: Optional[int] = None,
        source_text: Optional[str] = None,
        offset: Optional[int] = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.origin = origin
        self.line = line
        self.column = column
        self.source_text = source_text
        self.offset = offset

    # -- formatting -------------------------------------------------

    def _source_line(self) -> Optional[str]:
        if self.source_text is None or self.line is None:
            return None
        lines = self.source_text.splitlines()
        if 1 <= self.line <= len(lines):
            return lines[self.line - 1]
        return None

    def _header(self) -> str:
        text = f"RPL {self.kind}"
        if self.origin:
            text += f" in {self.origin}"
        if self.line is not None:
            text += f", line {self.line}"
        if self.column is not None:
            text += f", column {self.column}"
        if self.offset is not None and self.line is None:
            text += f" at byte offset {self.offset}"
        return text + ":"

    def render(self) -> str:
        """Return a complete, human-readable error report."""
        lines = [self._header()]

        source_line = self._source_line()
        if source_line is not None and self.line is not None:
            # Expand tabs so that the caret lines up with the text.
            display_line = source_line.expandtabs(4)
            number = str(self.line)
            lines.append(f"  {number} | {display_line}")

            if self.column is not None and self.column >= 1:
                before = source_line[: self.column - 1]
                caret_column = len(before.expandtabs(4))
                caret_prefix = " " * (len(number) + 3) + "| "
                lines.append(caret_prefix + " " * caret_column + "^")

        lines.append(self.message)
        return "\n".join(lines)

    def __str__(self) -> str:  # pragma: no cover - convenience only
        return self.render()


class RPLLexError(RPLError):
    """The source text contains characters that cannot form tokens."""

    kind = "lexer error"


class RPLSyntaxError(RPLError):
    """The token stream does not follow RPL grammar."""

    kind = "syntax error"


class RPLCompileError(RPLError):
    """The syntax tree cannot be turned into valid bytecode."""

    kind = "compile error"


class RPLBytecodeError(RPLError):
    """A .rbc file is malformed, corrupted, or unsupported."""

    kind = "bytecode error"


class RPLRuntimeError(RPLError):
    """A valid program failed while the VM was executing it."""

    kind = "runtime error"
