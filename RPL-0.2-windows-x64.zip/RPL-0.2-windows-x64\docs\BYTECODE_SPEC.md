# RPL Bytecode Specification — format 1.0

This document specifies the binary `.rbc` files produced by RPL 0.2. The
implementation is `src/bytecode.py`; the compiler is `src/compiler.py`; the
executor is `src/virtual_machine.py`.

RPL bytecode is a stack-machine format. It is **not** native machine code.

## 1. Conventions

- All multi-byte integers are **unsigned big-endian** (network byte order)
  unless a field is explicitly signed.
- `u8` = 1 byte, `u16` = 2 bytes, `u32` = 4 bytes, `i64` = 8-byte signed
  two's-complement integer.
- File offsets are zero-based byte offsets from the start of the `.rbc` file.
- Code offsets are zero-based byte offsets from the start of the code section.
- "Text" means UTF-8 bytes with a `u32` byte length.
- The constant pool is indexed from 0.

## 2. File layout

```text
+---------------------------+ offset 0
| Header (28 bytes)         |
+---------------------------+ offset 28
| Constant pool             | variable size
+---------------------------+
| Code                      | code_length bytes
+---------------------------+
| Source map                | 12 * source_map_count bytes
+---------------------------+
```

There is no padding between sections and no trailing data. A valid file ends
exactly after the source map.

### 2.1 Header (28 bytes)

| Offset | Size | Type | Field | Meaning |
| --- | --- | --- | --- | --- |
| 0 | 4 | bytes | `magic` | ASCII `RPLB` (`52 50 4C 42`) |
| 4 | 1 | u8 | `format_major` | Must be `1` |
| 5 | 1 | u8 | `format_minor` | Must be `0` for RPL 0.2 |
| 6 | 2 | u16 | `flags` | Must be `0`; reserved for future features |
| 8 | 4 | u32 | `constant_count` | Number of constant-pool entries |
| 12 | 4 | u32 | `code_length` | Number of bytes in the code section |
| 16 | 4 | u32 | `entry_point` | Code offset where execution begins |
| 20 | 4 | u32 | `source_map_count` | Number of source-map entries |
| 24 | 4 | u32 | `checksum` | CRC32 of everything after the header |

Python struct format: `>4sBBHIIIII`.

### 2.2 Constant pool

Each entry begins with a one-byte tag:

| Tag | Name | Payload | Total size |
| --- | --- | --- | --- |
| `0x01` | integer | `i64` value | 9 bytes |
| `0x02` | decimal | IEEE-754 binary64, big-endian | 9 bytes |
| `0x03` | text | `u32` byte length + UTF-8 bytes | 5 + length bytes |

Text is validated as UTF-8. Booleans are not valid constants in format 1.0.
The compiler reuses an existing constant when the same typed value appears
again, but reuse is not required by the format.

Example: the text `"hi"` is encoded as:

```text
03              tag = text
00 00 00 02     length = 2
68 69           "hi"
```

### 2.3 Code section

Exactly `code_length` bytes. It is a sequence of instructions:

```text
instruction := opcode:u8 operand*
```

Each opcode defines its operands. Operands are not aligned or padded.
Decoding stops exactly at `code_length`; an instruction may not be cut off.

### 2.4 Source map

`source_map_count` entries, each 12 bytes:

| Offset within entry | Size | Field |
| --- | --- | --- |
| 0 | u32 | code offset |
| 4 | u32 | source line (1-based) |
| 8 | u32 | source column (1-based) |

Rules:

- Entries are sorted by strictly increasing code offset.
- Each offset must be the first byte of an instruction.
- Offsets must be inside the code section.
- The map is optional (count 0), but the compiler emits one entry for every
  instruction.
- The VM uses the nearest entry at or before the current instruction when it
  reports a runtime error.

## 3. Checksum

`checksum` is:

```python
zlib.crc32(constant_pool_bytes + code_bytes + source_map_bytes) & 0xFFFFFFFF
```

It covers **every byte after the 28-byte header**, in file order. It detects
accidental corruption and casual edits. It is not a cryptographic signature
and does not prove that a file is trustworthy.

## 4. Instruction set

Stack effect notation: `+n` means n values pushed, `-n` means n popped.

| Opcode | Name | Operands | Value-stack effect | Purpose |
| --- | --- | --- | --- | --- |
| `0x00` | `HALT` | — | 0 | Stop normally |
| `0x01` | `PUSH_CONST` | `u32` index | +1 | Push a constant |
| `0x02` | `LOAD_VARIABLE` | `u32` name index | +1 | Push a variable's value |
| `0x03` | `STORE_VARIABLE` | `u32` name index | −1 | Assign to an existing variable |
| `0x04` | `MAKE_VARIABLE` | `u32` name index | −1 | Declare or replace a variable |
| `0x05` | `SAY` | — | −1 | Print a value |
| `0x06` | `ADD` | — | −1 (pop 2, push 1) | `a + b` |
| `0x07` | `SUBTRACT` | — | −1 (pop 2, push 1) | `a - b` |
| `0x08` | `MULTIPLY` | — | −1 (pop 2, push 1) | `a * b` |
| `0x09` | `DIVIDE` | — | −1 (pop 2, push 1) | `a / b` |
| `0x0A` | `COMPARE` | `u8` mode | −1 (pop 2, push 1) | Comparison result |
| `0x0B` | `JUMP` | `u32` target | 0 | Continue at target |
| `0x0C` | `JUMP_IF_FALSE` | `u32` target | −1 | Pop and jump if false |
| `0x0D` | `LOOP_START` | `u32` exit | −1 | Pop count; start or skip loop |
| `0x0E` | `LOOP_END` | `u32` body | 0 | Repeat or finish loop |
| `0x0F` | `CALL` | — | — | **Reserved** for RPL 0.4 |
| `0x10` | `RETURN` | — | — | **Reserved** for RPL 0.4 |

Operand encoding:

- `u32` = 4 bytes, big-endian. All current u32 operands are indexes or code
  offsets, so unsigned is sufficient.
- `u8` = 1 byte.

Code targets are **absolute code-section byte offsets**, not file offsets and
not instruction numbers. A target must be an instruction boundary. Jumps may
target `code_length`, which means "fall off the end", an implicit clean halt.

`CALL` and `RETURN` have assigned opcode numbers so future files can be
recognised, but format 1.0 loaders reject them before execution. Their
operand encodings are not defined yet.

### 4.1 Instruction semantics

Values at runtime are whole numbers, decimal numbers, text, or true/false
values produced by `COMPARE`.

`PUSH_CONST <index>`
: Push a copy of the constant. Number and text constants only.

`LOAD_VARIABLE <name>`
: Constant `<name>` must be text. Push the variable's value. An undefined
  variable is a runtime error.

`STORE_VARIABLE <name>`
: Constant `<name>` must be text. Pop a value and assign it. The variable must
  already exist; otherwise runtime error.

`MAKE_VARIABLE <name>`
: Constant `<name>` must be text. Pop a value and declare it, replacing any
  previous value. This is what `make` compiles to.

`SAY`
: Pop a value and print it followed by a newline.

`ADD`, `SUBTRACT`, `MULTIPLY`, `DIVIDE`
: Pop `b`, then `a`, and push `a op b`. Both operands must be numbers.
  Whole/whole arithmetic produces a whole number for `+`, `-`, `*`; mixing a
  decimal produces a decimal. `DIVIDE` always produces a decimal and rejects
  division by zero.

`COMPARE <mode>`
: Pop `b`, then `a`, and push a boolean. Modes:

  | Mode | Meaning |
  | --- | --- |
  | 0 | equal (`EQ`) |
  | 1 | not equal (`NE`) |
  | 2 | less than (`LT`) |
  | 3 | less than or equal (`LE`) |
  | 4 | greater than (`GT`) |
  | 5 | greater than or equal (`GE`) |

  `EQ` and `NE` compare numbers numerically, text lexicographically, and
  booleans with booleans. Values of different kinds are not equal. Ordered
  modes require two numbers or two text values; mixing kinds is a runtime
  error.

`JUMP <target>`
: Set the instruction pointer to the target.

`JUMP_IF_FALSE <target>`
: Pop a value and jump when it is false. False means `false`, numeric zero,
  or empty text. Everything else is true. RPL 0.2 source does not emit this
  instruction yet.

`LOOP_START <exit>`
: Pop the repeat count. It must be a whole number `>= 0` (a decimal with an
  exactly integral value is accepted and converted). If it is zero, jump to
  `<exit>` and do not push a loop frame. Otherwise push a loop frame holding
  the count and continue with the next instruction.

`LOOP_END <body>`
: Requires a loop frame. Decrement its remaining count. If greater than zero,
  jump to `<body>`; otherwise pop the frame and continue after this
  instruction. The operand must point backwards (or to this instruction for
  an empty body).

`HALT`
: Stop with success. Reaching the end of the instruction list also stops
  cleanly.

### 4.2 Compiling `repeat`

```text
PUSH_CONST <count>      ; evaluate the count once
LOOP_START <exit>       ; patched after the body is known
<body instructions>     ; starts at <body>
LOOP_END <body>         ; decrement and repeat
<exit>:                 ; first instruction after the loop
```

The compiler writes a placeholder exit operand and patches it after emitting
`LOOP_END`. This allows nesting without a second full pass over the tree.

## 5. Validation

The loader validates the entire file before returning a program to the VM.
Checks, in order:

1. File length at least 28 bytes; file size limit.
2. Magic is `RPLB`.
3. Format version is exactly 1.0.
4. Flags are zero.
5. Counts and lengths are within limits.
6. Code length is greater than zero.
7. CRC32 checksum matches.
8. Constant count fits the remaining file size.
9. Every constant tag is known and its payload is complete.
10. Text constants are valid UTF-8 and within the text-size limit.
11. Code bytes fit exactly before the source map.
12. Source-map bytes fit exactly, and no trailing data remains.
13. Every instruction decodes fully; opcode is known and not reserved.
14. Constant indexes are in range; variable-name indexes point to text.
15. `COMPARE` mode is 0–5.
16. Jump and loop targets are instruction boundaries (or `code_length` for
    jumps/loop exits).
17. `LOOP_START` exits forward; `LOOP_END` targets backwards.
18. Entry point is the start of an instruction inside the code.
19. Source-map offsets are strictly increasing, inside the code, on
    instruction boundaries, with line/column >= 1.

Malformed bytecode produces an `RPL bytecode error` with a byte offset where
possible. The VM itself still checks stack underflow, loop frames, variable
existence and resource limits, because those are dynamic properties.

## 6. Worked example

Source:

```text
say "hi"
```

Compile:

```powershell
python rpl.py compile hi.rpl
python rpl.py disassemble hi.rbc
```

The file is 78 bytes. Hex dump:

```text
00000000  52 50 4C 42 01 00 00 00 00 00 00 01 00 00 00 07
00000010  00 00 00 00 00 00 00 03 12 E7 20 1F 03 00 00 00
00000020  02 68 69 01 00 00 00 00 05 00 00 00 00 00 00 00
00000030  00 01 00 00 00 05 00 00 00 05 00 00 00 01 00 00
00000040  00 01 00 00 00 06 00 00 00 01 00 00 00 01
```

Annotated:

| Bytes | Meaning |
| --- | --- |
| `52 50 4C 42` | magic `RPLB` |
| `01 00` | format 1.0 |
| `00 00` | flags |
| `00 00 00 01` | one constant |
| `00 00 00 07` | seven code bytes |
| `00 00 00 00` | entry point 0 |
| `00 00 00 03` | three source-map entries |
| `12 E7 20 1F` | CRC32 `0x12E7201F` |
| `03 00 00 00 02 68 69` | constant #0: text `"hi"` |
| `01 00 00 00 00` | `PUSH_CONST 0` |
| `05` | `SAY` |
| `00` | `HALT` |
| `00 00 00 00 00 00 00 01 00 00 00 05` | source map: offset 0, line 1, column 5 |
| `00 00 00 05 00 00 00 01 00 00 00 01` | offset 5, line 1, column 1 |
| `00 00 00 06 00 00 00 01 00 00 00 01` | offset 6, line 1, column 1 |

Disassembly:

```text
0000  01 00 00 00 00   PUSH_CONST  0  ; "hi", line 1, column 5
0005  05               SAY            ; line 1, column 1
0006  00               HALT           ; line 1, column 1
```

The first four bytes of the file are the signature. As bits (most significant
bit first), they are:

```text
R      P      L      B
01010010 01010000 01001100 01000010
```

Show this yourself:

```powershell
python rpl.py bits hi.rbc --max-bytes 32
```

## 7. Limits

| Limit | Value |
| --- | --- |
| File size | 16,777,216 bytes |
| Constants | 65,535 |
| Text constant | 1,048,576 bytes |
| Code section | 8,388,608 bytes |
| Source-map entries | 1,000,000 |
| VM instructions per run | 1,000,000 default; `--limit` |
| VM value stack | 1,024 |
| VM loop nesting | 256 |
| VM variables | 100,000 |

## 8. Versioning and compatibility

- RPL 0.2 writes format **1.0** and accepts only 1.0.
- A file with another major/minor version is rejected before execution.
- The `flags` field is reserved and must be zero. Future features that change
  execution requirements must use flags or a new version.
- `CALL` and `RETURN` are reserved opcode numbers, not working instructions.
- Adding a new opcode with no compatibility impact still requires a format
  version discussion, because old loaders will reject the unknown opcode.

The format is intentionally strict: a `.rbc` file must be fully understood and
validated, or it must not run.
