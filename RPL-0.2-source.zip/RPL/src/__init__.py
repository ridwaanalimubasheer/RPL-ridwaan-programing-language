"""RPL - the Ridwaan Programming Language.

RPL 0.2 is a bytecode-interpreted language.  Its pipeline is:

    source (.rpl) -> lexer -> parser -> compiler -> bytecode (.rbc) -> VM

This package contains the reference implementation.  Start with
``src/main.py`` to see how the pieces are connected.
"""

from src.version import BYTECODE_VERSION, LANGUAGE_VERSION, __version__

__all__ = ["__version__", "LANGUAGE_VERSION", "BYTECODE_VERSION"]
