"""The RPL lexer (also called a tokenizer or scanner).

The lexer turns raw source text into a flat list of tokens.  It does not
understand grammar; it only answers questions such as "is this a number?",
"is this the keyword ``repeat``?", and "where exactly did this text start?".

Token kinds used in RPL 0.2
---------------------------
KEYWORD  a reserved English word: say, make, equal, add, to, repeat, times, end
IDENT    a variable name, for example ``score``
NUMBER   a whole number or decimal number, for example ``10`` or ``3.5``
STRING   a piece of text in double quotes, for example ``"hello"``
MINUS    the ``-`` sign (only valid directly before a number)
NEWLINE  the end of a source line
EOF      the end of the file
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional

from src.errors import RPLLexError

KEYWORDS = frozenset(
    {"say", "make", "equal", "add", "to", "repeat", "times", "end"}
)

# Token kind names.  Plain strings keep tracebacks and tests easy to read.
KEYWORD = "KEYWORD"
IDENT = "IDENT"
NUMBER = "NUMBER"
STRING = "STRING"
MINUS = "MINUS"
NEWLINE = "NEWLINE"
EOF = "EOF"

# A generous guard against accidentally feeding a huge file to the compiler.
MAX_SOURCE_CHARS = 2_000_000


@dataclass(frozen=True)
class Token:
    """One lexical unit, with a 1-based source position."""

    kind: str
    value: Any
    line: int
    column: int

    def __repr__(self) -> str:  # pragma: no cover - debugging aid
        return f"Token({self.kind}, {self.value!r}, {self.line}:{self.column})"


class Lexer:
    def __init__(self, source: str, origin: Optional[str] = None) -> None:
        if len(source) > MAX_SOURCE_CHARS:
            raise RPLLexError(
                f"This source file is too large. The limit is "
                f"{MAX_SOURCE_CHARS:,} characters.",
                origin=origin,
            )
        # Normalise line endings so line counting is the same on every OS.
        self.source = source.replace("\r\n", "\n").replace("\r", "\n")
        self.origin = origin
        self.pos = 0
        self.line = 1
        self.column = 1

    # -- small helpers ---------------------------------------------

    def _peek(self, ahead: int = 0) -> Optional[str]:
        index = self.pos + ahead
        if index < len(self.source):
            return self.source[index]
        return None

    def _advance(self) -> str:
        ch = self.source[self.pos]
        self.pos += 1
        if ch == "\n":
            self.line += 1
            self.column = 1
        else:
            self.column += 1
        return ch

    def _error(self, message: str, line: int, column: int) -> RPLLexError:
        return RPLLexError(
            message,
            origin=self.origin,
            line=line,
            column=column,
            source_text=self.source,
        )

    @staticmethod
    def _is_ident_start(ch: str) -> bool:
        return ch.isalpha() or ch == "_"

    @staticmethod
    def _is_ident_part(ch: str) -> bool:
        return ch.isalnum() or ch == "_"

    # -- main loop -------------------------------------------------

    def tokenize(self) -> List[Token]:
        tokens: List[Token] = []

        while self.pos < len(self.source):
            ch = self._peek()

            if ch in (" ", "\t"):
                self._advance()
                continue

            if ch == "#":
                # Comment: ignore everything up to (but not including) newline.
                while self._peek() is not None and self._peek() != "\n":
                    self._advance()
                continue

            if ch == "\n":
                line, column = self.line, self.column
                self._advance()
                tokens.append(Token(NEWLINE, "\n", line, column))
                continue

            if ch == '"':
                tokens.append(self._read_string())
                continue

            if ch.isdigit():
                tokens.append(self._read_number())
                continue

            if ch == "-":
                line, column = self.line, self.column
                self._advance()
                tokens.append(Token(MINUS, "-", line, column))
                continue

            if self._is_ident_start(ch):
                tokens.append(self._read_word())
                continue

            line, column = self.line, self.column
            raise self._error(self._unexpected_character_message(ch), line, column)

        tokens.append(Token(EOF, "", self.line, self.column))
        return tokens

    # -- token readers ---------------------------------------------

    def _read_word(self) -> Token:
        line, column = self.line, self.column
        start = self.pos
        while self._peek() is not None and self._is_ident_part(self._peek()):
            self._advance()
        word = self.source[start : self.pos]
        if word in KEYWORDS:
            return Token(KEYWORD, word, line, column)
        return Token(IDENT, word, line, column)

    def _read_number(self) -> Token:
        line, column = self.line, self.column
        start = self.pos

        while self._peek() is not None and self._peek().isdigit():
            self._advance()

        is_decimal = False
        if self._peek() == ".":
            is_decimal = True
            dot_line, dot_column = self.line, self.column
            self._advance()
            if self._peek() is None or not self._peek().isdigit():
                raise self._error(
                    "A decimal point must be followed by at least one digit "
                    "(for example 3.5).",
                    dot_line,
                    dot_column,
                )
            while self._peek() is not None and self._peek().isdigit():
                self._advance()

        text = self.source[start : self.pos]

        # Catch 12abc early with a clear message instead of a confusing
        # "unexpected variable name" error from the parser.
        after = self._peek()
        if after is not None and self._is_ident_start(after):
            raise self._error(
                "A number cannot be followed directly by letters. "
                "Put a space or a command between them.",
                self.line,
                self.column,
            )

        try:
            value: Any = float(text) if is_decimal else int(text)
        except ValueError:  # pragma: no cover - Python guard, hard to trigger
            raise self._error(
                "This number could not be read.", line, column
            ) from None

        return Token(NUMBER, value, line, column)

    def _read_string(self) -> Token:
        line, column = self.line, self.column
        self._advance()  # opening quote
        chars: List[str] = []

        while True:
            ch = self._peek()
            if ch is None:
                raise self._error(
                    'This text never ends. Add a closing " on the same line.',
                    line,
                    column,
                )
            if ch == "\n":
                raise self._error(
                    'Text cannot continue onto a new line. Add a closing " '
                    "before the end of the line.",
                    line,
                    column,
                )
            if ch == '"':
                self._advance()
                return Token(STRING, "".join(chars), line, column)

            if ch == "\\":
                escape_line, escape_column = self.line, self.column
                self._advance()
                escaped = self._peek()
                if escaped is None:
                    raise self._error(
                        'This text never ends. Add a closing " on the same line.',
                        line,
                        column,
                    )
                mapping = {
                    "n": "\n",
                    "t": "\t",
                    "r": "\r",
                    "\\": "\\",
                    '"': '"',
                }
                if escaped not in mapping:
                    raise self._error(
                        f"Unknown escape sequence '\\{escaped}'. "
                        'Use \\\\, \\", \\n, \\t or \\r.',
                        escape_line,
                        escape_column,
                    )
                chars.append(mapping[escaped])
                self._advance()
                continue

            chars.append(self._advance())

    # -- error hints -----------------------------------------------

    @staticmethod
    def _unexpected_character_message(ch: str) -> str:
        if ch == "+":
            return (
                "The '+' sign is not an RPL command. "
                "Use an English command such as: add 5 to score"
            )
        if ch == "=":
            return (
                "RPL uses the word 'equal' instead of '='. "
                "Example: make score equal 10"
            )
        if ch in ("<", ">"):
            return (
                f"The '{ch}' sign is not available in RPL 0.2. "
                "Comparisons are planned for a future version."
            )
        if ch in ("{", "}", "[", "]"):
            return f"The character '{ch}' is not part of RPL 0.2 syntax."
        if ch == "'":
            return (
                "RPL text must use double quotes, like this: "
                "say \"hello\""
            )
        return f"Unexpected character {ch!r} in the source code."
