# Changelog

All notable changes to RPL are recorded here. The format follows the spirit
of [Keep a Changelog](https://keepachangelog.com/en/1.1.0/). RPL uses
`MAJOR.MINOR.PATCH` version numbers.

## [Unreleased]

Nothing yet. Planned work is listed in the roadmap in `README.md`.

## [0.2.0] — 2026-11-26

The first working RPL release.

### Added

- Lexer with keyword, name, number, text and comment recognition, plus
  line/column tracking and friendly lexical errors.
- Parser for `say`, `make`, `add`, and nested `repeat ... end` blocks.
- AST with source locations and a `--show-ast` view.
- Compiler from AST to a documented stack-machine bytecode.
- Custom `.rbc` binary format with:
  - `RPLB` magic number,
  - format version 1.0,
  - constant pool for integers, floats and UTF-8 text,
  - instruction code section,
  - a debug source map with line and column numbers,
  - CRC32 checksum.
- Full bytecode validator: magic, version, flags, section sizes, checksum,
  constant tags, UTF-8, opcode validity, operand ranges, constant types,
  instruction-boundary jump targets, entry point and source-map offsets.
- Virtual machine with a value stack, variable store, loop stack, runtime type
  checks, useful runtime errors, and an instruction execution limit.
- Instruction set: `HALT`, `PUSH_CONST`, `LOAD_VARIABLE`, `STORE_VARIABLE`,
  `MAKE_VARIABLE`, `SAY`, `ADD`, `SUBTRACT`, `MULTIPLY`, `DIVIDE`, `COMPARE`,
  `JUMP`, `JUMP_IF_FALSE`, `LOOP_START`, `LOOP_END`.
- `CALL` and `RETURN` opcode numbers reserved for RPL 0.4 (rejected by 0.2).
- CLI commands: `compile`, `run`, `go`, `bits`, `disassemble`, `version`,
  `studio`.
- RPL Studio, a Tkinter graphical editor with an editor pane, line numbers,
  Open/Save, an Examples menu, an output pane and **F5** to compile and run.
  It is available from source (`python rpl.py studio`) and as a standalone
  `RPL Studio.exe` in the Windows release.
- A shared `src/runner.py` helper that compiles and runs source in memory for
  the editor, with captured output and the same errors as the CLI.
- Examples: `hello.rpl`, `variables.rpl`, `loops.rpl`, `full_demo.rpl`,
  `nested_loops.rpl`.
- Automated test suite covering the lexer, parser, compiler, bytecode format,
  validator, VM, CLI, runner and example output.
- Language specification, bytecode specification, architecture guide and
  beginner tutorial.
- Portable Windows build (`RPL.exe` plus `RPL Studio.exe`, no Python required)
  with a build script, plus a Linux build script and GitHub Actions for both
  platforms.
- GitHub Actions workflows for tests and standalone binaries on Python
  3.9–3.12.

### Notes

- RPL 0.2 is bytecode-interpreted. It does not compile to native machine code.
- Source syntax does not expose comparison, functions, lists, modules or file
  operations yet. The VM-level instruction set already contains arithmetic,
  comparison and jump instructions intended for future language versions.
